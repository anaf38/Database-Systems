# DocCrop — Unified Farmer + Agriculture Officer

This build uses the **Farmer Update** ZIP as the source of truth for the Farmer module and the **Unified Complete** ZIP as the source of truth for the Agriculture Officer and Dealer modules.

## Farmer files replaced from Farmer Update
- src/routes/index.tsx
- src/routes/role.tsx
- src/routes/auth.farmer.tsx
- src/routes/home.tsx
- src/routes/scan.tsx
- src/routes/diagnosis.tsx
- src/routes/map.tsx
- src/routes/alerts.tsx
- src/routes/profile.tsx
- src/routes/history.tsx
- src/routes/history.$caseId.tsx
- src/lib/severityService.ts
- src/lib/weatherService.ts
- src/lib/i18n.ts
- src/lib/otpService.ts
- src/lib/nearbyShopService.ts
- src/lib/caseService.ts
- src/components/CropSeverityChart.tsx

## Preserved from Unified Complete
- All `officer.*` routes and Officer components/services
- All Dealer routes and Dealer components/services
- Shared UI/components/assets/configuration unless explicitly replaced above
- Unified route tree

## Important prototype limitation
The Farmer ZIP README states that ML inference (MobileNetV2/YOLO/XGBoost) is simulated/deterministic in the frontend prototype rather than connected to live ML models.
