# DocCrop Officer Dashboard – Final Changes

## Officer login and area assignment
- Officer login now validates against a demo officer directory.
- Each officer has a unique Officer ID, password, assigned area, district and division.
- Session stores the assigned area so the dashboard can use it for area-scoped operations.
- Demo accounts:
  - AO-MDU-1042 / demo123 — Madurai
  - AO-VNR-2081 / demo123 — Virudhunagar
  - AO-SIV-3017 / demo123 — Sivakasi (Virudhunagar district)
- Production deployment should move credentials to FastAPI/MongoDB and store password hashes; this frontend directory is demo-only.

## Hotspot and geofencing
- Same crop + disease reports are clustered by GPS coordinates.
- Minimum threshold: 3 distinct farmers.
- Default clustering radius: 5 km.
- Default time window: 7 days.
- Haversine distance is used for geographic calculations.
- A geofence is created in Pending Review state for qualifying hotspots.
- Officer can Approve & Activate or Reject the geofence.
- Only Active geofences can send farmer alerts.
- Alerts target only farmers inside the geofence and avoid duplicate recipients.
- Current prototype persistence is localStorage because this ZIP is the React/TanStack frontend and does not include the FastAPI/MongoDB backend.

## Field visits
- Schedule New Field Visit workflow is retained and functional in the frontend service layer.
- Farmer/case selection, date/time validation, scheduling, visit status progression and investigation flow remain available.
