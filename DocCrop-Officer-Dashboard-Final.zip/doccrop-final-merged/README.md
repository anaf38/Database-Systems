# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Field Visit Scheduling – Functional Flow

The Officer Field Visits flow is implemented end-to-end within the frontend prototype:

1. Officer opens **Field Visits → Schedule New Field Visit**.
2. Officer selects a farmer.
3. The case selector is restricted to cases belonging to that farmer.
4. Officer selects a real future date and time using the browser date/time picker.
5. Officer enters the inspection location, purpose, and optional notes.
6. The form validates required selections and rejects past/invalid visit times.
7. The visit is created with a unique visit ID and **Scheduled** status.
8. The visit is persisted through the existing officer service/localStorage layer.
9. The related case status changes to **Field Visit Scheduled**.
10. A Field Visits notification is created for the officer.
11. The new visit appears immediately in the Visits list.
12. The visit detail page supports **Start Visit**, **Cancel Visit**, and the existing **Field Investigation** workflow.
13. Starting a visit changes it to **In Progress**; completing the investigation changes it to **Completed** and updates the related case.

This remains a frontend/localStorage prototype because the uploaded ZIP does not contain a FastAPI/MongoDB backend. A backend-connected version requires wiring these visit operations to the project's backend API/database.
