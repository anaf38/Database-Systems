# DocCrop — SIH 26131

Mobile UI for early detection & management of crop diseases and pest infestations.

## Tasks
- [x] Design system (agri green / amber, Outfit + Figtree)
- [x] Bottom tab shell + mobile frame
- [x] Home: crop health summary, weather risk, quick actions
- [x] Scan: image / voice / sensor input capture
- [x] Diagnosis result: disease, severity, IPM action plan, safe usage
- [x] Alerts: risk, pest, outbreak, follow-up
- [x] Hotspot map: geospatial outbreak view + nearby input dealers
- [x] Profile: farm details, language, expert referral, history

## Later (not built yet)
- [ ] Real AI detection backend (Cloud + AI gateway)
- [ ] Official dashboard (web) for agriculture officers

## Registration flow
- [x] Language selection → role selection → farmer register/login
- [x] Home with time-of-day hero, weather tiles, crop chips, photo/voice inputs
- [ ] Officer & dealer login screens
- [ ] Location sharing prompt (manual entry / skip)
