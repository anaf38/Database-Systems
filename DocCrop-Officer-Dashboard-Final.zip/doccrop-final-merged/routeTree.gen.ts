/* eslint-disable */
// @ts-nocheck
// Generated-style route tree for the current DocCrop source tree.
import { Route as rootRouteImport } from './routes/__root'
import { Route as IndexRouteImport } from './routes/index'
import { Route as AlertsRouteImport } from './routes/alerts'
import { Route as DiagnosisRouteImport } from './routes/diagnosis'
import { Route as HomeRouteImport } from './routes/home'
import { Route as MapRouteImport } from './routes/map'
import { Route as ProfileRouteImport } from './routes/profile'
import { Route as RoleRouteImport } from './routes/role'
import { Route as ScanRouteImport } from './routes/scan'
import { Route as AuthFarmerRouteImport } from './routes/auth.farmer'
import { Route as CropRouteImport } from './routes/crop.$cropId'
import { Route as FollowUpRouteImport } from './routes/followup'
import { Route as HistoryRouteImport } from './routes/history'
import { Route as HistoryCaseRouteImport } from './routes/history.$caseId'
import { Route as OfficerRouteImport } from './routes/officer'
import { Route as OfficerCasesRouteImport } from './routes/officer.cases'
import { Route as OfficerCaseRouteImport } from './routes/officer.case.$caseId'
import { Route as ExpertRouteImport } from './routes/expert'
import { Route as ExpertCaseRouteImport } from './routes/expert.case.$caseId'
import { Route as DealerRouteImport } from './routes/dealer'

const routes = [
  [IndexRouteImport,'/','/'],[AlertsRouteImport,'/alerts','/alerts'],[DiagnosisRouteImport,'/diagnosis','/diagnosis'],[HomeRouteImport,'/home','/home'],[MapRouteImport,'/map','/map'],[ProfileRouteImport,'/profile','/profile'],[RoleRouteImport,'/role','/role'],[ScanRouteImport,'/scan','/scan'],[AuthFarmerRouteImport,'/auth/farmer','/auth/farmer'],[CropRouteImport,'/crop/$cropId','/crop/$cropId'],[FollowUpRouteImport,'/followup','/followup'],[HistoryRouteImport,'/history','/history'],[HistoryCaseRouteImport,'/history/$caseId','/history/$caseId'],[OfficerRouteImport,'/officer','/officer'],[OfficerCasesRouteImport,'/officer/cases','/officer/cases'],[OfficerCaseRouteImport,'/officer/case/$caseId','/officer/case/$caseId'],[ExpertRouteImport,'/expert','/expert'],[ExpertCaseRouteImport,'/expert/case/$caseId','/expert/case/$caseId'],[DealerRouteImport,'/dealer','/dealer']
] as const

const childEntries:any = {}
for (const [r,id,path] of routes) {
  const key = id === '/' ? 'IndexRoute' : id.replace(/^\//,'').replace(/[^A-Za-z0-9]+(.)/g,(_,c)=>String(c).toUpperCase()).replace(/\$([A-Za-z])/g,(_,c)=>String(c).toUpperCase()) + 'Route'
  childEntries[key] = r.update({ id, path, getParentRoute: () => rootRouteImport } as any)
}
export const routeTree = rootRouteImport._addFileChildren(childEntries)._addFileTypes<any>()
import type { getRouter } from './router.tsx'
import type { startInstance } from './start.ts'
declare module '@tanstack/react-router' { interface FileRoutesByPath {} }
declare module '@tanstack/react-start' { interface Register { ssr: true; router: Awaited<ReturnType<typeof getRouter>>; config: Awaited<ReturnType<typeof startInstance.getOptions>> } }
