import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Bell, User, History } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { FeedbackModal } from "@/components/FeedbackModal";
import { getPendingFeedbackCall, type ExpertCallRequest } from "@/lib/callExpertService";

const tabs = [
  { to: "/home", label: "Home", icon: Home },
  { to: "/alerts", label: "Notifications", icon: Bell },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/history", label: "History", icon: History },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [pendingFeedback, setPendingFeedback] = useState<ExpertCallRequest | null>(null);

  useEffect(() => {
    if (path.startsWith("/officer")) return;
    setPendingFeedback(getPendingFeedbackCall() ?? null);
  }, [path]);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background">
      {pendingFeedback && (
        <FeedbackModal call={pendingFeedback} onDone={() => setPendingFeedback(null)} />
      )}
      <main className="flex-1 pb-28">{children}</main>

      <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-md -translate-x-1/2 border-t border-border bg-card/95 px-3 pb-5 pt-2 backdrop-blur">
        <ul className="grid grid-cols-4">
          {tabs.map(({ to, label, icon: Icon }) => {
            const active = path === to;
            return (
              <li key={to} className="flex justify-center">
                <Link
                  to={to}
                  className={`tap flex w-full flex-col items-center gap-1 rounded-xl py-2 text-[11px] font-medium ${
                    active ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  <span
                    className={`grid size-9 place-items-center rounded-full ${
                      active ? "bg-primary-soft" : ""
                    }`}
                  >
                    <Icon
                      className={`size-5 ${active ? "" : "opacity-70"}`}
                      strokeWidth={active ? 2.4 : 1.9}
                    />
                  </span>
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

export function ScreenHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-5 pb-4 pt-7">
      <div className="min-w-0">
        <h1 className="truncate text-2xl font-bold">{title}</h1>
        {subtitle ? (
          <p className="mt-0.5 text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </header>
  );
}

export function SeverityPill({ level }: { level: "Mild" | "Moderate" | "Severe" }) {
  const map = {
    Mild: "bg-mild text-mild-foreground",
    Moderate: "bg-moderate text-moderate-foreground",
    Severe: "bg-severe text-severe-foreground",
  } as const;

  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ${map[level]}`}
    >
      {level}
    </span>
  );
}
