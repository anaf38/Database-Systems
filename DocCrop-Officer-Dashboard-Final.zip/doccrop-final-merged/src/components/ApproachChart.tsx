import { useEffect, useState } from "react";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, Legend } from "recharts";

type Tick = { t: string; distanceKm: number; risk: number };

const TICKS = 8;

export function ApproachChart({ startKm, startRisk, label }: { startKm: number; startRisk: number; label: string }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    setStep(0);
    const id = window.setInterval(() => {
      setStep((s) => (s + 1) % (TICKS + 1));
    }, 2500);
    return () => window.clearInterval(id);
  }, [startKm, startRisk]);

  const data: Tick[] = Array.from({ length: TICKS + 1 }, (_, i) => {
    const progress = Math.min(i, step) / TICKS;
    return {
      t: i === 0 ? "Now" : `+${i * 5}m`,
      distanceKm: Number((startKm * (1 - progress)).toFixed(2)),
      risk: Math.round(startRisk * (1 - progress * 0.6)),
    };
  }).slice(0, Math.max(2, step + 1));

  return (
    <div className="card-surface p-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-bold">Live approach prediction</h2>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-primary-soft px-2.5 py-1 text-[11px] font-bold text-primary">
          <span className="size-1.5 animate-pulse rounded-full bg-primary" /> Simulated live
        </span>
      </div>
      <div className="mt-3 h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
            <XAxis dataKey="t" fontSize={11} />
            <YAxis fontSize={11} />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line type="monotone" dataKey="distanceKm" name="Distance (km)" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="risk" name="Risk score" stroke="var(--color-severe-foreground)" strokeWidth={3} dot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 text-[11px] text-muted-foreground">
        As the assigned officer/expert gets closer, distance falls and the on-ground risk score is expected to drop.
        This is a prototype simulation — a production build would plug in a real GPS feed here.
      </p>
    </div>
  );
}
