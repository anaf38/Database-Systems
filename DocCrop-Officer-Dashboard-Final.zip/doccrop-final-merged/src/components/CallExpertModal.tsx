import { useState } from "react";
import { X, PhoneCall, CheckCircle2, UserRound } from "lucide-react";
import { createExpertCallRequest, getAssignedExpert } from "@/lib/callExpertService";

export function CallExpertModal({
  crop,
  disease,
  severity,
  onClose,
}: {
  crop: string;
  disease: string;
  severity: number;
  onClose: () => void;
}) {
  const expert = getAssignedExpert(`${crop}-${disease}`);
  const [sent, setSent] = useState(false);

  const call = () => {
    createExpertCallRequest({ crop, disease, severity });
    setSent(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-[1.75rem] bg-card p-6 sm:rounded-[1.75rem]">
        <div className="flex items-center justify-between">
          <p className="text-base font-bold">Call the Expert</p>
          <button onClick={onClose} className="tap grid size-9 place-items-center rounded-full bg-secondary">
            <X className="size-4" />
          </button>
        </div>

        <div className="mt-4 flex items-center gap-3 rounded-2xl bg-secondary p-4">
          <span className="grid size-12 shrink-0 place-items-center rounded-full bg-primary-soft">
            <UserRound className="size-6 text-primary" />
          </span>
          <div className="min-w-0">
            <p className="font-bold">{expert.name}</p>
            <p className="text-xs text-muted-foreground">{expert.specialty} · assigned to your area</p>
          </div>
        </div>

        <p className="mt-3 text-sm text-muted-foreground">
          {crop} · {disease} at {severity}% severity. Calling will notify your Agriculture Officer's dashboard
          so a visit can be scheduled.
        </p>

        {sent ? (
          <div className="mt-4 flex items-center gap-2 rounded-2xl bg-mild p-4 text-mild-foreground">
            <CheckCircle2 className="size-5 shrink-0" />
            <p className="text-sm font-bold">Request sent — the officer dashboard has been notified.</p>
          </div>
        ) : (
          <button
            onClick={call}
            className="tap mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground"
          >
            <PhoneCall className="size-4" />
            Call Expert
          </button>
        )}
      </div>
    </div>
  );
}
