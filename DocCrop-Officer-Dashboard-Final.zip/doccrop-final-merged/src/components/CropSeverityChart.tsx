import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, ReferenceArea } from "recharts";
import type { SeverityPoint } from "@/lib/cropTypes";

export function CropSeverityChart({ points }: { points: SeverityPoint[] }) {
  const data = points.map((p) => ({ ...p, label: new Date(p.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" }) }));
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
          <defs>
            <linearGradient id="severity-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.35} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
          {/* Mild / Moderate / Severe reference bands, so a single number reads at a glance. */}
          <ReferenceArea y1={0} y2={30} fill="var(--color-mild)" fillOpacity={0.12} />
          <ReferenceArea y1={30} y2={60} fill="var(--color-moderate)" fillOpacity={0.1} />
          <ReferenceArea y1={60} y2={100} fill="var(--color-severe)" fillOpacity={0.1} />
          <XAxis dataKey="label" fontSize={11} />
          <YAxis domain={[0, 100]} fontSize={11} tickFormatter={(v) => `${v}%`} />
          <Tooltip formatter={(v: number) => [`${v}%`, "Severity"]} />
          <Area type="monotone" dataKey="severity" stroke="var(--color-primary)" strokeWidth={3} fill="url(#severity-fill)" dot={{ r: 5 }} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
