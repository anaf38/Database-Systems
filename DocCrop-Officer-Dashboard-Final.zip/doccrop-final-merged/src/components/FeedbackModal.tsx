import { useState } from "react";
import { Star, Send } from "lucide-react";
import type { ExpertCallRequest } from "@/lib/callExpertService";
import { submitExpertFeedback } from "@/lib/callExpertService";

const QUICK_COMMENTS = ["Good service", "Very good service", "Solved my problem", "Could be faster"];

export function FeedbackModal({ call, onDone }: { call: ExpertCallRequest; onDone: () => void }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const submit = () => {
    submitExpertFeedback(call.id, rating || 5, comment || "Good service");
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-[1.75rem] bg-card p-6 sm:rounded-[1.75rem]">
        <p className="text-base font-bold">How was the visit?</p>
        <p className="mt-1 text-sm text-muted-foreground">
          {call.expert.name} visited about your {call.crop} · {call.disease} case.
        </p>

        <div className="mt-4 flex justify-center gap-2">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} onClick={() => setRating(n)} className="tap p-1" aria-label={`${n} star`}>
              <Star className={`size-8 ${n <= rating ? "fill-accent text-accent" : "text-border"}`} />
            </button>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {QUICK_COMMENTS.map((c) => (
            <button
              key={c}
              onClick={() => setComment(c)}
              className={`tap rounded-full border px-3 py-1.5 text-xs font-semibold ${
                comment === c ? "border-primary bg-primary-soft text-primary" : "border-border bg-secondary"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Add a note (optional)"
          className="mt-3 h-20 w-full rounded-xl border border-border bg-secondary p-3 text-sm outline-none"
        />

        <button
          onClick={submit}
          disabled={rating === 0}
          className="tap mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
        >
          <Send className="size-4" />
          Submit feedback
        </button>
      </div>
    </div>
  );
}
