import type { RiskBand } from "@/lib/hotspotTypes";

const TONE: Record<RiskBand, string> = {
  LOW: "bg-mild text-mild-foreground",
  MEDIUM: "bg-moderate text-moderate-foreground",
  HIGH: "bg-severe text-severe-foreground",
  CRITICAL: "bg-destructive text-destructive-foreground",
};

export function RiskBadge({ band, label }: { band: RiskBand; label?: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ${TONE[band]}`}>
      {label ?? `${band} risk`}
    </span>
  );
}
