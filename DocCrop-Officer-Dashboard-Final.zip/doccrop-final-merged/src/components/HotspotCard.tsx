import { Link } from "@tanstack/react-router";
import { AlertTriangle, MapPin, Users } from "lucide-react";
import type { Hotspot } from "@/lib/hotspotTypes";
import { RiskBadge } from "./HotspotBadge";

export function HotspotCard({ hotspot }: { hotspot: Hotspot }) {
  const critical = hotspot.riskBand === "CRITICAL";
  return (
    <Link
      to="/officer/hotspot/$hotspotId"
      params={{ hotspotId: hotspot.id }}
      className={`tap card-surface block overflow-hidden ${critical ? "ring-2 ring-destructive" : ""}`}
    >
      <div className="flex items-start gap-3 p-4">
        <span className={`grid size-10 shrink-0 place-items-center rounded-xl ${critical ? "bg-destructive text-destructive-foreground" : "bg-severe text-severe-foreground"}`}>
          <AlertTriangle className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
            {critical ? "Critical hotspot" : "Active hotspot"}
          </p>
          <p className="mt-0.5 font-bold leading-snug">{hotspot.disease}</p>
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="size-3.5" />
            {hotspot.location} · {hotspot.radiusKm} km cluster
          </p>
          <p className="mt-1 flex items-center gap-1 text-xs font-semibold">
            <Users className="size-3.5 text-primary" />
            {hotspot.affectedFarmers} affected farmers
          </p>
        </div>
        <RiskBadge band={hotspot.riskBand} />
      </div>
      <div className="flex items-center justify-between border-t border-border bg-secondary/60 px-4 py-2.5">
        <span className="text-xs font-semibold text-muted-foreground">
          {hotspot.fieldVisitRequired ? "Field visit recommended" : "Monitor for further reports"}
        </span>
        <span className="text-xs font-bold text-primary">Review hotspot →</span>
      </div>
    </Link>
  );
}
