import type { Hotspot } from "@/lib/hotspotTypes";

const SIZE = 280;
const CENTER = SIZE / 2;

// Rough km-per-degree projection, fine for a small local cluster preview.
function kmOffset(center: { latitude: number; longitude: number }, point: { latitude: number; longitude: number }) {
  const dLat = (point.latitude - center.latitude) * 111;
  const dLon = (point.longitude - center.longitude) * 111 * Math.cos((center.latitude * Math.PI) / 180);
  return { dx: dLon, dy: -dLat }; // north is up
}

export function HotspotMapView({ hotspot }: { hotspot: Hotspot }) {
  const maxKm = Math.max(hotspot.radiusKm * 1.35, 0.6);
  const pxPerKm = (SIZE / 2 - 32) / maxKm;
  const boundaryR = hotspot.radiusKm * pxPerKm;

  return (
    <div className="card-surface overflow-hidden p-0">
      <svg viewBox={`0 0 ${SIZE} ${SIZE}`} className="block w-full" role="img" aria-label={`Map of the ${hotspot.disease} hotspot near ${hotspot.location}`}>
        <defs>
          <pattern id="hotspot-grid" width="28" height="28" patternUnits="userSpaceOnUse">
            <path d="M 28 0 L 0 0 0 28" fill="none" stroke="var(--color-border)" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width={SIZE} height={SIZE} fill="var(--color-secondary)" />
        <rect width={SIZE} height={SIZE} fill="url(#hotspot-grid)" opacity="0.6" />

        {/* Boundary of the potential affected zone */}
        <circle cx={CENTER} cy={CENTER} r={boundaryR} fill="var(--color-severe)" fillOpacity="0.18" stroke="var(--color-severe-foreground)" strokeDasharray="6 5" strokeWidth="2" />

        {/* Center point */}
        <circle cx={CENTER} cy={CENTER} r={5} fill="var(--color-severe-foreground)" />
        <circle cx={CENTER} cy={CENTER} r={9} fill="none" stroke="var(--color-severe-foreground)" strokeWidth="1.5" opacity="0.6" />

        {/* Farmer markers */}
        {hotspot.cases.map((c, i) => {
          const { dx, dy } = kmOffset(hotspot.center, c);
          const x = CENTER + dx * pxPerKm;
          const y = CENTER + dy * pxPerKm;
          return (
            <g key={c.id}>
              <circle cx={x} cy={y} r={9} fill="var(--color-primary)" stroke="var(--color-card)" strokeWidth="2" />
              <text x={x} y={y + 3.5} textAnchor="middle" fontSize="9" fontWeight="700" fill="var(--color-primary-foreground)">
                {i + 1}
              </text>
            </g>
          );
        })}

        <text x={12} y={22} fontSize="12" fontWeight="700" fill="var(--color-foreground)">
          {hotspot.location}
        </text>
        <text x={12} y={SIZE - 14} fontSize="10" fill="var(--color-muted-foreground)">
          Potential affected zone · ~{hotspot.radiusKm} km radius
        </text>
      </svg>
      <div className="flex flex-wrap gap-x-4 gap-y-1 border-t border-border px-4 py-2.5 text-[11px] text-muted-foreground">
        {hotspot.cases.map((c, i) => (
          <span key={c.id}>
            <b className="text-foreground">{i + 1}</b> {c.farmerName}
          </span>
        ))}
      </div>
    </div>
  );
}
