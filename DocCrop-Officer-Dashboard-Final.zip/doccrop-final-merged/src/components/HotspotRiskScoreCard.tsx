import type { Hotspot } from "@/lib/hotspotTypes";
import { RiskBadge } from "./HotspotBadge";

export function HotspotRiskScoreCard({ hotspot }: { hotspot: Hotspot }) {
  const b = hotspot.riskBreakdown;
  return (
    <div className="card-surface p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Hotspot risk score</p>
          <p className="mt-1 text-3xl font-bold">
            {hotspot.riskScore}
            <span className="text-base font-medium text-muted-foreground">/100</span>
          </p>
        </div>
        <RiskBadge band={hotspot.riskBand} />
      </div>
      <ul className="mt-3 space-y-1.5 text-xs text-muted-foreground">
        <li className="flex justify-between"><span>Affected farms</span><b className="text-foreground">{b.affectedFarms}</b></li>
        <li className="flex justify-between"><span>Geographic concentration</span><b className="text-foreground">{b.geographicConcentration}</b></li>
        <li className="flex justify-between"><span>New cases</span><b className="text-foreground">{b.newCases}</b></li>
        <li className="flex justify-between"><span>Environmental conditions</span><b className="text-foreground">{b.environmentalConditions}</b></li>
        <li className="flex justify-between border-t border-border pt-1.5"><span>Overall</span><b className="text-foreground">{b.overall}</b></li>
      </ul>
      <p className="mt-3 rounded-xl bg-secondary p-2.5 text-[11px] text-muted-foreground">
        Prototype risk score for officer triage only — not a validated outbreak-detection measurement. Field verification is required.
      </p>
    </div>
  );
}
