import { AlertTriangle, CalendarClock, Search, CheckCircle2, Eye, CheckCheck } from "lucide-react";
import type { HotspotStatus } from "@/lib/hotspotTypes";

const STEPS: { status: HotspotStatus; label: string; icon: typeof AlertTriangle }[] = [
  { status: "New", label: "New", icon: AlertTriangle },
  { status: "Field Visit Scheduled", label: "Field visit scheduled", icon: CalendarClock },
  { status: "Under Investigation", label: "Under investigation", icon: Search },
  { status: "Confirmed", label: "Confirmed", icon: CheckCircle2 },
  { status: "Monitoring", label: "Monitoring", icon: Eye },
  { status: "Resolved", label: "Resolved", icon: CheckCheck },
];

// "Under Review" sits alongside "New" (both pre field-visit) so it doesn't need its own column.
function stepIndex(status: HotspotStatus) {
  if (status === "Under Review") return 0;
  return STEPS.findIndex((s) => s.status === status);
}

export function HotspotStatusStepper({ status }: { status: HotspotStatus }) {
  const current = stepIndex(status);
  return (
    <div className="card-surface p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Hotspot status</p>
      <ol className="mt-3 flex items-start justify-between">
        {STEPS.map((step, i) => {
          const Icon = step.icon;
          const done = i < current;
          const active = i === current;
          return (
            <li key={step.status} className="flex flex-1 flex-col items-center text-center">
              <span
                className={`grid size-8 place-items-center rounded-full ${
                  active ? "bg-primary text-primary-foreground" : done ? "bg-primary-soft text-primary" : "bg-secondary text-muted-foreground"
                }`}
              >
                <Icon className="size-4" />
              </span>
              <p className={`mt-1 text-[9px] font-semibold leading-tight ${active ? "text-primary" : "text-muted-foreground"}`}>{step.label}</p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
