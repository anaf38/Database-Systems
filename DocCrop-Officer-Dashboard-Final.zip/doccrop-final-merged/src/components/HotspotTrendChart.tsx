import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { TrendingUp } from "lucide-react";
import type { Hotspot } from "@/lib/hotspotTypes";

export function HotspotTrendChart({ hotspot }: { hotspot: Hotspot }) {
  return (
    <div className="card-surface p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Case trend</p>
        {hotspot.increasing ? (
          <span className="flex items-center gap-1 rounded-full bg-severe px-2.5 py-1 text-[11px] font-bold text-severe-foreground">
            <TrendingUp className="size-3.5" />
            Cases are increasing
          </span>
        ) : (
          <span className="rounded-full bg-mild px-2.5 py-1 text-[11px] font-bold text-mild-foreground">Stable</span>
        )}
      </div>
      <div className="mt-2 h-40 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={hotspot.trend} margin={{ top: 8, right: 10, left: -25, bottom: 0 }}>
            <defs>
              <linearGradient id="hotspot-trend-fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--color-severe-foreground)" stopOpacity={0.35} />
                <stop offset="100%" stopColor="var(--color-severe-foreground)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="label" fontSize={11} />
            <YAxis fontSize={11} allowDecimals={false} />
            <Tooltip formatter={(v: number) => [`${v}`, "Cumulative cases"]} />
            <Area type="monotone" dataKey="cumulativeCases" stroke="var(--color-severe-foreground)" strokeWidth={3} fill="url(#hotspot-trend-fill)" dot={{ r: 4 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
