import { useRef, useState, type PointerEvent } from "react";
import { MapPin, Store, ZoomIn, ZoomOut, LocateFixed } from "lucide-react";

export type MapMarker = {
  id: string;
  label: string;
  km: number;
  bearingDeg: number; // 0 = north/up, clockwise
  kind: "hotspot" | "shop";
  tone?: "severe" | "moderate" | "mild";
};

const SIZE = 320;
const CENTER = SIZE / 2;
const PX_PER_KM = 26;

function toXY(km: number, bearingDeg: number) {
  const rad = (bearingDeg * Math.PI) / 180;
  return { x: CENTER + Math.sin(rad) * km * PX_PER_KM, y: CENTER - Math.cos(rad) * km * PX_PER_KM };
}

const TONE_FILL: Record<string, string> = {
  severe: "var(--color-severe-foreground)",
  moderate: "var(--color-moderate-foreground)",
  mild: "var(--color-mild-foreground)",
};

export function LiveMap({ markers, selectedId, onSelect }: { markers: MapMarker[]; selectedId: string | null; onSelect: (id: string) => void }) {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragging = useRef<{ startX: number; startY: number; panX: number; panY: number } | null>(null);

  const onPointerDown = (e: PointerEvent) => {
    dragging.current = { startX: e.clientX, startY: e.clientY, panX: pan.x, panY: pan.y };
    (e.target as Element).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: PointerEvent) => {
    if (!dragging.current) return;
    const dx = e.clientX - dragging.current.startX;
    const dy = e.clientY - dragging.current.startY;
    setPan({ x: dragging.current.panX + dx, y: dragging.current.panY + dy });
  };
  const onPointerUp = () => {
    dragging.current = null;
  };

  const selected = markers.find((m) => m.id === selectedId) ?? null;

  return (
    <div className="relative aspect-square overflow-hidden rounded-[1.75rem] border border-border bg-secondary">
      <div
        className="size-full cursor-grab touch-none active:cursor-grabbing"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
      >
        <svg
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          className="block w-full"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "center" }}
        >
          <defs>
            <pattern id="live-grid" width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" stroke="var(--color-border)" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width={SIZE} height={SIZE} fill="url(#live-grid)" opacity="0.7" />

          {/* range rings every 2km */}
          {[2, 4, 6, 8].map((r) => (
            <circle key={r} cx={CENTER} cy={CENTER} r={r * PX_PER_KM} fill="none" stroke="var(--color-border)" strokeDasharray="3 4" />
          ))}

          {/* path line to selected marker */}
          {selected && (
            <line
              x1={CENTER}
              y1={CENTER}
              x2={toXY(selected.km, selected.bearingDeg).x}
              y2={toXY(selected.km, selected.bearingDeg).y}
              stroke="var(--color-primary)"
              strokeWidth={2.5}
              strokeDasharray="7 6"
            />
          )}

          {/* farmer marker with a live pulse ring */}
          <circle cx={CENTER} cy={CENTER} r={8} fill="var(--color-primary)">
            <animate attributeName="r" values="8;14;8" dur="2.2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.5;0;0.5" dur="2.2s" repeatCount="indefinite" />
          </circle>
          <circle cx={CENTER} cy={CENTER} r={6} fill="var(--color-primary)" />

          {markers.map((m) => {
            const { x, y } = toXY(m.km, m.bearingDeg);
            const active = m.id === selectedId;
            const fill = m.kind === "hotspot" ? TONE_FILL[m.tone ?? "moderate"] : "var(--color-foreground)";
            return (
              <g key={m.id} onClick={() => onSelect(m.id)} className="cursor-pointer">
                <circle cx={x} cy={y} r={active ? 10 : 7} fill={fill} opacity={active ? 1 : 0.85} stroke="var(--color-card)" strokeWidth={2} />
              </g>
            );
          })}
        </svg>
      </div>

      <span className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-[calc(100%+10px)]">
        <MapPin className="size-6 text-primary drop-shadow" />
      </span>

      <div className="absolute bottom-4 left-4 rounded-xl bg-card/95 px-3 py-2">
        <p className="text-[11px] font-bold">Your live location</p>
        <p className="text-[11px] text-muted-foreground">Drag to pan · pinch not required, use +/-</p>
      </div>

      <div className="absolute right-4 top-4 flex flex-col gap-2">
        <button onClick={() => setZoom((z) => Math.min(2.5, z + 0.25))} className="tap grid size-10 place-items-center rounded-xl bg-card/95">
          <ZoomIn className="size-5 text-primary" />
        </button>
        <button onClick={() => setZoom((z) => Math.max(0.6, z - 0.25))} className="tap grid size-10 place-items-center rounded-xl bg-card/95">
          <ZoomOut className="size-5 text-primary" />
        </button>
        <button onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }} className="tap grid size-10 place-items-center rounded-xl bg-card/95">
          <LocateFixed className="size-5 text-primary" />
        </button>
      </div>

      {selected && (
        <div className="absolute left-4 right-4 top-4 max-w-[65%] rounded-xl bg-card/95 px-3 py-2">
          <div className="flex items-center gap-1.5">
            {selected.kind === "shop" ? <Store className="size-3.5 text-primary" /> : <MapPin className="size-3.5 text-primary" />}
            <p className="truncate text-[11px] font-bold">{selected.label}</p>
          </div>
          <p className="text-[11px] text-muted-foreground">{selected.km.toFixed(1)} km away</p>
        </div>
      )}
    </div>
  );
}
