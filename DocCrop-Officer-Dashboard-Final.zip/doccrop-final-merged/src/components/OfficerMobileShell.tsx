// src/components/OfficerMobileShell.tsx
import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "@tanstack/react-router";
import {
  Home,
  ClipboardList,
  AlertTriangle,
  CalendarCheck2,
  Menu,
  X,
  Radar,
  Users,
  FileBarChart2,
  Bell,
  Settings,
  LogOut,
  User,
  ArrowLeft,
  ShieldAlert,
} from "lucide-react";
import {
  getUnreadNotificationCount,
  isOfficerAuthenticated,
  logoutOfficer,
  getOfficerProfile,
} from "@/lib/officerService";

interface OfficerMobileShellProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  backTo?: string;
  children: React.ReactNode;
}

export function OfficerMobileShell({
  title = "Agriculture Officer",
  subtitle,
  showBack = false,
  backTo,
  children,
}: OfficerMobileShellProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const profile = getOfficerProfile();

  useEffect(() => {
    if (!isOfficerAuthenticated()) {
      navigate({ to: "/officer/login", replace: true });
      return;
    }
    setUnreadCount(getUnreadNotificationCount());
  }, [navigate, location.pathname]);

  const handleLogout = () => {
    logoutOfficer();
    navigate({ to: "/officer/login", replace: true });
  };

  const currentPath = location.pathname;

  const navItems = [
    { label: "Home", path: "/officer/dashboard", icon: Home },
    { label: "Cases", path: "/officer/cases", icon: ClipboardList },
    { label: "Alerts", path: "/officer/alerts", icon: AlertTriangle },
    { label: "Visits", path: "/officer/visits", icon: CalendarCheck2 },
  ];

  return (
    <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col bg-background text-foreground shadow-2xl">
      {/* Top App Bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/60 bg-card/95 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center gap-2.5 min-w-0">
          {showBack ? (
            <button
              type="button"
              onClick={() => {
                if (backTo) navigate({ to: backTo as any });
                else window.history.back();
              }}
              className="tap grid size-9 place-items-center rounded-xl bg-secondary text-secondary-foreground"
              aria-label="Back"
            >
              <ArrowLeft className="size-5" />
            </button>
          ) : (
            <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground font-bold text-sm shadow-sm">
              AO
            </div>
          )}
          <div className="min-w-0">
            <h1 className="truncate text-base font-bold leading-tight tracking-tight">{title}</h1>
            {subtitle && <p className="truncate text-[11px] text-muted-foreground">{subtitle}</p>}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <Link
            to="/officer/notifications"
            className="tap relative grid size-9 place-items-center rounded-xl bg-secondary text-secondary-foreground transition hover:bg-secondary/80"
            aria-label="Notifications"
          >
            <Bell className="size-5" />
            {unreadCount > 0 && (
              <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground animate-pulse">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </Link>
          <button
            type="button"
            onClick={() => setMenuOpen(!menuOpen)}
            className="tap grid size-9 place-items-center rounded-xl bg-secondary text-secondary-foreground"
            aria-label="Toggle menu"
          >
            {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 pb-24 overflow-x-hidden">
        {children}
      </main>

      {/* Slide-out / Bottom Drawer for More Modules */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm animate-in fade-in">
          <div className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-md rounded-t-3xl border-t border-border bg-card p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-border/60 pb-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-primary">Department of Agriculture</p>
                <p className="text-sm font-bold">{profile.name}</p>
                <p className="text-xs text-muted-foreground">{profile.division}</p>
              </div>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                className="tap grid size-8 place-items-center rounded-full bg-secondary"
              >
                <X className="size-4" />
              </button>
            </div>

            <nav className="mt-4 grid grid-cols-2 gap-2 text-sm font-medium">
              <Link
                to="/officer/hotspots"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <Radar className="size-4 text-severe-foreground" />
                <span>Hotspots</span>
              </Link>
              <Link
                to="/officer/farmers"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <Users className="size-4 text-primary" />
                <span>Farmers</span>
              </Link>
              <Link
                to="/officer/reports"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <FileBarChart2 className="size-4 text-emerald-600" />
                <span>Reports</span>
              </Link>
              <Link
                to="/officer/notifications"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <Bell className="size-4 text-amber-500" />
                <span>Notifications</span>
              </Link>
              <Link
                to="/officer/profile"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <User className="size-4 text-blue-500" />
                <span>Profile</span>
              </Link>
              <Link
                to="/officer/settings"
                onClick={() => setMenuOpen(false)}
                className="tap flex items-center gap-2.5 rounded-xl border border-border/80 bg-background p-3 text-left hover:border-primary"
              >
                <Settings className="size-4 text-slate-500" />
                <span>Settings</span>
              </Link>
            </nav>

            <div className="mt-4 border-t border-border/60 pt-3 flex gap-2">
              <button
                type="button"
                onClick={handleLogout}
                className="tap flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-destructive/10 py-2.5 text-xs font-bold text-destructive hover:bg-destructive/20"
              >
                <LogOut className="size-3.5" />
                Log out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 z-30 mx-auto w-full max-w-md border-t border-border/70 bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-lg">
        <div className="grid grid-cols-5 items-center py-1.5 text-center">
          {navItems.map(({ label, path, icon: Icon }) => {
            const active = currentPath === path || (path !== "/officer/dashboard" && currentPath.startsWith(path));
            return (
              <Link
                key={path}
                to={path as any}
                className={`tap flex flex-col items-center justify-center py-1 text-[11px] font-semibold transition ${
                  active ? "text-primary font-bold" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <span
                  className={`grid size-8 place-items-center rounded-xl transition ${
                    active ? "bg-primary-soft text-primary shadow-xs" : ""
                  }`}
                >
                  <Icon className="size-5" />
                </span>
                <span className="mt-0.5">{label}</span>
              </Link>
            );
          })}

          {/* Profile / More Tab */}
          <Link
            to="/officer/profile"
            className={`tap flex flex-col items-center justify-center py-1 text-[11px] font-semibold transition ${
              currentPath === "/officer/profile" ? "text-primary font-bold" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <span
              className={`grid size-8 place-items-center rounded-xl transition ${
                currentPath === "/officer/profile" ? "bg-primary-soft text-primary shadow-xs" : ""
              }`}
            >
              <User className="size-5" />
            </span>
            <span className="mt-0.5">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
