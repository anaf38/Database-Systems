import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import type { HistoryCase } from "@/lib/cropTypes";
export function TreatmentOutcomeChart({ cases }: { cases: HistoryCase[] }) {
  const data = cases.map((c) => ({ name: `${c.crop} · ${c.disease}`, initial: c.initialSeverity, final: c.finalSeverity }));
  return <div className="h-72 w-full"><ResponsiveContainer width="100%" height="100%"><BarChart data={data} margin={{ top: 10, right: 8, left: -15, bottom: 35 }}><CartesianGrid strokeDasharray="3 3" opacity={0.25}/><XAxis dataKey="name" angle={-18} textAnchor="end" interval={0} fontSize={10}/><YAxis domain={[0,100]} fontSize={11}/><Tooltip formatter={(v, n) => [`${v}%`, n === "initial" ? "Initial" : "Final"]}/><Bar dataKey="initial" fill="hsl(var(--primary))" radius={[5,5,0,0]}/><Bar dataKey="final" fill="hsl(var(--accent))" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div>;
}
