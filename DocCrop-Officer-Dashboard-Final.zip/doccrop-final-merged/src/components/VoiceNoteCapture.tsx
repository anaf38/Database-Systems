import { useEffect, useRef, useState } from "react";
import { Mic, Square, X, Check } from "lucide-react";

type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: any) => void) | null;
  onerror: ((event: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

function getRecognition(): SpeechRecognitionLike | null {
  if (typeof window === "undefined") return null;
  const Ctor = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
  if (!Ctor) return null;
  return new Ctor();
}

/** Maps DocCrop's language codes to BCP-47 tags the browser speech API understands. */
const LANG_MAP: Record<string, string> = {
  en: "en-IN",
  ta: "ta-IN",
  hi: "hi-IN",
  mr: "mr-IN",
  te: "te-IN",
  kn: "kn-IN",
  ml: "ml-IN",
  bn: "bn-IN",
  gu: "gu-IN",
  pa: "pa-IN",
};

export function VoiceNoteCapture({
  lang,
  onClose,
  onSave,
}: {
  lang: string;
  onClose: () => void;
  onSave: (text: string) => void;
}) {
  const [supported, setSupported] = useState(true);
  const [listening, setListening] = useState(false);
  const [text, setText] = useState("");
  const recRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    const rec = getRecognition();
    if (!rec) {
      setSupported(false);
      return;
    }
    rec.lang = LANG_MAP[lang] ?? "en-IN";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (event) => {
      let finalText = "";
      for (let i = 0; i < event.results.length; i++) {
        finalText += event.results[i][0].transcript;
      }
      setText(finalText);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recRef.current = rec;
    return () => {
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
    };
  }, [lang]);

  const toggle = () => {
    if (!recRef.current) return;
    if (listening) {
      recRef.current.stop();
      setListening(false);
    } else {
      setText("");
      recRef.current.start();
      setListening(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-[1.75rem] bg-card p-5 sm:rounded-[1.75rem]">
        <div className="flex items-center justify-between">
          <p className="text-base font-bold">Describe the problem by voice</p>
          <button onClick={onClose} className="tap grid size-9 place-items-center rounded-full bg-secondary">
            <X className="size-4" />
          </button>
        </div>

        {!supported ? (
          <div className="mt-4 space-y-3">
            <p className="rounded-xl bg-secondary p-3 text-sm text-muted-foreground">
              Voice-to-text isn't supported in this browser. Try Chrome on Android, or type your note instead.
            </p>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="e.g. Yellow spots on the lower leaves since yesterday"
              className="h-28 w-full rounded-xl border border-border bg-secondary p-3 text-sm outline-none"
            />
          </div>
        ) : (
          <div className="mt-5 flex flex-col items-center">
            <button
              onClick={toggle}
              className={`tap grid size-20 place-items-center rounded-full text-primary-foreground shadow-lift ${
                listening ? "bg-severe-foreground" : "field-gradient"
              }`}
            >
              {listening ? <Square className="size-7" /> : <Mic className="size-8" />}
            </button>
            <p className="mt-3 text-xs font-semibold text-muted-foreground">
              {listening ? "Listening… tap to stop" : "Tap to speak"}
            </p>
            <div className="mt-4 min-h-16 w-full rounded-xl bg-secondary p-3 text-sm">
              {text || <span className="text-muted-foreground">Your words will appear here as text…</span>}
            </div>
          </div>
        )}

        <button
          onClick={() => onSave(text.trim())}
          disabled={!text.trim()}
          className="tap mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
        >
          <Check className="size-4" />
          Use this note
        </button>
      </div>
    </div>
  );
}
