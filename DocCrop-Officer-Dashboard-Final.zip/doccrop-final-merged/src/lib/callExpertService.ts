// Farmer-initiated "Call the Expert" loop.
// Farmer taps Call Expert -> request is created + Officer dashboard is notified ->
// Officer marks the visit complete -> Farmer is prompted for a star rating.
// Prototype-only: persisted to localStorage, no real backend/telephony.

import { CURRENT_FARMER_NAME } from "./farmerIdentity";
import { EXPERTS, type Expert } from "./hotspotTypes";
import { pushOfficerNotification } from "./hotspotService";
import { addNotification as addFarmerNotification } from "./notificationService";

export type ExpertCallStatus = "Requested" | "Visited" | "Feedback Given";

export type ExpertCallRequest = {
  id: string;
  farmerName: string;
  crop: string;
  disease: string;
  severity: number;
  expert: Expert;
  status: ExpertCallStatus;
  requestedAt: string;
  visitedAt?: string;
  feedback?: { rating: number; comment: string; submittedAt: string };
};

const KEY = "doccrop.expertCalls";

function readAll(): ExpertCallRequest[] {
  if (typeof localStorage === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "[]") as ExpertCallRequest[];
  } catch {
    return [];
  }
}

function writeAll(list: ExpertCallRequest[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(list));
}

/** Deterministically assigns an expert based on crop/disease so the same case always reaches the same person. */
export function getAssignedExpert(seed: string): Expert {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  return EXPERTS[hash % EXPERTS.length];
}

export function getExpertCalls(): ExpertCallRequest[] {
  return readAll().sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());
}

export function getExpertCall(id: string): ExpertCallRequest | undefined {
  return readAll().find((c) => c.id === id);
}

/** Any call whose visit is done but the farmer hasn't rated it yet — used to trigger the feedback popup. */
export function getPendingFeedbackCall(): ExpertCallRequest | undefined {
  return readAll().find((c) => c.status === "Visited");
}

export function createExpertCallRequest(input: { crop: string; disease: string; severity: number }): ExpertCallRequest {
  const expert = getAssignedExpert(`${input.crop}-${input.disease}`);
  const request: ExpertCallRequest = {
    id: `EC-${Date.now()}`,
    farmerName: CURRENT_FARMER_NAME,
    crop: input.crop,
    disease: input.disease,
    severity: input.severity,
    expert,
    status: "Requested",
    requestedAt: new Date().toISOString(),
  };
  writeAll([request, ...readAll()]);

  pushOfficerNotification({
    title: `${CURRENT_FARMER_NAME} called for expert help`,
    body: `${input.crop} · ${input.disease} at ${input.severity}% severity. Assigned to ${expert.name} (${expert.specialty}). Please schedule a visit.`,
    priority: input.severity >= 70 ? "URGENT" : "HIGH",
    callId: request.id,
  });

  return request;
}

/** Officer/expert marks the visit as done — this is what unlocks the farmer's feedback prompt. */
export function markExpertVisitComplete(id: string) {
  const list = readAll().map((c) => (c.id === id ? { ...c, status: "Visited" as const, visitedAt: new Date().toISOString() } : c));
  writeAll(list);
  const call = list.find((c) => c.id === id);
  if (!call) return;
  addFarmerNotification({
    kind: "visit",
    title: `${call.expert.name} visited your farm`,
    body: `Your ${call.crop} · ${call.disease} case was reviewed on-site. Please rate the visit.`,
  });
}

export function submitExpertFeedback(id: string, rating: number, comment: string) {
  const list = readAll().map((c) =>
    c.id === id ? { ...c, status: "Feedback Given" as const, feedback: { rating, comment, submittedAt: new Date().toISOString() } } : c,
  );
  writeAll(list);
}
