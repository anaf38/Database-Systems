// Diagnosis engine + case/history store for the Farmer module.
//
// "Scan crop" flow: farmer's photo → runScan() → a CropCase is created and
// persisted here → shown on /diagnosis → follow-ups get appended over time →
// once resolved, it moves into farmer history (/history, /history/$caseId).
//
// Prototype-only: there's no real MobileNetV2/YOLO/XGBoost model running in
// the browser. runScan() picks a deterministic result from a small
// crop→disease/pest knowledge base (seeded off the image file's name+size so
// the *same* photo always gives the *same* result, which is what a demo
// needs) and lib/riskService.ts supplies the XGBoost-style risk score. A
// production build would swap the body of runScan() for a real inference
// call and keep everything downstream (storage, follow-ups, history)
// unchanged.

import { predictRisk } from "./riskService";
import { compareSeverity } from "./severityService";
import type { CropCase, HistoryCase, ProductUsed, SeverityPoint, TreatmentPlan, TreatmentPreference } from "./cropTypes";

const CASES_KEY = "doccrop.cases";
const HISTORY_KEY = "doccrop.history";

type DiagnosisTemplate = {
  disease: string;
  kind: "disease" | "pest";
  symptoms: string[];
  causes: string[];
  organic: Omit<TreatmentPlan, "preference">;
  chemical: Omit<TreatmentPlan, "preference">;
};

const KNOWLEDGE_BASE: Record<string, DiagnosisTemplate[]> = {
  Soybean: [
    {
      disease: "Yellow Mosaic Virus",
      kind: "disease",
      symptoms: ["Yellow-green mosaic patches on leaves", "Stunted pod formation"],
      causes: ["Whitefly transmission", "Warm, humid weather"],
      organic: { product: "Neem oil 1500 ppm + Yellow sticky traps", quantity: "5 ml/L water, spray every 5 days", instructions: ["Spray in the early morning or evening", "Install 8-10 yellow sticky traps per acre to cut whitefly numbers"], safety: ["Wash hands after handling", "Keep away from bee foraging hours"], followUpDays: [3, 7, 14] },
      chemical: { product: "Thiamethoxam 25% WG", quantity: "0.2 g/L water (100 g/acre in 500L)", instructions: ["Spray to control the whitefly vector, not the virus directly", "Repeat after 10 days if pressure continues"], safety: ["Wear gloves and mask while spraying", "Observe the 15-day pre-harvest interval", "Do not mix with alkaline products"], followUpDays: [3, 7, 14] },
    },
    {
      disease: "Girdle Beetle",
      kind: "pest",
      symptoms: ["Girdled/wilted stems and petioles", "Plants lodging at the ringed point"],
      causes: ["Adult beetle activity in early vegetative stage", "Continuous soybean cropping"],
      organic: { product: "Neem seed kernel extract (NSKE 5%)", quantity: "50 ml/L water", instructions: ["Spray at 15-20 days after sowing", "Remove and destroy girdled stems"], safety: ["Store away from direct sunlight"], followUpDays: [4, 8, 15] },
      chemical: { product: "Thiamethoxam 12.6% + Lambda-cyhalothrin 9.5% ZC", quantity: "0.5 ml/L water", instructions: ["Apply as soon as girdling is first noticed", "One well-timed spray usually controls the generation"], safety: ["Wear PPE", "7-day pre-harvest interval"], followUpDays: [4, 8, 15] },
    },
  ],
  Cotton: [
    {
      disease: "Pink Bollworm",
      kind: "pest",
      symptoms: ["Rosette flowers", "Bored bolls with pink larvae", "Damaged lint and seeds"],
      causes: ["Moth activity around square/boll formation", "Carry-over from previous season's residue"],
      organic: { product: "Pheromone traps (Gossyplure) + Bt spray", quantity: "5 traps/acre + Bt 2 g/L water", instructions: ["Install traps at flowering", "Spray Bt in the evening"], safety: ["Replace pheromone lures every 3 weeks"], followUpDays: [5, 10, 20] },
      chemical: { product: "Profenofos 50% EC", quantity: "2 ml/L water (1L/acre in 500L)", instructions: ["Spray at first sign of rosette flowers", "Avoid spraying during flowering peak to protect pollinators where possible"], safety: ["Wear full protective gear", "21-day pre-harvest interval"], followUpDays: [5, 10, 20] },
    },
  ],
  Tomato: [
    {
      disease: "Early Blight",
      kind: "disease",
      symptoms: ["Concentric dark brown leaf spots", "Lower leaf yellowing and drop"],
      causes: ["Alternaria solani fungus", "Warm days, cool humid nights"],
      organic: { product: "Trichoderma viride + Copper oxychloride (organic-approved)", quantity: "5 g/L water", instructions: ["Spray at 10-day intervals starting at first spot", "Improve airflow by staking/pruning"], safety: ["Do not spray in direct hot sun"], followUpDays: [3, 7, 14] },
      chemical: { product: "Mancozeb 75% WP", quantity: "2.5 g/L water", instructions: ["Cover both leaf surfaces", "Rotate with a different fungicide group after 2 sprays"], safety: ["Wear a mask while mixing", "7-day pre-harvest interval"], followUpDays: [3, 7, 14] },
    },
  ],
  Onion: [
    {
      disease: "Purple Blotch",
      kind: "disease",
      symptoms: ["Small water-soaked lesions turning purple-brown", "Leaf tip die-back"],
      causes: ["Alternaria porri fungus", "High humidity, leaf wetness"],
      organic: { product: "Neem oil + Trichoderma-based bio-fungicide", quantity: "5 ml/L + 5 g/L water", instructions: ["Spray every 7 days in humid weather", "Avoid overhead irrigation in the evening"], safety: ["Store separately from chemical inputs"], followUpDays: [4, 8, 16] },
      chemical: { product: "Chlorothalonil 75% WP", quantity: "2 g/L water", instructions: ["Begin at first lesion, repeat every 10 days"], safety: ["Wear gloves and eye protection", "10-day pre-harvest interval"], followUpDays: [4, 8, 16] },
    },
  ],
};

const DEFAULT_CROP = "Soybean";

function seedFromFile(file: { name: string; size: number }) {
  let hash = 0;
  const s = `${file.name}-${file.size}`;
  for (let i = 0; i < s.length; i++) hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  return hash;
}

function readCases(): CropCase[] {
  if (typeof localStorage === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(CASES_KEY) ?? "[]") as CropCase[];
  } catch {
    return [];
  }
}
function writeCases(list: CropCase[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(CASES_KEY, JSON.stringify(list));
  window.dispatchEvent(new Event("doccrop-session"));
}
function readHistory(): HistoryCase[] {
  if (typeof localStorage === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "[]") as HistoryCase[];
  } catch {
    return [];
  }
}
function writeHistory(list: HistoryCase[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
}

export type ScanResult = { case: CropCase; kind: "disease" | "pest" };

/** Simulated on-device inference (see file header) — deterministic per photo. */
export function runScan(file: File, crop: string | undefined, humidity = 68, rainProbability = 35): ScanResult {
  const cropKey = crop && KNOWLEDGE_BASE[crop] ? crop : DEFAULT_CROP;
  const templates = KNOWLEDGE_BASE[cropKey] ?? KNOWLEDGE_BASE[DEFAULT_CROP]!;
  const seed = seedFromFile(file);
  const template = templates[seed % templates.length]!;
  const severity = 30 + (seed % 55); // 30-85%
  const confidence = 78 + (seed % 18); // 78-95%
  const risk = predictRisk({ severity, humidity, rainfallProbability: rainProbability, history: seed % 3 === 0 });

  const now = new Date().toISOString();
  const point: SeverityPoint = { date: now, dayNumber: 0, severity };

  const cropCase: CropCase = {
    id: `CASE-${Date.now()}`,
    crop: cropKey,
    disease: template.disease,
    confidence,
    severity,
    riskScore: risk.score,
    riskLevel: risk.level,
    diagnosedAt: now,
    location: "",
    symptoms: template.symptoms,
    causes: template.causes,
    points: [point],
    nextFollowUp: new Date(Date.now() + 3 * 86400000).toISOString(),
  };

  const list = readCases();
  writeCases([cropCase, ...list]);
  return { case: cropCase, kind: template.kind };
}

export function getCases(): CropCase[] {
  return readCases().sort((a, b) => new Date(b.diagnosedAt).getTime() - new Date(a.diagnosedAt).getTime());
}
export function getCase(id: string): CropCase | undefined {
  return readCases().find((c) => c.id === id);
}

function templateFor(crop: string, disease: string): DiagnosisTemplate | undefined {
  return (KNOWLEDGE_BASE[crop] ?? KNOWLEDGE_BASE[DEFAULT_CROP])?.find((t) => t.disease === disease);
}

/** Builds the organic/chemical treatment plan for a case's disease — used by /diagnosis. */
export function getTreatmentPlan(cropCase: CropCase, preference: TreatmentPreference): TreatmentPlan {
  const template = templateFor(cropCase.crop, cropCase.disease);
  const base = preference === "Organic" ? template?.organic : template?.chemical;
  return {
    preference,
    product: base?.product ?? "Consult local agriculture officer",
    quantity: base?.quantity ?? "As advised on-site",
    instructions: base?.instructions ?? [],
    safety: base?.safety ?? [],
    followUpDays: base?.followUpDays ?? [3, 7, 14],
  };
}

export function setTreatmentPreference(id: string, preference: TreatmentPreference) {
  const plan = getTreatmentPlan(getCase(id)!, preference);
  const list = readCases().map((c) => (c.id === id ? { ...c, treatmentPreference: preference, treatment: plan } : c));
  writeCases(list);
}

export function markExpertRequested(id: string) {
  writeCases(readCases().map((c) => (c.id === id ? { ...c, expertRequested: true } : c)));
}

/** Farmer uploads a follow-up photo — appends a SeverityPoint and records the product used since the last check. */
export function addFollowUp(id: string, severity: number, product?: ProductUsed) {
  const list = readCases();
  const target = list.find((c) => c.id === id);
  if (!target) return;
  const last = target.points[target.points.length - 1];
  const dayNumber = (last?.dayNumber ?? 0) + 1;
  const point: SeverityPoint = {
    date: new Date().toISOString(),
    dayNumber,
    severity,
    status: last ? compareSeverity(last.severity, severity) : undefined,
    productApplied: product,
  };
  const updated = list.map((c) => (c.id === id ? { ...c, severity, points: [...c.points, point], productsUsed: [...(c.productsUsed ?? []), ...(product ? [product] : [])] } : c));
  writeCases(updated);
}

/** Moves a resolved case into history (called once severity trends to "Better" and the farmer confirms it's resolved). */
export function resolveCase(id: string): HistoryCase | undefined {
  const list = readCases();
  const target = list.find((c) => c.id === id);
  if (!target) return undefined;
  const first = target.points[0]?.severity ?? target.severity;
  const finalSeverity = target.points[target.points.length - 1]?.severity ?? target.severity;
  const improvement = Math.max(0, Math.round(((first - finalSeverity) / Math.max(1, first)) * 100));
  const outcome: HistoryCase["outcome"] = finalSeverity <= 15 ? "Success" : finalSeverity < first ? "No Significant Change" : "Worsened";

  const historyCase: HistoryCase = {
    id: target.id,
    crop: target.crop,
    disease: target.disease,
    initialSeverity: first,
    finalSeverity,
    startDate: target.diagnosedAt,
    endDate: new Date().toISOString(),
    outcome,
    improvement,
    successRate: Math.max(0, 100 - finalSeverity),
    points: target.points,
    treatment: target.treatment,
    riskScore: target.riskScore,
    expertReferred: !!target.expertRequested,
    productsUsed: target.productsUsed,
  };

  writeHistory([historyCase, ...readHistory()]);
  writeCases(list.filter((c) => c.id !== id));
  return historyCase;
}

export function getHistoryCases(): HistoryCase[] {
  return readHistory().sort((a, b) => new Date(b.endDate).getTime() - new Date(a.endDate).getTime());
}
export function getHistoryCase(id: string): HistoryCase | undefined {
  return readHistory().find((c) => c.id === id);
}
