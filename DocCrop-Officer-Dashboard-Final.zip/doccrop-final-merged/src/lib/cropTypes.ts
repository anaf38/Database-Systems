export type FollowUpStatus = "Better" | "No Change" | "Worse";
export type Outcome = "Success" | "No Significant Change" | "Worsened";
export type TreatmentPreference = "Organic" | "Chemical";

export type ProductUsed = {
  name: string;
  type: "Pesticide" | "Fungicide" | "Fertilizer" | "Organic Input";
  dosage: string;
  appliedOn: string;
};

export type SeverityPoint = {
  date: string;
  dayNumber: number;
  severity: number;
  status?: FollowUpStatus;
  productApplied?: ProductUsed;
};

export type CropCase = {
  id: string;
  crop: string;
  disease: string;
  confidence: number;
  severity: number;
  riskScore: number;
  riskLevel: "Low" | "Medium" | "High";
  diagnosedAt: string;
  location: string;
  symptoms: string[];
  causes: string[];
  points: SeverityPoint[];
  treatmentPreference?: TreatmentPreference;
  treatment?: TreatmentPlan;
  expertRequested?: boolean;
  productsUsed?: ProductUsed[];
  nextFollowUp?: string;
};

export type TreatmentPlan = {
  preference: TreatmentPreference;
  product: string;
  quantity: string;
  instructions: string[];
  safety: string[];
  followUpDays: number[];
};

export type HistoryCase = {
  id: string;
  crop: string;
  disease: string;
  initialSeverity: number;
  finalSeverity: number;
  startDate: string;
  endDate: string;
  outcome: Outcome;
  improvement: number;
  successRate: number;
  points: SeverityPoint[];
  treatment?: TreatmentPlan;
  riskScore: number;
  expertReferred: boolean;
  productsUsed?: ProductUsed[];
};
