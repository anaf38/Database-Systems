import type {
  Product, Customer, Sale, Order, DealerAlert, DealerNotification, DealerProfile, DealerSettings,
} from "./dealerTypes";

export const demoProfile: DealerProfile = {
  shopId: "DEALER-MDU-1001",
  ownerName: "Ramesh Kumar",
  mobile: "9843012345",
  email: "ramesh.greenharvest@example.com",
  shopName: "Green Harvest Agro Centre",
  shopType: "Retail agri-input shop",
  address: "12, Main Bazaar Road",
  village: "Melur",
  district: "Madurai",
  state: "Tamil Nadu",
  pincode: "625106",
  registrationNumber: "TN-AGD-2018-4471",
  gstNumber: "33ABCDE1234F1Z5",
  yearsInBusiness: 8,
  categories: ["Seeds", "Fertilizers", "Pesticides", "Bio-products"],
  status: "Verified",
  openingHours: "8:00 AM – 8:00 PM",
  latitude: null,
  longitude: null,
  locationShared: false,
};

export const defaultSettings: DealerSettings = {
  language: "en",
  theme: "light",
  notifyLowStock: true,
  notifyExpiry: true,
  notifyOrders: true,
  notifySales: true,
  notifyAlerts: true,
  lowStockThreshold: null,
  expiryWarningDays: 30,
  hideCustomerInfo: false,
};

const crops = ["Rice", "Tomato", "Cotton", "Chilli", "Groundnut", "Banana", "Sugarcane", "Soybean", "Onion", "Sorghum"];
const villages = ["Melur", "Alanganallur", "Vadipatti", "Thiruparankundram", "Usilampatti", "Sholavandan"];

const productSeed: Array<[string, Product["category"], string, string, number, number, string]> = [
  ["Paddy Hybrid Seeds", "Seeds", "AgriGold", "Rice", 850, 20, "Rice"],
  ["Paddy Certified Seeds", "Seeds", "TNAU", "Rice", 640, 24, "Rice"],
  ["Tomato Hybrid Seeds", "Seeds", "Namdhari", "Tomato", 1450, 6, "Tomato"],
  ["Chilli Seeds", "Seeds", "VNR", "Chilli", 1200, 15, "Chilli"],
  ["Cotton Seeds", "Seeds", "Rasi", "Cotton", 780, 25, "Cotton"],
  ["Groundnut Seeds", "Seeds", "TNAU", "Groundnut", 95, 22, "Groundnut"],
  ["Onion Seeds", "Seeds", "Nunhems", "Onion", 2100, 8, "Onion"],
  ["Sorghum Seeds", "Seeds", "Mahyco", "Sorghum", 210, 18, "Sorghum"],
  ["Soybean Seeds", "Seeds", "TNAU", "Soybean", 95, 20, "Soybean"],
  ["Banana Tissue Culture Plantlets", "Seeds", "Jain Irrigation", "Banana", 28, 300, "Banana"],
  ["Urea Fertilizer", "Fertilizers", "IFFCO", "Rice", 266, 8, "Rice"],
  ["DAP Fertilizer", "Fertilizers", "IFFCO", "Cotton", 1350, 20, "Cotton"],
  ["Potash (MOP)", "Fertilizers", "IPL", "Sugarcane", 1700, 20, "Sugarcane"],
  ["Micronutrient Mixture", "Fertilizers", "Aries Agro", "Tomato", 480, 30, "Tomato"],
  ["Zinc Sulphate", "Fertilizers", "Coromandel", "Rice", 90, 40, "Rice"],
  ["Complex 19:19:19", "Fertilizers", "Coromandel", "Groundnut", 1280, 25, "Groundnut"],
  ["Single Super Phosphate", "Fertilizers", "IPL", "Onion", 420, 30, "Onion"],
  ["Neem Oil 1500 ppm", "Bio-products", "Godrej Agrovet", "Chilli", 320, 40, "Chilli"],
  ["Trichoderma Viride", "Bio-products", "Bio Green", "Rice", 180, 35, "Rice"],
  ["Pseudomonas Fluorescens", "Bio-products", "Bio Green", "Tomato", 190, 30, "Tomato"],
  ["Panchagavya Concentrate", "Bio-products", "Local Producer", "Sugarcane", 210, 20, "Sugarcane"],
  ["Rice Blast Fungicide", "Pesticides", "Syngenta", "Rice", 640, 12, "Rice"],
  ["Chilli Anthracnose Fungicide", "Pesticides", "Bayer", "Chilli", 720, 12, "Chilli"],
  ["Bio Fungicide (Trichoderma-based)", "Pesticides", "Bio Green", "Tomato", 340, 20, "Tomato"],
  ["Broad Spectrum Insecticide", "Pesticides", "UPL", "Cotton", 560, 15, "Cotton"],
  ["Aphid Control Spray", "Pesticides", "PI Industries", "Groundnut", 430, 18, "Groundnut"],
  ["Fruit Borer Pheromone Traps", "Pesticides", "Pest Control India", "Tomato", 45, 60, "Tomato"],
  ["Weedicide (Pre-emergent)", "Pesticides", "Bayer", "Sorghum", 610, 14, "Sorghum"],
  ["Sprayer (Knapsack 16L)", "Equipment", "Aspee", "Cotton", 2450, 6, "Cotton"],
  ["Power Weeder", "Equipment", "VST Tillers", "Sugarcane", 18500, 2, "Sugarcane"],
  ["Seed Drill (Manual)", "Equipment", "Local Manufacturer", "Sorghum", 3200, 3, "Sorghum"],
  ["Sticky Traps (Yellow, pack of 20)", "Equipment", "Pest Control India", "Onion", 260, 25, "Onion"],
  ["Drip Irrigation Kit (1 acre)", "Irrigation", "Jain Irrigation", "Banana", 12500, 4, "Banana"],
  ["Sprinkler Set", "Irrigation", "Netafim", "Groundnut", 4800, 5, "Groundnut"],
  ["Mulching Film (Roll)", "Irrigation", "Jain Irrigation", "Chilli", 1650, 10, "Chilli"],
];

function seededRand(seed: number) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function makeProducts(): Product[] {
  const rand = seededRand(7);
  return productSeed.map(([name, category, brand, crop, price, minStock, cropName], i) => {
    const stockRoll = rand();
    const stock = stockRoll < 0.12 ? Math.max(0, Math.round(minStock * 0.15))
      : stockRoll < 0.3 ? Math.round(minStock * (0.4 + rand() * 0.4))
      : Math.round(minStock * (1.2 + rand() * 3));
    const expiryOffsetDays = Math.round(-10 + rand() * 400);
    const expiry = new Date(Date.UTC(2026, 8, 9));
    expiry.setUTCDate(expiry.getUTCDate() + expiryOffsetDays);
    const purchasePrice = Math.round(price * 0.78);
    return {
      id: `PRD-${String(i + 1).padStart(3, "0")}`,
      name, category, brand,
      type: category === "Seeds" ? "Hybrid" : category === "Fertilizers" ? "Granular" : category === "Pesticides" ? "Spray" : category === "Bio-products" ? "Organic input" : category === "Equipment" ? "Tool" : "Irrigation kit",
      description: `${name} for ${cropName} cultivation. Standard ${brand} pack.`,
      unit: category === "Seeds" ? "kg" : category === "Fertilizers" ? "bag (50kg)" : category === "Equipment" || category === "Irrigation" ? "unit" : "litre",
      sellingPrice: price, purchasePrice,
      stock, minStock,
      batchNumber: `${category.slice(0, 4).toUpperCase()}-2026-${String((i % 6) + 1).padStart(2, "0")}`,
      manufactureDate: "2026-01-15",
      expiryDate: expiry.toISOString().slice(0, 10),
      supplier: `${brand} Distributors`,
      licenseRef: category === "Pesticides" ? `PEST-LIC-${1000 + i}` : category === "Seeds" ? `SEED-LIC-${1000 + i}` : "",
      active: true,
      crop,
      updatedAt: "2026-09-08T09:00:00.000Z",
    };
  });
}

const firstNames = ["Muthu", "Selvam", "Karthik", "Vijay", "Saravanan", "Murugan", "Palani", "Rajesh", "Anbu", "Kumaresan", "Suresh", "Balamurugan", "Elango", "Ravi", "Ganesan", "Manikandan", "Senthil", "Dinesh", "Sundar", "Arul"];

function makeCustomers(): Customer[] {
  const rand = seededRand(3);
  return firstNames.map((n, i) => ({
    id: `FARMER-${String(i + 1).padStart(3, "0")}`,
    name: `${n} ${["S", "R", "K", "M", "P"][i % 5]}.`,
    mobile: `98${400 + i}0${1000 + i}`.replace(/(\d{5})(\d+)/, "$1$2").slice(0, 10),
    village: villages[i % villages.length],
    crops: [crops[i % crops.length], crops[(i + 3) % crops.length]],
    outstanding: rand() < 0.25 ? Math.round(rand() * 3000) : 0,
    notes: rand() < 0.15 ? "Prefers organic/bio-products" : "",
  }));
}

function makeSales(products: Product[], customers: Customer[]): Sale[] {
  const rand = seededRand(11);
  const sales: Sale[] = [];
  for (let i = 0; i < 34; i++) {
    const cust = customers[i % customers.length];
    const p1 = products[Math.floor(rand() * products.length)];
    const p2 = products[Math.floor(rand() * products.length)];
    const qty1 = 1 + Math.floor(rand() * 4);
    const qty2 = rand() < 0.5 ? 1 + Math.floor(rand() * 3) : 0;
    const lines = qty2 ? [{ productId: p1.id, name: p1.name, qty: qty1, price: p1.sellingPrice }, { productId: p2.id, name: p2.name, qty: qty2, price: p2.sellingPrice }]
      : [{ productId: p1.id, name: p1.name, qty: qty1, price: p1.sellingPrice }];
    const subtotal = lines.reduce((s, l) => s + l.qty * l.price, 0);
    const discount = rand() < 0.2 ? Math.round(subtotal * 0.05) : 0;
    const tax = Math.round((subtotal - discount) * 0.05);
    const daysAgo = Math.floor(rand() * 30);
    const d = new Date(Date.UTC(2026, 8, 9)); d.setUTCDate(d.getUTCDate() - daysAgo);
    sales.push({
      id: `SALE-2026-${String(i + 1).padStart(4, "0")}`,
      date: d.toISOString().slice(0, 10),
      customerId: cust.id, customerName: cust.name,
      lines, subtotal, discount, tax, total: subtotal - discount + tax,
      paymentMethod: (["Cash", "UPI", "Card", "Credit"] as const)[Math.floor(rand() * 4)],
      paymentStatus: rand() < 0.85 ? "Paid" : "Pending",
    });
  }
  return sales.sort((a, b) => (a.date < b.date ? 1 : -1));
}

function makeOrders(products: Product[], customers: Customer[]): Order[] {
  const rand = seededRand(17);
  const statuses: Order["status"][] = ["New", "Accepted", "Preparing", "Ready for Pickup", "Delivered", "Delivered", "Cancelled"];
  const orders: Order[] = [];
  for (let i = 0; i < 17; i++) {
    const cust = customers[(i * 3) % customers.length];
    const p = products[Math.floor(rand() * products.length)];
    const qty = 1 + Math.floor(rand() * 3);
    const amount = qty * p.sellingPrice;
    const status = statuses[i % statuses.length];
    const daysAgo = Math.floor(rand() * 12);
    const d = new Date(Date.UTC(2026, 8, 9)); d.setUTCDate(d.getUTCDate() - daysAgo);
    const chain: Order["status"][] = ["New", "Accepted", "Preparing", "Ready for Pickup", "Delivered"];
    const idx = status === "Cancelled" ? 1 : chain.indexOf(status);
    const timeline = (status === "Cancelled" ? ["New", "Cancelled"] : chain.slice(0, idx + 1)).map((s, si) => ({
      status: s as Order["status"], at: new Date(d.getTime() + si * 3600_000).toISOString(),
    }));
    orders.push({
      id: `ORDER-2026-${String(i + 81).padStart(4, "0")}`,
      customerId: cust.id, customerName: cust.name,
      date: d.toISOString().slice(0, 10),
      lines: [{ productId: p.id, name: p.name, qty, price: p.sellingPrice }],
      amount, paymentStatus: rand() < 0.7 ? "Paid" : "Pending",
      status, timeline,
    });
  }
  return orders.sort((a, b) => (a.date < b.date ? 1 : -1));
}

export function makeAlerts(): DealerAlert[] {
  const base: Array<[string, string, string, DealerAlert["risk"], DealerAlert["kind"], DealerAlert["productCategories"], string]> = [
    ["Rice Leaf Blast reported around Melur", "Rice", "Melur", "HIGH", "Disease", ["Pesticides", "Bio-products"], "Refer affected farmers to the Agriculture Officer for field verification."],
    ["Chilli Anthracnose risk rising", "Chilli", "Alanganallur", "MODERATE", "Disease", ["Pesticides"], "Advise farmers to scout fields; confirm with officer before treatment."],
    ["Fall Armyworm activity in maize/sorghum belt", "Sorghum", "Vadipatti", "HIGH", "Pest", ["Pesticides", "Equipment"], "Recommend pheromone traps; escalate confirmed sightings to officer."],
    ["Cotton bollworm pressure increasing", "Cotton", "Usilampatti", "MODERATE", "Pest", ["Pesticides"], "Monitor stock of approved insecticides; refer heavy infestations."],
    ["Heavy rainfall forecast — waterlogging risk", "Paddy", "Thiruparankundram", "MODERATE", "Weather", ["Equipment", "Irrigation"], "Inform farmers about drainage and fungal risk after rain."],
    ["Groundnut leaf spot advisory issued", "Groundnut", "Sholavandan", "LOW", "Advisory", ["Bio-products", "Pesticides"], "General advisory circulated by Agriculture Department."],
    ["Tomato bacterial wilt cases under monitoring", "Tomato", "Melur", "MODERATE", "Disease", ["Bio-products"], "Officer investigation ongoing; avoid unverified chemical claims."],
    ["Onion thrips outbreak watch", "Onion", "Alanganallur", "HIGH", "Pest", ["Pesticides", "Equipment"], "Sticky traps recommended; refer severe cases to officer."],
    ["Sugarcane red rot advisory", "Sugarcane", "Vadipatti", "LOW", "Advisory", ["Bio-products"], "Preventive advisory — no confirmed outbreak yet."],
    ["Banana bunchy top monitoring zone extended", "Banana", "Usilampatti", "MODERATE", "Disease", ["Bio-products"], "Refer suspected cases; do not sell unapproved remedies."],
  ];
  return base.map(([title, crop, area, risk, kind, cats, advice], i) => ({
    id: `ALERT-${String(i + 1).padStart(3, "0")}`, title, crop, area, risk, kind, productCategories: cats, advice,
    createdAt: new Date(Date.UTC(2026, 8, 9 - i)).toISOString(),
  }));
}

function makeNotifications(): DealerNotification[] {
  const items: Array<[string, string, DealerNotification["kind"]]> = [
    ["Chilli Seeds stock is critically low", "Only 5 packets left, minimum stock is 15.", "inventory"],
    ["Order ORDER-2026-0081 has been accepted", "You accepted this order for Muthu S.", "orders"],
    ["Rice Leaf Blast alert updated for Melur", "Risk level changed to HIGH.", "alerts"],
    ["5 products are approaching expiry", "Review the expiring products list.", "inventory"],
    ["Sale SALE-2026-0042 recorded", "₹4,250 received via UPI.", "sales"],
    ["New order received", "ORDER-2026-0089 placed by Selvam R.", "orders"],
    ["Urea Fertilizer stock is low", "8 bags left, minimum stock is 20.", "inventory"],
    ["Paddy Seeds stock is low", "12 packets left, minimum stock is 30.", "inventory"],
    ["Monthly sales report ready", "Your August sales report has been generated.", "system"],
    ["Fall Armyworm pest alert near Vadipatti", "High risk reported for sorghum belt.", "alerts"],
    ["Order ORDER-2026-0085 delivered", "Marked delivered to Karthik K.", "orders"],
    ["Payment pending on SALE-2026-0031", "₹1,200 credit sale still pending.", "sales"],
    ["Referral submitted to Agriculture Officer", "Farmer referral for Vijay M. is pending review.", "system"],
    ["Groundnut Seeds restocked", "Stock updated to 96 kg.", "inventory"],
    ["New order received", "ORDER-2026-0092 placed by Ganesan P.", "orders"],
    ["Onion thrips outbreak watch issued", "Alert affects Alanganallur.", "alerts"],
    ["Sale SALE-2026-0018 recorded", "₹2,890 received in cash.", "sales"],
    ["System maintenance scheduled", "Brief downtime expected this weekend.", "system"],
    ["Trichoderma Viride approaching expiry", "Batch BIO-2026-03 expires in 18 days.", "inventory"],
    ["Order ORDER-2026-0083 ready for pickup", "Notify Rajesh M. for collection.", "orders"],
  ];
  return items.map(([title, body, kind], i) => ({
    id: `NOTIF-${String(i + 1).padStart(3, "0")}`, title, body, kind,
    read: i > 6, archived: false,
    createdAt: new Date(Date.UTC(2026, 8, 9, 12 - i)).toISOString(),
  }));
}

export const seedProducts = makeProducts();
export const seedCustomers = makeCustomers();
export const seedSales = makeSales(seedProducts, seedCustomers);
export const seedOrders = makeOrders(seedProducts, seedCustomers);
export const seedAlerts = makeAlerts();
export const seedNotifications = makeNotifications();
