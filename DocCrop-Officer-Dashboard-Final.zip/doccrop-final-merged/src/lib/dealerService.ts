import { dealers } from "./farmData";
import {
  demoProfile, defaultSettings, seedProducts, seedCustomers, seedSales, seedOrders, seedAlerts, seedNotifications,
} from "./dealerData";
import type {
  Product, Customer, Sale, Order, OrderStatus, DealerAlert, Referral, ReferralStatus, DealerNotification, DealerNotifKind,
  DealerProfile, DealerSettings, DealerAuth, SaleLine, PaymentMethod, StockStatus,
} from "./dealerTypes";

// Farmer-facing "nearby dealers" list (unrelated to the shop-owner module below).
export function getNearbyDealers() { return dealers; }

const KEYS = {
  auth: "doccropDealerAuth",
  profile: "doccropDealerProfile",
  products: "doccropDealerProducts",
  sales: "doccropDealerSales",
  orders: "doccropDealerOrders",
  customers: "doccropDealerCustomers",
  notifications: "doccropDealerNotifications",
  settings: "doccropDealerSettings",
  referrals: "doccropDealerReferrals",
  alerts: "doccropDealerAlerts",
} as const;

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event("doccrop-dealer"));
}

function ensureSeeded() {
  if (typeof window === "undefined") return;
  if (!window.localStorage.getItem(KEYS.products)) write(KEYS.products, seedProducts);
  if (!window.localStorage.getItem(KEYS.customers)) write(KEYS.customers, seedCustomers);
  if (!window.localStorage.getItem(KEYS.sales)) write(KEYS.sales, seedSales);
  if (!window.localStorage.getItem(KEYS.orders)) write(KEYS.orders, seedOrders);
  if (!window.localStorage.getItem(KEYS.alerts)) write(KEYS.alerts, seedAlerts);
  if (!window.localStorage.getItem(KEYS.notifications)) write(KEYS.notifications, seedNotifications);
  if (!window.localStorage.getItem(KEYS.profile)) write(KEYS.profile, demoProfile);
  if (!window.localStorage.getItem(KEYS.settings)) write(KEYS.settings, defaultSettings);
}

// ---------- Auth ----------
export const DEMO_SHOP_ID = "DEALER-MDU-1001";
export const DEMO_PASSWORD = "demo123";

export function dealerLogin(idOrMobileOrEmail: string, password: string): { ok: true } | { ok: false; error: string } {
  ensureSeeded();
  const profile = getDealerProfile();
  const idMatch = idOrMobileOrEmail.trim().toUpperCase() === profile.shopId
    || idOrMobileOrEmail.trim() === profile.mobile
    || idOrMobileOrEmail.trim().toLowerCase() === profile.email.toLowerCase();
  if (!idMatch || password !== DEMO_PASSWORD) return { ok: false, error: "Invalid shop ID or password." };
  write(KEYS.auth, { shopId: profile.shopId, loggedInAt: new Date().toISOString() });
  return { ok: true };
}

export function dealerLogout() {
  write(KEYS.auth, null);
}

export function getDealerAuth(): DealerAuth {
  return read<DealerAuth>(KEYS.auth, null);
}

export function isDealerAuthenticated(): boolean {
  return getDealerAuth() !== null;
}

export function registerDealer(input: Partial<DealerProfile> & { password?: string }): DealerProfile {
  ensureSeeded();
  const profile: DealerProfile = {
    ...demoProfile,
    ...input,
    shopId: demoProfile.shopId,
    status: "Verification Pending",
  };
  write(KEYS.profile, profile);
  write(KEYS.auth, { shopId: profile.shopId, loggedInAt: new Date().toISOString() });
  return profile;
}

// ---------- Profile ----------
export function getDealerProfile(): DealerProfile {
  ensureSeeded();
  return read<DealerProfile>(KEYS.profile, demoProfile);
}
export function updateDealerProfile(patch: Partial<DealerProfile>): DealerProfile {
  const next = { ...getDealerProfile(), ...patch };
  write(KEYS.profile, next);
  return next;
}
export function updateDealerLocation(input: { latitude: number; longitude: number; village?: string }): DealerProfile {
  const patch: Partial<DealerProfile> = { latitude: input.latitude, longitude: input.longitude, locationShared: true };
  if (input.village) patch.village = input.village;
  const next = updateDealerProfile(patch);
  createNotification({ title: "Shop location updated", body: "Your shop's location is now visible to nearby farmers on the map.", kind: "system" });
  return next;
}

// ---------- Products ----------
export function getProducts(): Product[] {
  ensureSeeded();
  return read<Product[]>(KEYS.products, seedProducts);
}
export function getProductById(id: string): Product | undefined {
  return getProducts().find((p) => p.id === id);
}
export function stockStatus(p: Pick<Product, "stock" | "minStock">): StockStatus {
  if (p.stock <= 0) return "Out of Stock";
  if (p.stock < p.minStock * 0.5) return "Critical";
  if (p.stock < p.minStock) return "Low Stock";
  return "In Stock";
}
export function isExpiringSoon(expiryDate: string, withinDays = 30): boolean {
  const days = Math.ceil((new Date(expiryDate).getTime() - new Date("2026-09-09").getTime()) / 86_400_000);
  return days >= 0 && days <= withinDays;
}
export function daysToExpiry(expiryDate: string): number {
  return Math.ceil((new Date(expiryDate).getTime() - new Date("2026-09-09").getTime()) / 86_400_000);
}
export function addProduct(input: Omit<Product, "id" | "active" | "updatedAt">): Product {
  const list = getProducts();
  const product: Product = { ...input, id: `PRD-${String(list.length + 1).padStart(3, "0")}-${Date.now().toString().slice(-4)}`, active: true, updatedAt: new Date().toISOString() };
  write(KEYS.products, [product, ...list]);
  createNotification({ title: "Product added", body: `${product.name} added to your catalogue.`, kind: "inventory" });
  return product;
}
export function updateProduct(id: string, patch: Partial<Product>): Product | undefined {
  const list = getProducts();
  const idx = list.findIndex((p) => p.id === id);
  if (idx === -1) return undefined;
  const next = { ...list[idx], ...patch, updatedAt: new Date().toISOString() };
  const updated = [...list]; updated[idx] = next;
  write(KEYS.products, updated);
  return next;
}
export function deactivateProduct(id: string): void {
  updateProduct(id, { active: false });
}
export function updateStock(id: string, delta: number, meta?: { supplier?: string; purchasePrice?: number; batchNumber?: string; expiryDate?: string; reason?: string }): Product | undefined {
  const p = getProductById(id);
  if (!p) return undefined;
  const nextStock = Math.max(0, p.stock + delta);
  const patch: Partial<Product> = { stock: nextStock };
  if (delta > 0) {
    if (meta?.supplier) patch.supplier = meta.supplier;
    if (meta?.purchasePrice) patch.purchasePrice = meta.purchasePrice;
    if (meta?.batchNumber) patch.batchNumber = meta.batchNumber;
    if (meta?.expiryDate) patch.expiryDate = meta.expiryDate;
  }
  const updated = updateProduct(id, patch);
  const status = updated ? stockStatus(updated) : "In Stock";
  if (updated && (status === "Low Stock" || status === "Critical" || status === "Out of Stock")) {
    createNotification({ title: `${updated.name} stock is ${status.toLowerCase()}`, body: `${updated.stock} ${updated.unit} left, minimum stock is ${updated.minStock}.`, kind: "inventory" });
  }
  return updated;
}

// ---------- Sales ----------
export function getSales(): Sale[] {
  ensureSeeded();
  return read<Sale[]>(KEYS.sales, seedSales);
}
export function getSaleById(id: string): Sale | undefined {
  return getSales().find((s) => s.id === id);
}
export function createSale(input: { customerId: string; lines: SaleLine[]; discount: number; paymentMethod: PaymentMethod; paymentStatus: "Paid" | "Pending" }): Sale {
  const list = getSales();
  const customer = getCustomerById(input.customerId);
  const subtotal = input.lines.reduce((s, l) => s + l.qty * l.price, 0);
  const tax = Math.round((subtotal - input.discount) * 0.05);
  const sale: Sale = {
    id: `SALE-2026-${String(list.length + 1).padStart(4, "0")}`,
    date: new Date().toISOString().slice(0, 10),
    customerId: input.customerId, customerName: customer?.name ?? "Walk-in customer",
    lines: input.lines, subtotal, discount: input.discount, tax,
    total: subtotal - input.discount + tax,
    paymentMethod: input.paymentMethod, paymentStatus: input.paymentStatus,
  };
  write(KEYS.sales, [sale, ...list]);
  input.lines.forEach((l) => updateStock(l.productId, -l.qty, { reason: "Sale" }));
  createNotification({ title: `Sale ${sale.id} recorded successfully`, body: `₹${sale.total.toLocaleString("en-IN")} via ${sale.paymentMethod}.`, kind: "sales" });
  return sale;
}

// ---------- Orders ----------
export function getOrders(): Order[] {
  ensureSeeded();
  return read<Order[]>(KEYS.orders, seedOrders);
}
export function getOrderById(id: string): Order | undefined {
  return getOrders().find((o) => o.id === id);
}
const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  "New": ["Accepted", "Cancelled"],
  "Accepted": ["Preparing", "Cancelled"],
  "Preparing": ["Ready for Pickup", "Cancelled"],
  "Ready for Pickup": ["Delivered", "Cancelled"],
  "Delivered": [],
  "Cancelled": [],
};
export function nextOrderStatuses(status: OrderStatus): OrderStatus[] {
  return ORDER_TRANSITIONS[status];
}
export function updateOrderStatus(id: string, status: OrderStatus): Order | undefined {
  const list = getOrders();
  const idx = list.findIndex((o) => o.id === id);
  if (idx === -1) return undefined;
  const order = list[idx];
  if (!ORDER_TRANSITIONS[order.status].includes(status)) return order;
  const next: Order = { ...order, status, timeline: [...order.timeline, { status, at: new Date().toISOString() }] };
  if (status === "Delivered") next.paymentStatus = order.paymentStatus === "Pending" ? "Pending" : "Paid";
  const updated = [...list]; updated[idx] = next;
  write(KEYS.orders, updated);
  createNotification({ title: `Order ${id} has been ${status.toLowerCase()}`, body: `Status updated for ${order.customerName}.`, kind: "orders" });
  return next;
}

// ---------- Customers ----------
export function getCustomers(): Customer[] {
  ensureSeeded();
  return read<Customer[]>(KEYS.customers, seedCustomers);
}
export function getCustomerById(id: string): Customer | undefined {
  return getCustomers().find((c) => c.id === id);
}
export function getCustomerPurchaseHistory(id: string): { sales: Sale[]; orders: Order[] } {
  return { sales: getSales().filter((s) => s.customerId === id), orders: getOrders().filter((o) => o.customerId === id) };
}

// ---------- Agricultural alerts ----------
export function getAgriculturalAlerts(): DealerAlert[] {
  if (typeof window !== "undefined" && !window.localStorage.getItem(KEYS.alerts)) write(KEYS.alerts, seedAlerts);
  return read<DealerAlert[]>(KEYS.alerts, seedAlerts);
}
export function getAlertById(id: string): DealerAlert | undefined {
  return getAgriculturalAlerts().find((a) => a.id === id);
}
export function createFarmerReferral(input: Omit<Referral, "id" | "status" | "createdAt" | "dealerShopName">): Referral {
  const list = read<Referral[]>(KEYS.referrals, []);
  const referral: Referral = { ...input, dealerShopName: getDealerProfile().shopName, id: `REF-${Date.now()}`, status: "Pending Officer Review", createdAt: new Date().toISOString() };
  write(KEYS.referrals, [referral, ...list]);
  createNotification({ title: "Farmer referral submitted", body: `Referral for ${referral.farmerName} sent to the Agriculture Officer.`, kind: "system" });
  return referral;
}
export function getFarmerReferrals(): Referral[] {
  return read<Referral[]>(KEYS.referrals, []);
}
export function getReferralById(id: string): Referral | undefined {
  return getFarmerReferrals().find((r) => r.id === id);
}
export function updateReferralStatus(id: string, status: ReferralStatus): Referral | undefined {
  const list = getFarmerReferrals();
  const idx = list.findIndex((r) => r.id === id);
  if (idx === -1) return undefined;
  const next = { ...list[idx], status };
  const updated = [...list]; updated[idx] = next;
  write(KEYS.referrals, updated);
  const messages: Partial<Record<ReferralStatus, { title: string; body: string }>> = {
    "Reviewed": { title: "Officer reviewed your referral", body: `The Agriculture Officer has reviewed the referral for ${next.farmerName} (${next.crop}).` },
    "Field Visit Scheduled": { title: "Field visit scheduled", body: `The Agriculture Officer has scheduled a field visit for ${next.farmerName} (${next.crop}) at ${next.location}.` },
    "Dismissed": { title: "Referral dismissed by officer", body: `The Agriculture Officer dismissed the referral for ${next.farmerName} — no field visit needed.` },
  };
  const msg = messages[status];
  if (msg) createNotification({ ...msg, kind: "referral" });
  return next;
}
export function pendingReferralCount(): number {
  return getFarmerReferrals().filter((r) => r.status === "Pending Officer Review").length;
}

// ---------- Notifications ----------
export function getNotifications(): DealerNotification[] {
  ensureSeeded();
  return read<DealerNotification[]>(KEYS.notifications, seedNotifications);
}
export function createNotification(input: { title: string; body: string; kind: DealerNotifKind }): DealerNotification {
  const list = read<DealerNotification[]>(KEYS.notifications, seedNotifications);
  const n: DealerNotification = { ...input, id: `NOTIF-${Date.now()}`, read: false, archived: false, createdAt: new Date().toISOString() };
  write(KEYS.notifications, [n, ...list]);
  return n;
}
function patchNotification(id: string, patch: Partial<DealerNotification>) {
  const list = getNotifications();
  write(KEYS.notifications, list.map((n) => (n.id === id ? { ...n, ...patch } : n)));
}
export function markNotificationRead(id: string) { patchNotification(id, { read: true }); }
export function markNotificationUnread(id: string) { patchNotification(id, { read: false }); }
export function archiveNotification(id: string) { patchNotification(id, { archived: true }); }
export function markAllNotificationsRead() {
  write(KEYS.notifications, getNotifications().map((n) => ({ ...n, read: true })));
}
export function unreadNotificationCount(): number {
  return getNotifications().filter((n) => !n.read && !n.archived).length;
}

// ---------- Settings ----------
export function getDealerSettings(): DealerSettings {
  ensureSeeded();
  return read<DealerSettings>(KEYS.settings, defaultSettings);
}
export function updateDealerSettings(patch: Partial<DealerSettings>): DealerSettings {
  const next = { ...getDealerSettings(), ...patch };
  write(KEYS.settings, next);
  return next;
}
export function resetDealerSettings(): DealerSettings {
  write(KEYS.settings, defaultSettings);
  return defaultSettings;
}

// ---------- Dashboard aggregates ----------
export function getDashboardStats() {
  const products = getProducts().filter((p) => p.active);
  const sales = getSales();
  const orders = getOrders();
  const customers = getCustomers();
  const today = "2026-09-09";
  const monthPrefix = "2026-09";
  const todaySales = sales.filter((s) => s.date === today).reduce((s, x) => s + x.total, 0);
  const monthlySales = sales.filter((s) => s.date.startsWith(monthPrefix)).reduce((s, x) => s + x.total, 0);
  const lowStock = products.filter((p) => { const s = stockStatus(p); return s === "Low Stock" || s === "Critical"; });
  const expiring = products.filter((p) => isExpiringSoon(p.expiryDate, 30));
  const productsSold = sales.reduce((sum, s) => sum + s.lines.reduce((a, l) => a + l.qty, 0), 0);
  return {
    totalProducts: products.length,
    lowStockCount: lowStock.length,
    todaySales,
    monthlySales,
    pendingOrders: orders.filter((o) => o.status === "New" || o.status === "Accepted" || o.status === "Preparing" || o.status === "Ready for Pickup").length,
    activeCustomers: customers.length,
    productsSold,
    expiringCount: expiring.length,
    lowStockItems: lowStock,
    expiringItems: expiring,
  };
}

export function weeklySalesSeries() {
  const sales = getSales();
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const start = new Date("2026-09-07"); // Monday of current week
  return days.map((label, i) => {
    const d = new Date(start); d.setUTCDate(start.getUTCDate() + i);
    const key = d.toISOString().slice(0, 10);
    return { label, value: sales.filter((s) => s.date === key).reduce((sum, s) => sum + s.total, 0) };
  });
}

export function categoryDistribution() {
  const products = getProducts().filter((p) => p.active);
  const cats = ["Seeds", "Fertilizers", "Pesticides", "Bio-products", "Equipment", "Irrigation"] as const;
  return cats.map((c) => ({ name: c, value: products.filter((p) => p.category === c).length }));
}
