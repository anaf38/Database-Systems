// Types for the Shop Owner / Agricultural Input Dealer module.
// Prototype/demo module — mock data + localStorage only, no backend.

export type ProductCategory = "Seeds" | "Fertilizers" | "Pesticides" | "Bio-products" | "Equipment" | "Irrigation";
export type StockStatus = "In Stock" | "Low Stock" | "Critical" | "Out of Stock";

export type Product = {
  id: string;
  name: string;
  category: ProductCategory;
  brand: string;
  type: string;
  description: string;
  unit: string;
  sellingPrice: number;
  purchasePrice: number;
  stock: number;
  minStock: number;
  batchNumber: string;
  manufactureDate: string;
  expiryDate: string;
  supplier: string;
  licenseRef: string;
  active: boolean;
  crop: string;
  updatedAt: string;
};

export type Customer = {
  id: string;
  name: string;
  mobile: string;
  village: string;
  crops: string[];
  outstanding: number;
  notes: string;
};

export type SaleLine = { productId: string; name: string; qty: number; price: number };
export type PaymentMethod = "Cash" | "UPI" | "Card" | "Credit";
export type Sale = {
  id: string;
  date: string;
  customerId: string;
  customerName: string;
  lines: SaleLine[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: "Paid" | "Pending";
};

export type OrderStatus = "New" | "Accepted" | "Preparing" | "Ready for Pickup" | "Delivered" | "Cancelled";
export type Order = {
  id: string;
  customerId: string;
  customerName: string;
  date: string;
  lines: SaleLine[];
  amount: number;
  paymentStatus: "Paid" | "Pending";
  status: OrderStatus;
  timeline: { status: OrderStatus; at: string }[];
};

export type AlertRisk = "LOW" | "MODERATE" | "HIGH";
export type DealerAlert = {
  id: string;
  title: string;
  crop: string;
  area: string;
  risk: AlertRisk;
  kind: "Disease" | "Pest" | "Weather" | "Advisory";
  productCategories: ProductCategory[];
  advice: string;
  createdAt: string;
};

export type ReferralStatus = "Pending Officer Review" | "Reviewed" | "Field Visit Scheduled" | "Dismissed";
export type Referral = {
  id: string;
  farmerName: string;
  crop: string;
  issue: string;
  location: string;
  notes: string;
  dealerShopName: string;
  status: ReferralStatus;
  createdAt: string;
};

export type DealerNotifKind = "orders" | "inventory" | "sales" | "alerts" | "referral" | "system";
export type DealerNotification = {
  id: string;
  title: string;
  body: string;
  kind: DealerNotifKind;
  read: boolean;
  archived: boolean;
  createdAt: string;
};

export type DealerProfile = {
  shopId: string;
  ownerName: string;
  mobile: string;
  email: string;
  shopName: string;
  shopType: string;
  address: string;
  village: string;
  district: string;
  state: string;
  pincode: string;
  registrationNumber: string;
  gstNumber: string;
  yearsInBusiness: number;
  categories: ProductCategory[];
  status: "Verification Pending" | "Verified";
  openingHours: string;
  latitude: number | null;
  longitude: number | null;
  locationShared: boolean;
};

export type DealerSettings = {
  language: "en" | "ta" | "hi" | "te" | "kn" | "ml";
  theme: "light" | "dark" | "system";
  notifyLowStock: boolean;
  notifyExpiry: boolean;
  notifyOrders: boolean;
  notifySales: boolean;
  notifyAlerts: boolean;
  lowStockThreshold: number | null;
  expiryWarningDays: number;
  hideCustomerInfo: boolean;
};

export type DealerAuth = { shopId: string; loggedInAt: string } | null;
