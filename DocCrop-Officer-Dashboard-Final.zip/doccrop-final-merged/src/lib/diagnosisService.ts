import type { CropCase } from "./cropTypes";
import { activeCases } from "./farmData";

export async function analyzeCropImage(file: File, crop = "Soybean"): Promise<Pick<CropCase, "disease" | "confidence" | "severity" | "riskScore" | "riskLevel" | "symptoms" | "causes">> {
  // Frontend contract for the future Python ML API (OpenCV + MobileNetV2/YOLO + severity model).
  // The current implementation is a deterministic demo adapter, not a claim that ML runs in-browser.
  await new Promise((r) => setTimeout(r, 900));
  const base = activeCases.find((c) => c.crop === crop) ?? activeCases[0];
  return { disease: base.disease, confidence: base.confidence, severity: base.severity, riskScore: base.riskScore, riskLevel: base.riskLevel, symptoms: base.symptoms, causes: base.causes };
}
