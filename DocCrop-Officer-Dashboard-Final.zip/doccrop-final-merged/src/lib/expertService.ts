export type ExpertRequest = { id: string; crop: string; disease: string; severity: number; status: "Pending" | "Assigned" | "Reviewed"; createdAt: string };
const KEY = "doccrop.expertRequests";
export function createExpertRequest(input: Omit<ExpertRequest, "id" | "createdAt" | "status">): ExpertRequest {
  const item: ExpertRequest = { ...input, id: `er-${Date.now()}`, status: "Pending", createdAt: new Date().toISOString() };
  const list = JSON.parse(localStorage.getItem(KEY) ?? "[]") as ExpertRequest[];
  localStorage.setItem(KEY, JSON.stringify([item, ...list]));
  return item;
}
export function getExpertRequests(): ExpertRequest[] { return JSON.parse(localStorage.getItem(KEY) ?? "[]") as ExpertRequest[]; }
