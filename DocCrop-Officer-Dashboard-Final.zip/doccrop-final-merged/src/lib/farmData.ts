import type { CropCase, HistoryCase } from "./cropTypes";

export type Severity = "Mild" | "Moderate" | "Severe";
export type Trend = "Improving" | "No change" | "Worse";
export type FollowUpPoint = { date: string; score: number; risk: "Low" | "Medium" | "High" };

export const activeCases: CropCase[] = [
  {
    id: "c1",
    crop: "Soybean",
    disease: "Soybean rust",
    confidence: 94,
    severity: 42,
    riskScore: 72,
    riskLevel: "High",
    diagnosedAt: "2026-09-04T08:10:00+05:30",
    location: "Wardha, Maharashtra",
    symptoms: ["Orange-brown rust spots", "Early leaf yellowing", "Lower leaves affected"],
    causes: ["Warm humid weather", "Long leaf-wetness period", "Previous rust history"],
    points: [
      { date: "2026-09-04", dayNumber: 1, severity: 42 },
      {
        date: "2026-09-06",
        dayNumber: 3,
        severity: 58,
        status: "Worse",
        productApplied: { name: "Hexaconazole 5% EC", type: "Fungicide", dosage: "2 ml / litre water, foliar spray", appliedOn: "2026-09-06" },
      },
      { date: "2026-09-08", dayNumber: 5, severity: 71, status: "Worse" },
    ],
    productsUsed: [
      { name: "Hexaconazole 5% EC", type: "Fungicide", dosage: "2 ml / litre water, foliar spray", appliedOn: "2026-09-06" },
      { name: "DAP (18:46:0)", type: "Fertilizer", dosage: "25 kg / acre, basal top-up", appliedOn: "2026-09-05" },
    ],
    nextFollowUp: "in 2 days",
  },
  {
    id: "c2",
    crop: "Cotton",
    disease: "Pink bollworm",
    confidence: 88,
    severity: 43,
    riskScore: 68,
    riskLevel: "High",
    diagnosedAt: "2026-09-01T18:40:00+05:30",
    location: "Wardha, Maharashtra",
    symptoms: ["Boll damage", "Larval feeding signs", "Flower/boll shedding"],
    causes: ["Pest pressure", "Moth activity nearby"],
    points: [
      { date: "2026-09-01", dayNumber: 1, severity: 38 },
      {
        date: "2026-09-04",
        dayNumber: 4,
        severity: 41,
        status: "No Change",
        productApplied: { name: "Neem oil 1500 ppm", type: "Organic Input", dosage: "5 ml / litre water, evening spray", appliedOn: "2026-09-04" },
      },
      { date: "2026-09-07", dayNumber: 7, severity: 40, status: "Better" },
    ],
    productsUsed: [
      { name: "Neem oil 1500 ppm", type: "Organic Input", dosage: "5 ml / litre water, evening spray", appliedOn: "2026-09-04" },
      { name: "Pheromone traps (PBW)", type: "Pesticide", dosage: "5 traps / acre", appliedOn: "2026-09-01" },
    ],
    nextFollowUp: "today",
  },
];

export const historyCases: HistoryCase[] = [
  {
    id: "h1",
    crop: "Soybean",
    disease: "Yellow mosaic",
    initialSeverity: 78,
    finalSeverity: 18,
    startDate: "2026-08-12",
    endDate: "2026-08-26",
    outcome: "Success",
    improvement: 60,
    successRate: 92,
    riskScore: 66,
    expertReferred: false,
    points: [
      { date: "2026-08-12", dayNumber: 1, severity: 78 },
      {
        date: "2026-08-14",
        dayNumber: 3,
        severity: 61,
        status: "Better",
        productApplied: { name: "Imidacloprid 17.8% SL", type: "Pesticide", dosage: "0.5 ml / litre water, whitefly vector control", appliedOn: "2026-08-14" },
      },
      {
        date: "2026-08-19",
        dayNumber: 8,
        severity: 35,
        status: "Better",
        productApplied: { name: "19:19:19 NPK", type: "Fertilizer", dosage: "2 g / litre water, foliar feed", appliedOn: "2026-08-18" },
      },
      { date: "2026-08-26", dayNumber: 14, severity: 18, status: "Better" },
    ],
    productsUsed: [
      { name: "Imidacloprid 17.8% SL", type: "Pesticide", dosage: "0.5 ml / litre water, whitefly vector control", appliedOn: "2026-08-14" },
      { name: "19:19:19 NPK", type: "Fertilizer", dosage: "2 g / litre water, foliar feed", appliedOn: "2026-08-18" },
    ],
  },
  {
    id: "h2",
    crop: "Cotton",
    disease: "Jassid attack",
    initialSeverity: 42,
    finalSeverity: 67,
    startDate: "2026-07-22",
    endDate: "2026-08-02",
    outcome: "Worsened",
    improvement: -25,
    successRate: 31,
    riskScore: 81,
    expertReferred: true,
    points: [
      { date: "2026-07-22", dayNumber: 1, severity: 42 },
      {
        date: "2026-07-25",
        dayNumber: 4,
        severity: 51,
        status: "Worse",
        productApplied: { name: "Acetamiprid 20% SP", type: "Pesticide", dosage: "0.4 g / litre water, sucking pest control", appliedOn: "2026-07-25" },
      },
      { date: "2026-08-02", dayNumber: 12, severity: 67, status: "Worse" },
    ],
    productsUsed: [
      { name: "Acetamiprid 20% SP", type: "Pesticide", dosage: "0.4 g / litre water, sucking pest control", appliedOn: "2026-07-25" },
    ],
  },
];

export const dealers = [
  { name: "Shree Krishi Kendra", owner: "Sanjay Patil", distance: "1.8 km", phone: "9876543210", stock: ["Trichoderma viride", "Neem oil 1500 ppm"] },
  { name: "Wardha Agro Agency", owner: "Nilesh Rathod", distance: "4.2 km", phone: "9765432108", stock: ["Bio-control products", "Sticky traps"] },
];

export const riskNotifications = [
  { id: "n1", kind: "risk" as const, title: "High rust risk in 48 hours", body: "Humidity and leaf wetness are favorable for rust spread. Scout the lower canopy.", severity: "Severe" as Severity, time: "20 min ago", factors: ["Humidity", "Leaf wetness", "Rust history"] },
  { id: "n2", kind: "followup" as const, title: "Follow-up photo due", body: "Upload a fresh crop photo so DocCrop can compare treatment progress.", severity: "Mild" as Severity, time: "Today", factors: ["Follow-up", "Severity comparison"] },
];
