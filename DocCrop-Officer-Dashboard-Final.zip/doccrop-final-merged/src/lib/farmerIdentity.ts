// Single shared "current farmer" identity for this prototype.
// The app only has one farmer persona (see profile.tsx), so officer-side mock
// hotspot data includes this exact name to demonstrate the officer -> farmer
// notification loop end-to-end without needing real multi-user accounts.

export const CURRENT_FARMER_NAME = "Ramesh Deshmukh";
export const CURRENT_FARMER_LOCATION = "Wardha, Maharashtra";
