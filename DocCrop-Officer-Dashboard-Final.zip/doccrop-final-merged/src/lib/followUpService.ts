import type { FollowUpStatus, SeverityPoint } from "./cropTypes";
import { compareSeverity } from "./severityService";
export function createFollowUp(previous: SeverityPoint, date: string, severity: number): SeverityPoint & { status: FollowUpStatus } {
  const previousDate = new Date(previous.date);
  const currentDate = new Date(date);
  const dayNumber = Math.max(1, Math.round((currentDate.getTime() - previousDate.getTime()) / 86400000) + previous.dayNumber);
  return { date, dayNumber, severity, status: compareSeverity(previous.severity, severity) };
}
