import { getAssignedArea, getCases, getFarmers, getHotspotById, getOfficerSession, type Hotspot } from "./officerService";

export type GeofenceStatus = "Pending Review" | "Active" | "Rejected";
export interface GeoFence {
  id: string; hotspotId: string; crop: string; disease: string; location: string;
  center: { latitude: number; longitude: number }; radiusKm: number;
  status: GeofenceStatus; createdAt: string; reviewedAt?: string; reviewedBy?: string;
  alertedFarmerIds: string[];
}

const KEY = "doccrop_officer_geofences";
function load<T>(fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try { return JSON.parse(localStorage.getItem(KEY) || "null") ?? fallback; } catch { return fallback; }
}
function save(value: GeoFence[]) { if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(value)); }

export function getGeoFences(): GeoFence[] { return load<GeoFence[]>([]); }
export function getGeoFenceForHotspot(hotspotId: string): GeoFence | undefined { return getGeoFences().find(g => g.hotspotId === hotspotId); }

export function createGeoFenceForHotspot(hotspot: Hotspot): GeoFence {
  const existing = getGeoFenceForHotspot(hotspot.id);
  if (existing) return existing;
  const fence: GeoFence = {
    id: `GEOFENCE-${Date.now()}`, hotspotId: hotspot.id, crop: hotspot.crop, disease: hotspot.disease,
    location: hotspot.location, center: hotspot.center, radiusKm: Math.max(5, hotspot.radiusKm),
    status: "Pending Review", createdAt: new Date().toISOString(), alertedFarmerIds: [],
  };
  save([...getGeoFences(), fence]); return fence;
}

export function reviewGeoFence(id: string, status: "Active" | "Rejected"): GeoFence | undefined {
  const session = getOfficerSession(); const all = getGeoFences(); const i = all.findIndex(g => g.id === id);
  if (i < 0) return undefined; all[i] = { ...all[i], status, reviewedAt: new Date().toISOString(), reviewedBy: session?.officerId || "Officer" }; save(all); return all[i];
}

function haversine(a:{latitude:number;longitude:number}, b:{latitude:number;longitude:number}) {
  const R=6371, dLat=(b.latitude-a.latitude)*Math.PI/180, dLon=(b.longitude-a.longitude)*Math.PI/180;
  const lat1=a.latitude*Math.PI/180, lat2=b.latitude*Math.PI/180;
  const h=Math.sin(dLat/2)**2+Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2; return 2*R*Math.asin(Math.sqrt(h));
}

export function getFarmersInsideGeoFence(fence: GeoFence) {
  const area = getAssignedArea();
  return getFarmers().filter(f => f.district === area).map(f => ({ farmer:f, distanceKm:haversine(fence.center,{latitude:f.lat,longitude:f.lng}) })).filter(x => x.distanceKm <= fence.radiusKm);
}

export function sendGeoFenceAlert(id: string, message: string) {
  const all=getGeoFences(), i=all.findIndex(g=>g.id===id); if(i<0) return {sent:0, farmerIds:[] as string[]};
  const fence=all[i]; if(fence.status!=="Active") return {sent:0, farmerIds:[] as string[]};
  const targets=getFarmersInsideGeoFence(fence).filter(x=>!fence.alertedFarmerIds.includes(x.farmer.id));
  const updated={...fence, alertedFarmerIds:[...fence.alertedFarmerIds,...targets.map(x=>x.farmer.id)]}; all[i]=updated; save(all);
  if(typeof window!=="undefined"){ const key="doccrop_officer_geofence_farmer_alerts"; let alerts:any[]=[]; try{alerts=JSON.parse(localStorage.getItem(key)||"[]")}catch{};
    const now=new Date().toISOString(); alerts.push(...targets.map(x=>({id:`GFA-${Date.now()}-${x.farmer.id}`,farmerId:x.farmer.id,geofenceId:id,hotspotId:fence.hotspotId,title:`${fence.disease} Alert`,message,createdAt:now,read:false}))); localStorage.setItem(key,JSON.stringify(alerts)); }
  return {sent:targets.length, farmerIds:targets.map(x=>x.farmer.id)};
}
