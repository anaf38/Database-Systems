import { historyCases } from "./farmData";
export function getHistory() { return historyCases; }
export function getHistoryCase(id: string) { return historyCases.find((h) => h.id === id); }
