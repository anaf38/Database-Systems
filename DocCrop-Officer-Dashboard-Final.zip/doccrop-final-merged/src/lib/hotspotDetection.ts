// Disease Hotspot / Cluster Detection — frontend prototype logic.
//
// This is a demo heuristic to help an Agriculture Officer triage where several
// nearby farmers report the same disease/pest in a short time window. It is
// NOT a scientifically validated outbreak-detection system — it only flags
// patterns worth a human field visit. The officer always makes the final call.
//
// Rule (all configurable — these are prototype/demo defaults, not universal
// agricultural thresholds):
//   IF 3+ farmers, within ~5km of each other, report the same disease/pest
//   within the last 7 days → create a "potential disease hotspot".

import type {
  DiseaseCaseReport,
  EnvironmentalConditions,
  Hotspot,
  HotspotRiskBreakdown,
  HotspotSeverity,
  RiskBand,
  TrendPoint,
} from "./hotspotTypes";

export type HotspotDetectionConfig = {
  minAffectedFarmers: number; // threshold to create a hotspot (default 3)
  radiusKm: number; // clustering radius (default 5)
  timeWindowDays: number; // recency window (default 7)
};

export const DEFAULT_HOTSPOT_CONFIG: HotspotDetectionConfig = {
  minAffectedFarmers: 3,
  radiusKm: 5,
  timeWindowDays: 7,
};

const DAY_MS = 24 * 60 * 60 * 1000;

function haversineKm(a: { latitude: number; longitude: number }, b: { latitude: number; longitude: number }) {
  const R = 6371;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const lat1 = (a.latitude * Math.PI) / 180;
  const lat2 = (b.latitude * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function daysAgo(dateStr: string, now: Date) {
  return Math.round((now.getTime() - new Date(dateStr).getTime()) / DAY_MS);
}

function classifySeverity(affectedFarmers: number): HotspotSeverity | "NONE" {
  if (affectedFarmers > 5) return "CRITICAL";
  if (affectedFarmers >= 3) return "HIGH PRIORITY";
  if (affectedFarmers === 2) return "MONITORING";
  return "NONE";
}

function riskBandFromScore(score: number): RiskBand {
  if (score >= 80) return "CRITICAL";
  if (score >= 60) return "HIGH";
  if (score >= 35) return "MEDIUM";
  return "LOW";
}

function buildTrend(cases: DiseaseCaseReport[], now: Date): { trend: TrendPoint[]; increasing: boolean } {
  const sorted = [...cases].sort((a, b) => new Date(a.reportedAt).getTime() - new Date(b.reportedAt).getTime());
  const uniqueDays = Array.from(new Set(sorted.map((c) => c.reportedAt))).sort();
  let cumulative = 0;
  const trend: TrendPoint[] = uniqueDays.map((day, i) => {
    const newCases = sorted.filter((c) => c.reportedAt === day).length;
    cumulative += newCases;
    const ago = daysAgo(day, now);
    const label = ago <= 0 ? "Today" : ago === 1 ? "Yesterday" : `Day ${i + 1}`;
    return { day, label, newCases, cumulativeCases: cumulative };
  });
  const increasing = trend.length >= 2 && trend.some((t, i) => i > 0 && t.newCases > (trend[i - 1]?.newCases ?? 0));
  return { trend, increasing };
}

function calculateRiskScore(input: {
  affectedFarmers: number;
  radiusKm: number;
  configRadiusKm: number;
  increasing: boolean;
  environmental: EnvironmentalConditions | null;
  avgFarmerRisk: number;
}): { score: number; breakdown: HotspotRiskBreakdown } {
  const farmsScore = Math.min(1, input.affectedFarmers / 5) * 35;

  const concentrationRatio = input.radiusKm / input.configRadiusKm;
  const geographicConcentration: HotspotRiskBreakdown["geographicConcentration"] =
    concentrationRatio <= 0.75 ? "High" : concentrationRatio <= 1 ? "Medium" : "Low";
  const concentrationScore = geographicConcentration === "High" ? 20 : geographicConcentration === "Medium" ? 12 : 5;

  const trendScore = input.increasing ? 20 : 8;
  const newCases: HotspotRiskBreakdown["newCases"] = input.increasing ? "Increasing" : "Stable";

  const envScore = input.environmental ? (input.environmental.favorable ? 15 : 4) : 8;
  const environmentalConditions: HotspotRiskBreakdown["environmentalConditions"] = input.environmental
    ? input.environmental.favorable
      ? "Favorable"
      : "Unfavorable"
    : "Unknown";

  const severityScore = (input.avgFarmerRisk / 100) * 10;

  const score = Math.round(Math.min(100, farmsScore + concentrationScore + trendScore + envScore + severityScore));
  const band = riskBandFromScore(score);

  return {
    score,
    breakdown: {
      affectedFarms: `${Math.min(input.affectedFarmers, 5)} / 5`,
      geographicConcentration,
      newCases,
      environmentalConditions,
      overall: band === "CRITICAL" ? "CRITICAL PRIORITY" : band === "HIGH" ? "HIGH PRIORITY" : band === "MEDIUM" ? "MEDIUM PRIORITY" : "LOW PRIORITY",
    },
  };
}

/**
 * Groups disease case reports into potential hotspots.
 *
 * Steps (per the DocCrop hotspot spec):
 *  1. Group cases by disease (+ crop).
 *  2. Compare geographic coordinates to find cases within the radius of one another.
 *  3. Only consider cases inside the configured recent time window.
 *  4. Count affected (distinct) farmers per cluster.
 *  5. Create a hotspot object once the minimum-farmer threshold is reached.
 *  6. Calculate a prototype risk score.
 *  7. Return the active hotspots, most urgent first.
 */
export function detectDiseaseHotspots(
  cases: DiseaseCaseReport[],
  config: HotspotDetectionConfig = DEFAULT_HOTSPOT_CONFIG,
  environmentalByLocation: Record<string, EnvironmentalConditions> = {},
  now: Date = new Date(),
): Hotspot[] {
  const recent = cases.filter((c) => daysAgo(c.reportedAt, now) <= config.timeWindowDays);

  const byDisease = new Map<string, DiseaseCaseReport[]>();
  for (const c of recent) {
    const key = `${c.crop}::${c.disease}`;
    byDisease.set(key, [...(byDisease.get(key) ?? []), c]);
  }

  const hotspots: Hotspot[] = [];

  for (const [, group] of byDisease) {
    // Union-find style clustering: connect any two reports within the radius.
    const parent: number[] = group.map((_, i) => i);
    const find = (i: number): number => {
      const p = parent[i] ?? i;
      if (p === i) return i;
      const root = find(p);
      parent[i] = root;
      return root;
    };
    const union = (a: number, b: number) => {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent[ra] = rb;
    };
    for (let i = 0; i < group.length; i++) {
      for (let j = i + 1; j < group.length; j++) {
        const gi = group[i];
        const gj = group[j];
        if (gi && gj && haversineKm(gi, gj) <= config.radiusKm) union(i, j);
      }
    }

    const clusters = new Map<number, DiseaseCaseReport[]>();
    group.forEach((c, i) => {
      const root = find(i);
      clusters.set(root, [...(clusters.get(root) ?? []), c]);
    });

    for (const [, clusterCases] of clusters) {
      const affectedFarmers = new Set(clusterCases.map((c) => c.farmerName)).size;
      if (affectedFarmers < config.minAffectedFarmers) continue; // require the configured threshold

      const lats = clusterCases.map((c) => c.latitude);
      const lons = clusterCases.map((c) => c.longitude);
      const center = {
        latitude: lats.reduce((a, b) => a + b, 0) / lats.length,
        longitude: lons.reduce((a, b) => a + b, 0) / lons.length,
      };
      const radiusKm = Math.max(0.3, ...clusterCases.map((c) => haversineKm(center, c)));

      const { trend, increasing } = buildTrend(clusterCases, now);
      const severity = classifySeverity(affectedFarmers);
      if (severity === "NONE") continue;

      const location = mostCommonLocation(clusterCases);
      const environmental = environmentalByLocation[location] ?? null;
      const avgFarmerRisk = clusterCases.reduce((a, c) => a + c.riskScore, 0) / clusterCases.length;

      const { score, breakdown } = calculateRiskScore({
        affectedFarmers,
        radiusKm,
        configRadiusKm: config.radiusKm,
        increasing,
        environmental,
        avgFarmerRisk,
      });

      const sortedByDate = [...clusterCases].sort((a, b) => new Date(a.reportedAt).getTime() - new Date(b.reportedAt).getTime());
      const firstCase = sortedByDate[0];
      const lastCase = sortedByDate[sortedByDate.length - 1];
      if (!firstCase || !lastCase) continue;

      const meetsHotspotThreshold = affectedFarmers >= config.minAffectedFarmers;

      hotspots.push({
        id: `HOTSPOT-${slug(firstCase.disease)}-${slug(location)}`,
        disease: firstCase.disease,
        crop: firstCase.crop,
        location,
        center,
        radiusKm: Math.round(radiusKm * 10) / 10,
        affectedFarmers,
        caseIds: clusterCases.map((c) => c.id),
        cases: sortedByDate,
        firstDetected: firstCase.reportedAt,
        lastDetected: lastCase.reportedAt,
        riskScore: score,
        riskBand: riskBandFromScore(score),
        severity,
        status: "New",
        fieldVisitRequired: meetsHotspotThreshold,
        trend,
        increasing,
        environmental,
        riskBreakdown: breakdown,
      });
    }
  }

  return hotspots.sort((a, b) => b.riskScore - a.riskScore);
}

/** UI helper: "Today" / "Yesterday" / "3 days ago" relative to now. */
export function formatRelativeDate(dateStr: string, now: Date = new Date()) {
  const ago = daysAgo(dateStr, now);
  if (ago <= 0) return "Today";
  if (ago === 1) return "Yesterday";
  return `${ago} days ago`;
}

function mostCommonLocation(cases: DiseaseCaseReport[]) {
  const counts = new Map<string, number>();
  for (const c of cases) counts.set(c.location, (counts.get(c.location) ?? 0) + 1);
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] ?? cases[0]?.location ?? "Unknown";
}

function slug(s: string) {
  return s.toUpperCase().replace(/[^A-Z0-9]+/g, "").slice(0, 10);
}
