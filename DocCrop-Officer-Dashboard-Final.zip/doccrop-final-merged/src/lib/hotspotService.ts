// Officer-side hotspot workflow service.
// Detection itself (hotspotDetection.ts) is pure/stateless. This service layers
// officer actions — status changes, scheduled field visits, investigation
// write-ups and notifications — on top, persisted to localStorage so the demo
// flow works end-to-end with local/mock frontend state only (no backend).

import { detectDiseaseHotspots } from "./hotspotDetection";
import { diseaseCaseReports, environmentalConditionsByLocation } from "./officerMockData";
import { CURRENT_FARMER_NAME } from "./farmerIdentity";
import { addNotification as addFarmerNotification } from "./notificationService";
import type {
  FarmerVisitConfirmation,
  FieldVisit,
  FieldVisitAssigneeRole,
  Hotspot,
  HotspotAssessment,
  HotspotInvestigation,
  HotspotStatus,
  OfficerNotification,
  OfficerNotificationPriority,
} from "./hotspotTypes";

const STATUS_KEY = "doccrop.officer.hotspotStatus";
const VISITS_KEY = "doccrop.officer.fieldVisits";
const INVESTIGATIONS_KEY = "doccrop.officer.hotspotInvestigations";
const NOTIFICATIONS_KEY = "doccrop.officer.notifications";
const SEEDED_KEY = "doccrop.officer.notificationsSeeded";

function readJSON<T>(key: string, fallback: T): T {
  if (typeof localStorage === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON<T>(key: string, value: T) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
}

/** Fresh detection output from the current mock case reports — no officer overrides. */
export function getBaseHotspots(): Hotspot[] {
  return detectDiseaseHotspots(diseaseCaseReports, undefined, environmentalConditionsByLocation);
}

/** Detected hotspots with any officer status changes applied. Sorted most urgent first. */
export function getHotspots(): Hotspot[] {
  seedHotspotNotifications();
  const overrides = readJSON<Record<string, HotspotStatus>>(STATUS_KEY, {});
  return getBaseHotspots()
    .map((h) => {
      const overriddenStatus = overrides[h.id];
      return overriddenStatus ? { ...h, status: overriddenStatus } : h;
    })
    .sort((a, b) => b.riskScore - a.riskScore);
}

export function getHotspot(id: string): Hotspot | undefined {
  return getHotspots().find((h) => h.id === id);
}

export function updateHotspotStatus(id: string, status: HotspotStatus) {
  const overrides = readJSON<Record<string, HotspotStatus>>(STATUS_KEY, {});
  overrides[id] = status;
  writeJSON(STATUS_KEY, overrides);
}

// --- Field visits -----------------------------------------------------------

export function getFieldVisits(): FieldVisit[] {
  return readJSON<FieldVisit[]>(VISITS_KEY, []).sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime());
}

export function getFieldVisit(id: string): FieldVisit | undefined {
  return getFieldVisits().find((v) => v.id === id);
}

export function scheduleFieldVisit(input: {
  hotspot: Hotspot;
  assignedRole: FieldVisitAssigneeRole;
  assignedName: string;
  scheduledDate: string;
  scheduledTime: string;
}): FieldVisit {
  const visit: FieldVisit = {
    id: `FV-${Date.now()}`,
    hotspotId: input.hotspot.id,
    purpose: "Investigate Disease Hotspot",
    affectedArea: input.hotspot.location,
    disease: input.hotspot.disease,
    affectedFarmers: input.hotspot.affectedFarmers,
    assignedRole: input.assignedRole,
    assignedName: input.assignedName,
    scheduledDate: input.scheduledDate,
    scheduledTime: input.scheduledTime,
    status: "Scheduled",
    farmerConfirmation: "Pending",
    isFollowUp: false,
    followUpOfVisitId: null,
    createdAt: new Date().toISOString(),
  };
  const list = readJSON<FieldVisit[]>(VISITS_KEY, []);
  writeJSON(VISITS_KEY, [visit, ...list]);
  updateHotspotStatus(input.hotspot.id, "Field Visit Scheduled");
  addNotification({
    title: "Hotspot field visit scheduled",
    body: `${input.assignedRole === "Expert" ? input.assignedName : "You"} will visit the ${input.hotspot.disease} hotspot in ${input.hotspot.location} on ${input.scheduledDate} at ${input.scheduledTime}.`,
    priority: "HIGH",
    hotspotId: input.hotspot.id,
    visitId: visit.id,
  });
  notifyAffectedFarmers(input.hotspot, visit, "scheduled");
  return visit;
}

/** Called when the farmer taps a response on the field-visit notification card. */
export function setFarmerVisitConfirmation(visitId: string, confirmation: FarmerVisitConfirmation) {
  const visits = readJSON<FieldVisit[]>(VISITS_KEY, []).map((v) => (v.id === visitId ? { ...v, farmerConfirmation: confirmation } : v));
  writeJSON(VISITS_KEY, visits);
  const visit = visits.find((v) => v.id === visitId);
  if (!visit) return;
  addNotification({
    title: "Farmer responded to field visit",
    body: `The farmer marked the ${visit.disease} field visit in ${visit.affectedArea} as "${confirmation}".`,
    priority: confirmation === "Visited" ? "NORMAL" : "HIGH",
    hotspotId: visit.hotspotId,
    visitId: visit.id,
  });
}

/** Officer accepts an auto-suggested follow-up visit (optionally adjusting the date/time first). */
export function confirmFollowUpVisit(visitId: string, scheduledDate?: string, scheduledTime?: string) {
  const visits = readJSON<FieldVisit[]>(VISITS_KEY, []).map((v) =>
    v.id === visitId
      ? { ...v, status: "Scheduled" as const, scheduledDate: scheduledDate ?? v.scheduledDate, scheduledTime: scheduledTime ?? v.scheduledTime }
      : v,
  );
  writeJSON(VISITS_KEY, visits);
  const visit = visits.find((v) => v.id === visitId);
  const hotspot = visit ? getHotspots().find((h) => h.id === visit.hotspotId) : undefined;
  if (visit && hotspot) notifyAffectedFarmers(hotspot, visit, "followup-confirmed");
}

function notifyAffectedFarmers(hotspot: Hotspot, visit: FieldVisit, kind: "scheduled" | "followup-confirmed") {
  const involvesCurrentFarmer = hotspot.cases.some((c) => c.farmerName === CURRENT_FARMER_NAME);
  if (!involvesCurrentFarmer) return;
  const who = visit.assignedRole === "Expert" ? `${visit.assignedName} (${visit.assignedRole.toLowerCase()})` : "Your agriculture officer";
  addFarmerNotification({
    kind: "visit",
    title: kind === "scheduled" ? "Field visit scheduled for your farm" : "Follow-up visit confirmed",
    body:
      kind === "scheduled"
        ? `${who} will visit your ${hotspot.crop.toLowerCase()} field in ${hotspot.location} on ${visit.scheduledDate} at ${visit.scheduledTime} to check on the reported ${hotspot.disease}. Please confirm once the visit happens.`
        : `A follow-up visit has been confirmed for ${visit.scheduledDate} at ${visit.scheduledTime} regarding the ${hotspot.disease} case on your farm.`,
  });
}

// --- Investigations / hotspot assessment ------------------------------------

export function getInvestigations(): HotspotInvestigation[] {
  return readJSON<HotspotInvestigation[]>(INVESTIGATIONS_KEY, []);
}

export function getInvestigationForVisit(visitId: string): HotspotInvestigation | undefined {
  return getInvestigations().find((i) => i.visitId === visitId);
}

const ASSESSMENT_TO_STATUS: Record<HotspotAssessment, HotspotStatus> = {
  "Confirmed Outbreak": "Confirmed",
  "Potential Outbreak": "Under Investigation",
  "False Alarm": "Resolved",
  "Requires Further Monitoring": "Monitoring",
};

export function submitHotspotAssessment(input: {
  hotspot: Hotspot;
  visit: FieldVisit;
  farmsInspected: number;
  confirmedCases: number;
  suspectedCases: number;
  symptomsObserved: string;
  cropGrowthStage: string;
  approxAffectedArea: string;
  weatherObservations: string;
  soilMoistureObservations: string;
  pestObservations: string;
  officerRemarks: string;
  assessment: HotspotAssessment;
}): HotspotInvestigation {
  const record: HotspotInvestigation = {
    id: `INV-${Date.now()}`,
    visitId: input.visit.id,
    hotspotId: input.hotspot.id,
    farmsInspected: input.farmsInspected,
    confirmedCases: input.confirmedCases,
    suspectedCases: input.suspectedCases,
    symptomsObserved: input.symptomsObserved,
    cropGrowthStage: input.cropGrowthStage,
    approxAffectedArea: input.approxAffectedArea,
    weatherObservations: input.weatherObservations,
    soilMoistureObservations: input.soilMoistureObservations,
    pestObservations: input.pestObservations,
    officerRemarks: input.officerRemarks,
    assessment: input.assessment,
    submittedAt: new Date().toISOString(),
  };
  const list = readJSON<HotspotInvestigation[]>(INVESTIGATIONS_KEY, []);
  writeJSON(INVESTIGATIONS_KEY, [record, ...list]);

  const visits = readJSON<FieldVisit[]>(VISITS_KEY, []).map((v) => (v.id === input.visit.id ? { ...v, status: "Completed" as const } : v));
  writeJSON(VISITS_KEY, visits);

  const newStatus = ASSESSMENT_TO_STATUS[input.assessment];
  updateHotspotStatus(input.hotspot.id, newStatus);
  addNotification({
    title: `Hotspot assessment submitted: ${input.assessment}`,
    body: `${input.hotspot.disease} hotspot in ${input.hotspot.location} is now marked "${newStatus}".`,
    priority: input.assessment === "Confirmed Outbreak" ? "URGENT" : "NORMAL",
    hotspotId: input.hotspot.id,
    visitId: input.visit.id,
  });

  if (input.assessment !== "False Alarm") {
    suggestFollowUpVisit(input.hotspot, input.visit);
  }

  return record;
}

/** Auto-suggests a follow-up visit ~7 days out; the officer reviews/confirms it from the Visits page. */
function suggestFollowUpVisit(hotspot: Hotspot, originatingVisit: FieldVisit): FieldVisit {
  const suggestedDate = new Date(originatingVisit.scheduledDate);
  suggestedDate.setDate(suggestedDate.getDate() + 7);
  const followUp: FieldVisit = {
    id: `FV-${Date.now()}`,
    hotspotId: hotspot.id,
    purpose: "Follow-up Hotspot Visit",
    affectedArea: hotspot.location,
    disease: hotspot.disease,
    affectedFarmers: hotspot.affectedFarmers,
    assignedRole: originatingVisit.assignedRole,
    assignedName: originatingVisit.assignedName,
    scheduledDate: suggestedDate.toISOString().slice(0, 10),
    scheduledTime: originatingVisit.scheduledTime,
    status: "Suggested",
    farmerConfirmation: "Pending",
    isFollowUp: true,
    followUpOfVisitId: originatingVisit.id,
    createdAt: new Date().toISOString(),
  };
  const list = readJSON<FieldVisit[]>(VISITS_KEY, []);
  writeJSON(VISITS_KEY, [followUp, ...list]);
  addNotification({
    title: "Follow-up visit suggested",
    body: `A follow-up visit for the ${hotspot.disease} hotspot in ${hotspot.location} is suggested for ${followUp.scheduledDate}. Review and confirm it from Field Visits.`,
    priority: "NORMAL",
    hotspotId: hotspot.id,
    visitId: followUp.id,
  });
  return followUp;
}

// --- Notifications ------------------------------------------------------------

/** Generic entry point for pushing a notification onto the officer's notification center (e.g. from the farmer's "Call the Expert" flow). */
export function pushOfficerNotification(input: { title: string; body: string; priority: OfficerNotificationPriority; hotspotId?: string; visitId?: string; callId?: string }): OfficerNotification {
  return addNotification(input);
}

function addNotification(input: { title: string; body: string; priority: OfficerNotificationPriority; hotspotId?: string; visitId?: string; callId?: string }): OfficerNotification {
  const notification: OfficerNotification = {
    id: `ON-${Date.now()}-${Math.round(Math.random() * 1000)}`,
    createdAt: new Date().toISOString(),
    read: false,
    ...input,
  };
  const list = readJSON<OfficerNotification[]>(NOTIFICATIONS_KEY, []);
  writeJSON(NOTIFICATIONS_KEY, [notification, ...list]);
  return notification;
}

const PRIORITY_RANK: Record<OfficerNotificationPriority, number> = { CRITICAL: 3, URGENT: 2, HIGH: 1, NORMAL: 0 };

function priorityForHotspot(h: Hotspot): OfficerNotificationPriority {
  if (h.affectedFarmers > 5) return "CRITICAL";
  if (h.affectedFarmers >= 4) return "URGENT";
  if (h.affectedFarmers === 3) return "HIGH";
  return "NORMAL";
}

/** Idempotently create one auto-notification per hotspot the first time it's detected. */
export function seedHotspotNotifications() {
  const seeded = readJSON<string[]>(SEEDED_KEY, []);
  const toSeed = getBaseHotspots().filter((h) => !seeded.includes(h.id));
  if (!toSeed.length) return;

  for (const h of toSeed) {
    const priority = priorityForHotspot(h);
    const body =
      h.severity === "MONITORING"
        ? `${h.affectedFarmers} nearby farms in ${h.location} report possible ${h.disease}. Possible disease cluster — no field visit required yet.`
        : `${h.affectedFarmers} nearby ${h.crop.toLowerCase()} farms in ${h.location} have reported possible ${h.disease} within the last few days. Field inspection is recommended.`;
    addNotification({
      title: h.severity === "MONITORING" ? "Possible disease cluster" : "Potential disease hotspot",
      body,
      priority,
      hotspotId: h.id,
    });
  }
  writeJSON(SEEDED_KEY, [...seeded, ...toSeed.map((h) => h.id)]);
}

export function getOfficerNotifications(): OfficerNotification[] {
  seedHotspotNotifications();
  return readJSON<OfficerNotification[]>(NOTIFICATIONS_KEY, []).sort((a, b) => {
    const rankDiff = PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority];
    if (rankDiff !== 0) return rankDiff;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
}

export function markNotificationRead(id: string) {
  const list = readJSON<OfficerNotification[]>(NOTIFICATIONS_KEY, []).map((n) => (n.id === id ? { ...n, read: true } : n));
  writeJSON(NOTIFICATIONS_KEY, list);
}

export function getUnreadOfficerNotificationCount(): number {
  return getOfficerNotifications().filter((n) => !n.read).length;
}
