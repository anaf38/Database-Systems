// Types for the Agriculture Officer Hotspot Detection & Alert module.
// Prototype/demo module — thresholds and the risk score are configurable
// demo parameters, not validated agricultural science.

export type HotspotSeverity = "MONITORING" | "HIGH PRIORITY" | "CRITICAL";
export type RiskBand = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export type HotspotStatus =
  | "New"
  | "Under Review"
  | "Field Visit Scheduled"
  | "Under Investigation"
  | "Confirmed"
  | "Monitoring"
  | "Resolved";

export type HotspotAssessment =
  | "Confirmed Outbreak"
  | "Potential Outbreak"
  | "False Alarm"
  | "Requires Further Monitoring";

export type OfficerNotificationPriority = "NORMAL" | "HIGH" | "URGENT" | "CRITICAL";

/** A single farmer-submitted disease/pest report used as raw input to the detector. */
export type DiseaseCaseReport = {
  id: string;
  farmerName: string;
  crop: string;
  disease: string;
  location: string;
  latitude: number;
  longitude: number;
  reportedAt: string; // ISO date (yyyy-mm-dd)
  riskScore: number; // 0-100, that farmer's individual AI risk/confidence
};

export type EnvironmentalConditions = {
  location: string;
  relativeHumidity: number; // %
  soilMoisture: number; // %
  recentRainfallMm: number;
  favorable: boolean; // whether conditions may favor disease development
};

export type HotspotRiskBreakdown = {
  affectedFarms: string; // e.g. "5 / 5"
  geographicConcentration: "Low" | "Medium" | "High";
  newCases: "Stable" | "Increasing" | "Decreasing";
  environmentalConditions: "Favorable" | "Unfavorable" | "Unknown";
  overall: string; // e.g. "HIGH PRIORITY"
};

export type TrendPoint = { day: string; label: string; newCases: number; cumulativeCases: number };

export type Hotspot = {
  id: string;
  disease: string;
  crop: string;
  location: string;
  center: { latitude: number; longitude: number };
  radiusKm: number;
  affectedFarmers: number;
  caseIds: string[];
  cases: DiseaseCaseReport[];
  firstDetected: string;
  lastDetected: string;
  riskScore: number;
  riskBand: RiskBand;
  severity: HotspotSeverity;
  status: HotspotStatus;
  fieldVisitRequired: boolean;
  trend: TrendPoint[];
  increasing: boolean;
  environmental: EnvironmentalConditions | null;
  riskBreakdown: HotspotRiskBreakdown;
};

export type FieldVisitAssigneeRole = "Officer" | "Expert";
export type FieldVisitStatus = "Suggested" | "Scheduled" | "Completed";
export type FarmerVisitConfirmation = "Pending" | "Visited" | "In Progress" | "Not Yet";

export type Expert = {
  id: string;
  name: string;
  specialty: string;
};

export type FieldVisit = {
  id: string;
  hotspotId: string;
  purpose: string;
  affectedArea: string;
  disease: string;
  affectedFarmers: number;
  assignedRole: FieldVisitAssigneeRole;
  assignedName: string;
  scheduledDate: string;
  scheduledTime: string;
  status: FieldVisitStatus;
  farmerConfirmation: FarmerVisitConfirmation;
  isFollowUp: boolean;
  followUpOfVisitId: string | null;
  createdAt: string;
};

export type HotspotInvestigation = {
  id: string;
  visitId: string;
  hotspotId: string;
  farmsInspected: number;
  confirmedCases: number;
  suspectedCases: number;
  symptomsObserved: string;
  cropGrowthStage: string;
  approxAffectedArea: string;
  weatherObservations: string;
  soilMoistureObservations: string;
  pestObservations: string;
  officerRemarks: string;
  assessment: HotspotAssessment;
  submittedAt: string;
};

export type OfficerNotification = {
  id: string;
  title: string;
  body: string;
  priority: OfficerNotificationPriority;
  hotspotId?: string;
  visitId?: string;
  callId?: string;
  createdAt: string;
  read: boolean;
};

export const EXPERTS: Expert[] = [
  { id: "EXP-1", name: "Dr. Anita Rao", specialty: "Plant Pathologist" },
  { id: "EXP-2", name: "Dr. S. Iyer", specialty: "Entomologist" },
  { id: "EXP-3", name: "Dr. Meera Joshi", specialty: "Agronomist" },
];
