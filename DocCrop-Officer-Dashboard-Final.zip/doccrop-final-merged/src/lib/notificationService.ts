export type NotificationItem = { id: string; title: string; body: string; kind: "risk" | "followup" | "expert" | "safety" | "visit"; createdAt: string };
const KEY = "doccrop.notifications";
export function addNotification(item: Omit<NotificationItem, "id" | "createdAt">) { const n = { ...item, id: `n-${Date.now()}`, createdAt: new Date().toISOString() }; const list = JSON.parse(localStorage.getItem(KEY) ?? "[]") as NotificationItem[]; localStorage.setItem(KEY, JSON.stringify([n, ...list])); return n; }
export function getNotifications(): NotificationItem[] { return JSON.parse(localStorage.getItem(KEY) ?? "[]") as NotificationItem[]; }
