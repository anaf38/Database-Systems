// Mock data for the Agriculture Officer module.
// These are FRONTEND PROTOTYPE fixtures — mock farmer coordinates and mock
// disease/pest reports used to demonstrate hotspot-detection logic. No real
// backend or real farmer data is involved.
//
// Locations are set in Wardha district, Maharashtra so this connects to the
// app's own farmer persona (Ramesh Deshmukh, Wardha) — his existing Soybean
// rust and Pink bollworm cases (see lib/farmData.ts) are included as reports
// inside two of the clusters below, so scheduling a field visit for those
// hotspots produces a real notification on the farmer side.

import type { DiseaseCaseReport, EnvironmentalConditions } from "./hotspotTypes";
import { CURRENT_FARMER_NAME } from "./farmerIdentity";

// "Today" for every relative date in this module is 2026-09-08, matching the
// rest of the DocCrop mock data set (see lib/farmData.ts).

export const diseaseCaseReports: DiseaseCaseReport[] = [
  // --- Wardha cluster: Soybean Rust (5 farmers, includes the app's own farmer) ---
  { id: "DC-2042", farmerName: "S. Patil", crop: "Soybean", disease: "Soybean Rust", location: "Wardha", latitude: 20.7469, longitude: 78.5991, reportedAt: "2026-09-04", riskScore: 69 },
  { id: "DC-2045", farmerName: "V. Bhoyar", crop: "Soybean", disease: "Soybean Rust", location: "Wardha", latitude: 20.7502, longitude: 78.6048, reportedAt: "2026-09-05", riskScore: 71 },
  { id: "DC-2048", farmerName: CURRENT_FARMER_NAME, crop: "Soybean", disease: "Soybean Rust", location: "Wardha", latitude: 20.7453, longitude: 78.6022, reportedAt: "2026-09-04", riskScore: 72 },
  { id: "DC-2051", farmerName: "A. Ingle", crop: "Soybean", disease: "Soybean Rust", location: "Wardha", latitude: 20.7411, longitude: 78.5967, reportedAt: "2026-09-07", riskScore: 78 },
  { id: "DC-2053", farmerName: "K. Thakre", crop: "Soybean", disease: "Soybean Rust", location: "Wardha", latitude: 20.7488, longitude: 78.6091, reportedAt: "2026-09-08", riskScore: 83 },

  // --- Hinganghat cluster: Cotton Pink Bollworm (4 farmers, includes the app's own farmer) ---
  { id: "DC-2102", farmerName: "N. Sahare", crop: "Cotton", disease: "Pink Bollworm", location: "Hinganghat", latitude: 20.5488, longitude: 78.8412, reportedAt: "2026-09-01", riskScore: 62 },
  { id: "DC-2107", farmerName: CURRENT_FARMER_NAME, crop: "Cotton", disease: "Pink Bollworm", location: "Hinganghat", latitude: 20.5461, longitude: 78.8379, reportedAt: "2026-09-01", riskScore: 68 },
  { id: "DC-2111", farmerName: "D. Gawande", crop: "Cotton", disease: "Pink Bollworm", location: "Hinganghat", latitude: 20.5522, longitude: 78.8455, reportedAt: "2026-09-05", riskScore: 65 },
  { id: "DC-2116", farmerName: "P. Kale", crop: "Cotton", disease: "Pink Bollworm", location: "Hinganghat", latitude: 20.5439, longitude: 78.8340, reportedAt: "2026-09-06", riskScore: 70 },

  // --- Arvi cluster: Onion Purple Blotch (4 farmers, unrelated to the current farmer) ---
  { id: "DC-2201", farmerName: "T. Kohad", crop: "Onion", disease: "Onion Purple Blotch", location: "Arvi", latitude: 20.9936, longitude: 78.2377, reportedAt: "2026-09-03", riskScore: 58 },
  { id: "DC-2204", farmerName: "R. Wankhede", crop: "Onion", disease: "Onion Purple Blotch", location: "Arvi", latitude: 20.9971, longitude: 78.2415, reportedAt: "2026-09-05", riskScore: 61 },
  { id: "DC-2208", farmerName: "M. Deshmukh", crop: "Onion", disease: "Onion Purple Blotch", location: "Arvi", latitude: 20.9902, longitude: 78.2338, reportedAt: "2026-09-06", riskScore: 60 },
  { id: "DC-2212", farmerName: "S. Rathi", crop: "Onion", disease: "Onion Purple Blotch", location: "Arvi", latitude: 20.9958, longitude: 78.2296, reportedAt: "2026-09-08", riskScore: 66 },

  // --- Samudrapur pair: Groundnut Tikka Disease (2 farmers -> MONITORING, below hotspot threshold) ---
  { id: "DC-2301", farmerName: "G. Nimje", crop: "Groundnut", disease: "Groundnut Tikka Disease", location: "Samudrapur", latitude: 20.8425, longitude: 78.3016, reportedAt: "2026-09-07", riskScore: 51 },
  { id: "DC-2304", farmerName: "L. Bawane", crop: "Groundnut", disease: "Groundnut Tikka Disease", location: "Samudrapur", latitude: 20.8461, longitude: 78.3054, reportedAt: "2026-09-08", riskScore: 54 },

  // --- Isolated single reports (should NOT trigger a hotspot) ---
  { id: "DC-2401", farmerName: "H. Meshram", crop: "Wheat", disease: "Wheat Rust", location: "Deoli", latitude: 20.9020, longitude: 78.4780, reportedAt: "2026-09-08", riskScore: 57 },
  { id: "DC-2405", farmerName: "C. Yerawar", crop: "Soybean", disease: "Soybean Rust", location: "Karanja", latitude: 20.4903, longitude: 78.2119, reportedAt: "2026-09-07", riskScore: 63 },
];

export const environmentalConditionsByLocation: Record<string, EnvironmentalConditions> = {
  Wardha: { location: "Wardha", relativeHumidity: 84, soilMoisture: 71, recentRainfallMm: 28, favorable: true },
  Hinganghat: { location: "Hinganghat", relativeHumidity: 66, soilMoisture: 39, recentRainfallMm: 3, favorable: false },
  Arvi: { location: "Arvi", relativeHumidity: 70, soilMoisture: 46, recentRainfallMm: 9, favorable: true },
  Samudrapur: { location: "Samudrapur", relativeHumidity: 63, soilMoisture: 42, recentRainfallMm: 5, favorable: false },
};
