// src/lib/officerService.ts
// Centralized mock/service layer with localStorage persistence for DocCrop Agriculture Officer Mobile App

export type RiskLevel = "Low" | "Medium" | "High" | "Critical";
export type CaseStatus =
  | "New"
  | "Under Review"
  | "Field Visit Scheduled"
  | "Under Investigation"
  | "Confirmed"
  | "Monitoring"
  | "Resolved";

export interface CaseRemark {
  id: string;
  officerName: string;
  officerRole: string;
  timestamp: string;
  text: string;
}

export interface CaseTimelineItem {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  status: CaseStatus;
}

export interface OfficerCase {
  id: string; // e.g. "DC-1042"
  farmerId: string;
  farmerName: string;
  farmerPhone: string;
  crop: string;
  disease: string;
  location: string;
  riskScore: number; // 0-100
  riskLevel: RiskLevel;
  status: CaseStatus;
  reportDate: string;
  assignedOfficer: string;
  affectedArea: string; // e.g. "2.4 acres"
  lat: number;
  lng: number;
  symptoms?: string[];
  imageUrl?: string;
  remarks: CaseRemark[];
  timeline: CaseTimelineItem[];
  hotspotId?: string;
}

export interface HotspotTrendPoint {
  day: string;
  farmers: number;
  date: string;
}

export interface EnvironmentalData {
  temperatureC: number;
  humidityPercent: number;
  soilMoisturePercent: number;
  rainfallMm: number;
  safetyDisclaimer: string;
}

export interface Hotspot {
  id: string; // e.g. "HOTSPOT-001"
  disease: string;
  crop: string;
  location: string;
  affectedFarmers: number;
  radiusKm: number;
  riskScore: number;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "MONITORING";
  status: "New" | "Field Visit Scheduled" | "Under Investigation" | "Confirmed" | "Monitoring" | "Resolved";
  firstReport: string;
  latestReport: string;
  caseIds: string[];
  lat: number;
  lng: number;
  trend: HotspotTrendPoint[];
  environmental: EnvironmentalData;
}

export interface Farmer {
  id: string; // e.g. "FARMER-001"
  name: string;
  phone: string;
  village: string;
  taluk: string;
  district: string;
  primaryCrop: string;
  landSizeAcres: number;
  activeCasesCount: number;
  overallRisk: RiskLevel;
  soilType: string;
  irrigationSource: string;
  lat: number;
  lng: number;
  remarks: string[];
  joinedDate: string;
}

export type VisitStatus = "Scheduled" | "In Progress" | "Completed" | "Cancelled";

export interface InvestigationData {
  farmsInspected: number;
  confirmedCases: number;
  suspectedCases: number;
  symptoms: string;
  growthStage: string;
  affectedArea: string;
  weather: string;
  soilCondition: string;
  moisture: string;
  pestsObserved: string;
  officerRemarks: string;
  assessment: "Confirmed Outbreak" | "Potential Outbreak" | "False Alarm" | "Requires Further Monitoring";
  completedAt: string;
}

export interface FieldVisit {
  id: string; // e.g. "VISIT-001"
  farmerId: string;
  farmerName: string;
  caseId: string;
  crop: string;
  disease: string;
  location: string;
  dateTime: string;
  purpose: string;
  status: VisitStatus;
  notes?: string;
  investigation?: InvestigationData;
}

export interface OfficerNotification {
  id: string;
  category: "Urgent" | "Hotspots" | "Cases" | "Field Visits" | "System";
  title: string;
  body: string;
  timestamp: string;
  read: boolean;
  archived: boolean;
  priority: "High" | "Normal" | "Critical";
  caseId?: string;
  hotspotId?: string;
  visitId?: string;
}

export interface OfficerProfile {
  id: string;
  name: string;
  department: string;
  division: string;
  location: string;
  role: string;
  phone: string;
  email: string;
  badgeNumber: string;
  joinedDate: string;
}

export interface OfficerSettings {
  language: "English" | "Tamil" | "Hindi" | "Telugu" | "Kannada" | "Malayalam";
  appearance: "Light" | "Dark" | "System";
  notificationsEnabled: boolean;
  alertPreferences: {
    highRiskCases: boolean;
    criticalCases: boolean;
    hotspots: boolean;
    fieldVisits: boolean;
    systemAlerts: boolean;
  };
  hotspotConfig: {
    minimumAffectedFarmers: number;
    clusterRadiusKm: number;
    timeWindowDays: number;
  };
}

// ---------------- LOCAL STORAGE KEYS ----------------
const KEYS = {
  SESSION: "doccrop_officer_session",
  PROFILE: "doccrop_officer_profile",
  SETTINGS: "doccrop_officer_settings",
  CASES: "doccrop_officer_cases",
  HOTSPOTS: "doccrop_officer_hotspots",
  FARMERS: "doccrop_officer_farmers",
  VISITS: "doccrop_officer_visits",
  NOTIFICATIONS: "doccrop_officer_notifications",
  SELECTED_LANG: "doccrop_selected_language",
};

// ---------------- SEED DATA GENERATION ----------------
const SEED_PROFILE: OfficerProfile = {
  id: "AO-MDU-1042",
  name: "Agriculture Development Officer",
  department: "Department of Agriculture",
  division: "Madurai Agricultural Division",
  location: "Madurai",
  role: "Agriculture Officer",
  phone: "+91 94432 10842",
  email: "ado.madurai@agri.tn.gov.in",
  badgeNumber: "TN-AGRI-2024-1042",
  joinedDate: "2021-06-15",
};

const SEED_SETTINGS: OfficerSettings = {
  language: "English",
  appearance: "Light",
  notificationsEnabled: true,
  alertPreferences: {
    highRiskCases: true,
    criticalCases: true,
    hotspots: true,
    fieldVisits: true,
    systemAlerts: true,
  },
  hotspotConfig: {
    minimumAffectedFarmers: 3,
    clusterRadiusKm: 5,
    timeWindowDays: 7,
  },
};

const SEED_FARMERS: Farmer[] = [
  { id: "FARMER-001", name: "R. Kumar", phone: "+91 98421 11001", village: "Melur", taluk: "Melur", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 3.5, activeCasesCount: 2, overallRisk: "High", soilType: "Clay Loam", irrigationSource: "Periyar Canal", lat: 10.0284, lng: 78.3368, remarks: ["Followed up regarding leaf blast. Advised Tricyclazole application."], joinedDate: "2024-01-12" },
  { id: "FARMER-002", name: "M. Selvam", phone: "+91 98421 11002", village: "Melur", taluk: "Melur", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 4.0, activeCasesCount: 1, overallRisk: "High", soilType: "Clay Loam", irrigationSource: "Borewell", lat: 10.0312, lng: 78.3412, remarks: ["Neighboring field to R. Kumar. Early leaf lesions."], joinedDate: "2024-02-05" },
  { id: "FARMER-003", name: "P. Murugan", phone: "+91 98421 11003", village: "Melur", taluk: "Melur", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 2.8, activeCasesCount: 1, overallRisk: "High", soilType: "Alluvial Loam", irrigationSource: "Periyar Canal", lat: 10.0261, lng: 78.3340, remarks: ["Confirmed Rice Blast. Recommended fungicide rotation."], joinedDate: "2024-02-18" },
  { id: "FARMER-004", name: "K. Arumugam", phone: "+91 98421 11004", village: "Melur", taluk: "Melur", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 5.2, activeCasesCount: 1, overallRisk: "High", soilType: "Clay", irrigationSource: "Borewell", lat: 10.0335, lng: 78.3395, remarks: ["Reported blast symptoms on nursery crop."], joinedDate: "2024-03-01" },
  { id: "FARMER-005", name: "S. Rajendran", phone: "+91 98421 11005", village: "Melur", taluk: "Melur", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 3.0, activeCasesCount: 1, overallRisk: "Critical", soilType: "Clay Loam", irrigationSource: "Canal", lat: 10.0298, lng: 78.3315, remarks: ["High spore count observed; immediate spray needed."], joinedDate: "2024-03-10" },
  { id: "FARMER-006", name: "T. Balan", phone: "+91 98421 11006", village: "Usilampatti", taluk: "Usilampatti", district: "Madurai", primaryCrop: "Tomato", landSizeAcres: 2.2, activeCasesCount: 1, overallRisk: "High", soilType: "Red Sandy Loam", irrigationSource: "Drip Irrigation", lat: 9.9701, lng: 77.7942, remarks: ["Early blight concentric rings on lower leaves."], joinedDate: "2024-01-20" },
  { id: "FARMER-007", name: "V. Karuppan", phone: "+91 98421 11007", village: "Usilampatti", taluk: "Usilampatti", district: "Madurai", primaryCrop: "Tomato", landSizeAcres: 1.8, activeCasesCount: 1, overallRisk: "High", soilType: "Red Loam", irrigationSource: "Drip Irrigation", lat: 9.9734, lng: 77.7981, remarks: ["Coordinated field visit scheduled."], joinedDate: "2024-02-14" },
  { id: "FARMER-008", name: "A. Pandian", phone: "+91 98421 11008", village: "Usilampatti", taluk: "Usilampatti", district: "Madurai", primaryCrop: "Tomato", landSizeAcres: 3.0, activeCasesCount: 1, overallRisk: "High", soilType: "Red Soil", irrigationSource: "Open Well", lat: 9.9680, lng: 77.7915, remarks: ["Suspected early blight spread from adjacent plot."], joinedDate: "2024-03-04" },
  { id: "FARMER-009", name: "C. Muthu", phone: "+91 98421 11009", village: "Usilampatti", taluk: "Usilampatti", district: "Madurai", primaryCrop: "Tomato", landSizeAcres: 2.5, activeCasesCount: 1, overallRisk: "Medium", soilType: "Sandy Loam", irrigationSource: "Borewell", lat: 9.9752, lng: 77.8010, remarks: ["Preventive copper oxychloride spray completed."], joinedDate: "2024-03-12" },
  { id: "FARMER-010", name: "G. Subramanian", phone: "+91 98421 11010", village: "Thirumangalam", taluk: "Thirumangalam", district: "Madurai", primaryCrop: "Cotton", landSizeAcres: 4.5, activeCasesCount: 1, overallRisk: "Medium", soilType: "Black Cotton Soil", irrigationSource: "Rainfed / Well", lat: 9.8234, lng: 77.9890, remarks: ["Bollworm larvae identified in flower buds."], joinedDate: "2024-02-01" },
  { id: "FARMER-011", name: "J. Sundaram", phone: "+91 98421 11011", village: "Thirumangalam", taluk: "Thirumangalam", district: "Madurai", primaryCrop: "Cotton", landSizeAcres: 3.8, activeCasesCount: 1, overallRisk: "Medium", soilType: "Black Soil", irrigationSource: "Open Well", lat: 9.8270, lng: 77.9925, remarks: ["Pheromone traps set at 5 per acre."], joinedDate: "2024-02-22" },
  { id: "FARMER-012", name: "D. Vellayan", phone: "+91 98421 11012", village: "Thirumangalam", taluk: "Thirumangalam", district: "Madurai", primaryCrop: "Cotton", landSizeAcres: 5.0, activeCasesCount: 1, overallRisk: "Medium", soilType: "Black Soil", irrigationSource: "Rainfed", lat: 9.8201, lng: 77.9845, remarks: ["Under investigation with field officer."], joinedDate: "2024-03-08" },
  { id: "FARMER-013", name: "N. Palanivel", phone: "+91 98421 11013", village: "Vadipatti", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Banana", landSizeAcres: 2.0, activeCasesCount: 1, overallRisk: "High", soilType: "Alluvial Loam", irrigationSource: "Periyar Canal", lat: 10.0765, lng: 77.9620, remarks: ["Sigatoka yellow streaks on Grand Naine cultivar."], joinedDate: "2024-01-15" },
  { id: "FARMER-014", name: "L. Ramasamy", phone: "+91 98421 11014", village: "Vadipatti", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Banana", landSizeAcres: 3.2, activeCasesCount: 1, overallRisk: "High", soilType: "Clay Loam", irrigationSource: "Canal", lat: 10.0792, lng: 77.9654, remarks: ["De-leafing of diseased leaves recommended."], joinedDate: "2024-02-28" },
  { id: "FARMER-015", name: "B. Chelliah", phone: "+91 98421 11015", village: "Vadipatti", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Banana", landSizeAcres: 2.7, activeCasesCount: 1, overallRisk: "Medium", soilType: "Alluvial", irrigationSource: "Borewell", lat: 10.0738, lng: 77.9585, remarks: ["Monitoring progress after initial mineral oil spray."], joinedDate: "2024-03-15" },
  { id: "FARMER-016", name: "E. Senthil", phone: "+91 98421 11016", village: "Alanganallur", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Sugarcane", landSizeAcres: 6.0, activeCasesCount: 1, overallRisk: "Medium", soilType: "Clay Loam", irrigationSource: "River Canal", lat: 10.0432, lng: 78.0821, remarks: ["Red rot suspected in midrib of third leaf."], joinedDate: "2024-01-25" },
  { id: "FARMER-017", name: "H. Natarajan", phone: "+91 98421 11017", village: "Alanganallur", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Sugarcane", landSizeAcres: 4.2, activeCasesCount: 1, overallRisk: "Medium", soilType: "Clay Loam", irrigationSource: "Canal", lat: 10.0460, lng: 78.0855, remarks: ["Sett treatment check verified."], joinedDate: "2024-02-10" },
  { id: "FARMER-018", name: "Y. Dharmaraj", phone: "+91 98421 11018", village: "Alanganallur", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Sugarcane", landSizeAcres: 3.8, activeCasesCount: 1, overallRisk: "Low", soilType: "Loam", irrigationSource: "Borewell", lat: 10.0405, lng: 78.0790, remarks: ["Field sample sent for lab culture confirmation."], joinedDate: "2024-03-02" },
  { id: "FARMER-019", name: "R. Meenakshi", phone: "+91 98421 11019", village: "Sholavandan", taluk: "Vadipatti", district: "Madurai", primaryCrop: "Paddy (Rice)", landSizeAcres: 2.0, activeCasesCount: 0, overallRisk: "Low", soilType: "Clay Loam", irrigationSource: "Vaigai Canal", lat: 10.0210, lng: 77.9620, remarks: ["Resolved brown planthopper incident successfully."], joinedDate: "2024-02-12" },
  { id: "FARMER-020", name: "K. Thirupathi", phone: "+91 98421 11020", village: "Peraiyur", taluk: "Peraiyur", district: "Madurai", primaryCrop: "Groundnut", landSizeAcres: 3.5, activeCasesCount: 0, overallRisk: "Low", soilType: "Red Sandy Soil", irrigationSource: "Rainfed", lat: 9.7120, lng: 77.7950, remarks: ["Tikka disease under control after mancozeb spray."], joinedDate: "2024-01-30" },
];

const SEED_CASES: OfficerCase[] = [
  {
    id: "DC-1042",
    farmerId: "FARMER-001",
    farmerName: "R. Kumar",
    farmerPhone: "+91 98421 11001",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    riskScore: 84,
    riskLevel: "High",
    status: "Under Investigation",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.4 acres",
    lat: 10.0284,
    lng: 78.3368,
    symptoms: ["Spindle-shaped lesions with gray centers", "Yellow chlorotic halo around leaf spots", "Drying of leaf tips"],
    remarks: [
      { id: "rem-1", officerName: "ADO Madurai", officerRole: "Agriculture Officer", timestamp: "Sep 8, 2026 10:30 AM", text: "Cluster flagged in Melur paddy belt. Field visit scheduled." },
    ],
    timeline: [
      { id: "t-1", title: "Reported by Farmer", description: "Farmer submitted crop image scan via DocCrop AI.", timestamp: "Sep 4, 2026", status: "New" },
      { id: "t-2", title: "AI Hotspot Trigger", description: "Cluster risk crossed threshold score 80.", timestamp: "Sep 6, 2026", status: "Under Review" },
      { id: "t-3", title: "Field Visit Scheduled", description: "Visit assigned for on-site spore assessment.", timestamp: "Sep 7, 2026", status: "Field Visit Scheduled" },
      { id: "t-4", title: "Investigation Underway", description: "Field investigation in progress.", timestamp: "Sep 8, 2026", status: "Under Investigation" },
    ],
    hotspotId: "HOTSPOT-001",
  },
  {
    id: "DC-1045",
    farmerId: "FARMER-002",
    farmerName: "M. Selvam",
    farmerPhone: "+91 98421 11002",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    riskScore: 82,
    riskLevel: "High",
    status: "Under Investigation",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "3.1 acres",
    lat: 10.0312,
    lng: 78.3412,
    symptoms: ["Diamond lesions on flag leaves", "High humidity stress"],
    remarks: [],
    timeline: [
      { id: "t-1", title: "Reported by Farmer", description: "Submitted via DocCrop AI scanner.", timestamp: "Sep 5, 2026", status: "New" },
      { id: "t-2", title: "Added to Melur Hotspot", description: "Associated with HOTSPOT-001 cluster.", timestamp: "Sep 7, 2026", status: "Under Investigation" },
    ],
    hotspotId: "HOTSPOT-001",
  },
  {
    id: "DC-1048",
    farmerId: "FARMER-003",
    farmerName: "P. Murugan",
    farmerPhone: "+91 98421 11003",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    riskScore: 86,
    riskLevel: "Critical",
    status: "Field Visit Scheduled",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.0 acres",
    lat: 10.0261,
    lng: 78.3340,
    symptoms: ["Severe leaf necrosis", "Neck blast signs in early panicles"],
    remarks: [],
    timeline: [
      { id: "t-1", title: "Reported by Farmer", description: "Submitted via DocCrop AI scanner.", timestamp: "Sep 6, 2026", status: "New" },
      { id: "t-2", title: "Visit Booked", description: "Priority field inspection requested.", timestamp: "Sep 8, 2026", status: "Field Visit Scheduled" },
    ],
    hotspotId: "HOTSPOT-001",
  },
  {
    id: "DC-1051",
    farmerId: "FARMER-004",
    farmerName: "K. Arumugam",
    farmerPhone: "+91 98421 11004",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    riskScore: 79,
    riskLevel: "High",
    status: "New",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.8 acres",
    lat: 10.0335,
    lng: 78.3395,
    symptoms: ["Small brown spots on seedlings"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported by Farmer", description: "Uploaded nursery photo.", timestamp: "Sep 8, 2026", status: "New" }],
    hotspotId: "HOTSPOT-001",
  },
  {
    id: "DC-1053",
    farmerId: "FARMER-005",
    farmerName: "S. Rajendran",
    farmerPhone: "+91 98421 11005",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    riskScore: 88,
    riskLevel: "Critical",
    status: "Under Review",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.5 acres",
    lat: 10.0298,
    lng: 78.3315,
    symptoms: ["Widespread collar rot and blast lesions"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported by Farmer", description: "Submitted scan.", timestamp: "Sep 8, 2026", status: "New" }],
    hotspotId: "HOTSPOT-001",
  },
  {
    id: "DC-1020",
    farmerId: "FARMER-006",
    farmerName: "T. Balan",
    farmerPhone: "+91 98421 11006",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti",
    riskScore: 78,
    riskLevel: "High",
    status: "Field Visit Scheduled",
    reportDate: "Sep 6, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.5 acres",
    lat: 9.9701,
    lng: 77.7942,
    symptoms: ["Concentric ring lesions", "Lower foliage yellowing"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Case Created", description: "Farmer uploaded leaf photo.", timestamp: "Sep 6, 2026", status: "New" }],
    hotspotId: "HOTSPOT-002",
  },
  {
    id: "DC-1021",
    farmerId: "FARMER-007",
    farmerName: "V. Karuppan",
    farmerPhone: "+91 98421 11007",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti",
    riskScore: 75,
    riskLevel: "High",
    status: "Field Visit Scheduled",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.2 acres",
    lat: 9.9734,
    lng: 77.7981,
    symptoms: ["Target spots on stems and leaves"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Case Created", description: "Submitted via app.", timestamp: "Sep 7, 2026", status: "New" }],
    hotspotId: "HOTSPOT-002",
  },
  {
    id: "DC-1022",
    farmerId: "FARMER-008",
    farmerName: "A. Pandian",
    farmerPhone: "+91 98421 11008",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti",
    riskScore: 72,
    riskLevel: "High",
    status: "Under Review",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.0 acres",
    lat: 9.9680,
    lng: 77.7915,
    symptoms: ["Leaf defoliation in lower canopy"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Case Created", description: "Uploaded scan.", timestamp: "Sep 7, 2026", status: "New" }],
    hotspotId: "HOTSPOT-002",
  },
  {
    id: "DC-1023",
    farmerId: "FARMER-009",
    farmerName: "C. Muthu",
    farmerPhone: "+91 98421 11009",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti",
    riskScore: 68,
    riskLevel: "Medium",
    status: "New",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.8 acres",
    lat: 9.9752,
    lng: 77.8010,
    symptoms: ["Early concentric lesions"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Automatic scan detection.", timestamp: "Sep 8, 2026", status: "New" }],
    hotspotId: "HOTSPOT-002",
  },
  {
    id: "DC-1030",
    farmerId: "FARMER-010",
    farmerName: "G. Subramanian",
    farmerPhone: "+91 98421 11010",
    crop: "Cotton",
    disease: "American Bollworm",
    location: "Thirumangalam",
    riskScore: 62,
    riskLevel: "Medium",
    status: "Under Investigation",
    reportDate: "Sep 5, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "3.5 acres",
    lat: 9.8234,
    lng: 77.9890,
    symptoms: ["Bored holes in young bolls", "Frass deposition on bracts"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Boll damage photographed.", timestamp: "Sep 5, 2026", status: "New" }],
    hotspotId: "HOTSPOT-003",
  },
  {
    id: "DC-1031",
    farmerId: "FARMER-011",
    farmerName: "J. Sundaram",
    farmerPhone: "+91 98421 11011",
    crop: "Cotton",
    disease: "American Bollworm",
    location: "Thirumangalam",
    riskScore: 60,
    riskLevel: "Medium",
    status: "Under Investigation",
    reportDate: "Sep 6, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.8 acres",
    lat: 9.8270,
    lng: 77.9925,
    symptoms: ["Flared squares and shedding of buds"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Submitted via app.", timestamp: "Sep 6, 2026", status: "New" }],
    hotspotId: "HOTSPOT-003",
  },
  {
    id: "DC-1032",
    farmerId: "FARMER-012",
    farmerName: "D. Vellayan",
    farmerPhone: "+91 98421 11012",
    crop: "Cotton",
    disease: "American Bollworm",
    location: "Thirumangalam",
    riskScore: 64,
    riskLevel: "Medium",
    status: "Under Investigation",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "4.0 acres",
    lat: 9.8201,
    lng: 77.9845,
    symptoms: ["Larval feeding observed"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Submitted scan.", timestamp: "Sep 7, 2026", status: "New" }],
    hotspotId: "HOTSPOT-003",
  },
  {
    id: "DC-1035",
    farmerId: "FARMER-013",
    farmerName: "N. Palanivel",
    farmerPhone: "+91 98421 11013",
    crop: "Banana",
    disease: "Sigatoka Leaf Spot",
    location: "Vadipatti",
    riskScore: 71,
    riskLevel: "High",
    status: "Monitoring",
    reportDate: "Sep 3, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.8 acres",
    lat: 10.0765,
    lng: 77.9620,
    symptoms: ["Yellowish streaks parallel to leaf veins", "Premature leaf drying"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Crop scanned.", timestamp: "Sep 3, 2026", status: "New" }],
    hotspotId: "HOTSPOT-004",
  },
  {
    id: "DC-1036",
    farmerId: "FARMER-014",
    farmerName: "L. Ramasamy",
    farmerPhone: "+91 98421 11014",
    crop: "Banana",
    disease: "Sigatoka Leaf Spot",
    location: "Vadipatti",
    riskScore: 70,
    riskLevel: "High",
    status: "Monitoring",
    reportDate: "Sep 4, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.4 acres",
    lat: 10.0792,
    lng: 77.9654,
    symptoms: ["Extensive foliar blight"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Leaf scan uploaded.", timestamp: "Sep 4, 2026", status: "New" }],
    hotspotId: "HOTSPOT-004",
  },
  {
    id: "DC-1037",
    farmerId: "FARMER-015",
    farmerName: "B. Chelliah",
    farmerPhone: "+91 98421 11015",
    crop: "Banana",
    disease: "Sigatoka Leaf Spot",
    location: "Vadipatti",
    riskScore: 66,
    riskLevel: "Medium",
    status: "Monitoring",
    reportDate: "Sep 5, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.0 acres",
    lat: 10.0738,
    lng: 77.9585,
    symptoms: ["Leaf necrotic margins"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Submitted photo.", timestamp: "Sep 5, 2026", status: "New" }],
    hotspotId: "HOTSPOT-004",
  },
  {
    id: "DC-1060",
    farmerId: "FARMER-016",
    farmerName: "E. Senthil",
    farmerPhone: "+91 98421 11016",
    crop: "Sugarcane",
    disease: "Red Rot",
    location: "Alanganallur",
    riskScore: 56,
    riskLevel: "Medium",
    status: "New",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "3.2 acres",
    lat: 10.0432,
    lng: 78.0821,
    symptoms: ["Red lesions on midribs with white patches"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Uploaded cane shoot image.", timestamp: "Sep 7, 2026", status: "New" }],
    hotspotId: "HOTSPOT-005",
  },
  {
    id: "DC-1061",
    farmerId: "FARMER-017",
    farmerName: "H. Natarajan",
    farmerPhone: "+91 98421 11017",
    crop: "Sugarcane",
    disease: "Red Rot",
    location: "Alanganallur",
    riskScore: 54,
    riskLevel: "Medium",
    status: "New",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.8 acres",
    lat: 10.0460,
    lng: 78.0855,
    symptoms: ["Withering and yellowing of upper leaves"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Farmer diagnosis request.", timestamp: "Sep 8, 2026", status: "New" }],
    hotspotId: "HOTSPOT-005",
  },
  {
    id: "DC-1062",
    farmerId: "FARMER-018",
    farmerName: "Y. Dharmaraj",
    farmerPhone: "+91 98421 11018",
    crop: "Sugarcane",
    disease: "Red Rot",
    location: "Alanganallur",
    riskScore: 52,
    riskLevel: "Medium",
    status: "New",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.1 acres",
    lat: 10.0405,
    lng: 78.0790,
    symptoms: ["Alcoholic odor in stalk pith"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Sample sent for verification.", timestamp: "Sep 8, 2026", status: "New" }],
    hotspotId: "HOTSPOT-005",
  },
  // Additional 12 realistic cases to reach 30 total
  {
    id: "DC-1063",
    farmerId: "FARMER-001",
    farmerName: "R. Kumar",
    farmerPhone: "+91 98421 11001",
    crop: "Paddy (Rice)",
    disease: "Brown Spot",
    location: "Melur",
    riskScore: 45,
    riskLevel: "Low",
    status: "Monitoring",
    reportDate: "Aug 29, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.0 acre",
    lat: 10.0284,
    lng: 78.3368,
    symptoms: ["Oval brown spots on older leaves"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Follow-up scan.", timestamp: "Aug 29, 2026", status: "Monitoring" }],
  },
  {
    id: "DC-1064",
    farmerId: "FARMER-006",
    farmerName: "T. Balan",
    farmerPhone: "+91 98421 11006",
    crop: "Tomato",
    disease: "Bacterial Wilt",
    location: "Usilampatti",
    riskScore: 81,
    riskLevel: "High",
    status: "Confirmed",
    reportDate: "Aug 25, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "0.8 acres",
    lat: 9.9701,
    lng: 77.7942,
    symptoms: ["Sudden wilting of entire plant without initial chlorosis"],
    remarks: [{ id: "rem-c1", officerName: "ADO Madurai", officerRole: "Agriculture Officer", timestamp: "Aug 27, 2026", text: "Bacterial stream test positive. Drenching advised." }],
    timeline: [
      { id: "t-1", title: "Reported", description: "Uploaded wilt symptoms.", timestamp: "Aug 25, 2026", status: "New" },
      { id: "t-2", title: "Confirmed", description: "Field confirmed by officer.", timestamp: "Aug 27, 2026", status: "Confirmed" },
    ],
  },
  {
    id: "DC-1065",
    farmerId: "FARMER-019",
    farmerName: "R. Meenakshi",
    farmerPhone: "+91 98421 11019",
    crop: "Paddy (Rice)",
    disease: "Brown Planthopper",
    location: "Sholavandan",
    riskScore: 35,
    riskLevel: "Low",
    status: "Resolved",
    reportDate: "Aug 20, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.5 acres",
    lat: 10.0210,
    lng: 77.9620,
    symptoms: ["Hopper burn patches (cured)"],
    remarks: [{ id: "rem-c2", officerName: "ADO Madurai", officerRole: "Agriculture Officer", timestamp: "Aug 28, 2026", text: "Alley formation and drainage resolved the pest build-up." }],
    timeline: [
      { id: "t-1", title: "Reported", description: "Case opened.", timestamp: "Aug 20, 2026", status: "New" },
      { id: "t-2", title: "Resolved", description: "Pest cleared after biological management.", timestamp: "Aug 28, 2026", status: "Resolved" },
    ],
  },
  {
    id: "DC-1066",
    farmerId: "FARMER-020",
    farmerName: "K. Thirupathi",
    farmerPhone: "+91 98421 11020",
    crop: "Groundnut",
    disease: "Tikka Leaf Spot",
    location: "Peraiyur",
    riskScore: 40,
    riskLevel: "Low",
    status: "Resolved",
    reportDate: "Aug 22, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.0 acres",
    lat: 9.7120,
    lng: 77.7950,
    symptoms: ["Circular dark spots on upper leaf surfaces"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Resolved", description: "Foliar spray verified.", timestamp: "Aug 29, 2026", status: "Resolved" }],
  },
  {
    id: "DC-1067",
    farmerId: "FARMER-010",
    farmerName: "G. Subramanian",
    farmerPhone: "+91 98421 11010",
    crop: "Chilli",
    disease: "Chilli Leaf Curl Virus",
    location: "Thirumangalam",
    riskScore: 73,
    riskLevel: "High",
    status: "Under Review",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.2 acres",
    lat: 9.8234,
    lng: 77.9890,
    symptoms: ["Upward curling of leaves", "Stunted terminal growth", "Vector whiteflies present"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Submitted via DocCrop.", timestamp: "Sep 7, 2026", status: "Under Review" }],
  },
  {
    id: "DC-1068",
    farmerId: "FARMER-011",
    farmerName: "J. Sundaram",
    farmerPhone: "+91 98421 11011",
    crop: "Maize",
    disease: "Fall Armyworm",
    location: "Thirumangalam",
    riskScore: 85,
    riskLevel: "Critical",
    status: "Field Visit Scheduled",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "3.0 acres",
    lat: 9.8270,
    lng: 77.9925,
    symptoms: ["Shot holes in leaves", "Whorl feeding with sawdust-like frass"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Alert Raised", description: "Critical armyworm whorl attack.", timestamp: "Sep 8, 2026", status: "Field Visit Scheduled" }],
  },
  {
    id: "DC-1069",
    farmerId: "FARMER-003",
    farmerName: "P. Murugan",
    farmerPhone: "+91 98421 11003",
    crop: "Paddy (Rice)",
    disease: "Sheath Blight",
    location: "Melur",
    riskScore: 58,
    riskLevel: "Medium",
    status: "New",
    reportDate: "Sep 7, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.5 acres",
    lat: 10.0261,
    lng: 78.3340,
    symptoms: ["Oval greenish-grey lesions on leaf sheaths near water line"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "AI detected Rhizoctonia solani pattern.", timestamp: "Sep 7, 2026", status: "New" }],
  },
  {
    id: "DC-1070",
    farmerId: "FARMER-004",
    farmerName: "K. Arumugam",
    farmerPhone: "+91 98421 11004",
    crop: "Paddy (Rice)",
    disease: "Bacterial Leaf Blight",
    location: "Melur",
    riskScore: 77,
    riskLevel: "High",
    status: "Under Review",
    reportDate: "Sep 6, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.2 acres",
    lat: 10.0335,
    lng: 78.3395,
    symptoms: ["Water-soaked to yellowish stripes along leaf margins"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Reported", description: "Scan classified as high risk.", timestamp: "Sep 6, 2026", status: "Under Review" }],
  },
  {
    id: "DC-1071",
    farmerId: "FARMER-007",
    farmerName: "V. Karuppan",
    farmerPhone: "+91 98421 11007",
    crop: "Tomato",
    disease: "Late Blight",
    location: "Usilampatti",
    riskScore: 89,
    riskLevel: "Critical",
    status: "Under Investigation",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.4 acres",
    lat: 9.9734,
    lng: 77.7981,
    symptoms: ["Rapid water-soaked leaf blighting", "White fungal down on underside"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Urgent Alert", description: "Sudden late blight detected.", timestamp: "Sep 8, 2026", status: "Under Investigation" }],
  },
  {
    id: "DC-1072",
    farmerId: "FARMER-008",
    farmerName: "A. Pandian",
    farmerPhone: "+91 98421 11008",
    crop: "Brinjal",
    disease: "Shoot and Fruit Borer",
    location: "Usilampatti",
    riskScore: 65,
    riskLevel: "Medium",
    status: "Monitoring",
    reportDate: "Sep 2, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "1.0 acre",
    lat: 9.9680,
    lng: 77.7915,
    symptoms: ["Drooping tender shoots", "Bored fruit holes"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Monitoring", description: "Pheromone traps installed.", timestamp: "Sep 2, 2026", status: "Monitoring" }],
  },
  {
    id: "DC-1073",
    farmerId: "FARMER-014",
    farmerName: "L. Ramasamy",
    farmerPhone: "+91 98421 11014",
    crop: "Banana",
    disease: "Panama Wilt (Fusarium)",
    location: "Vadipatti",
    riskScore: 92,
    riskLevel: "Critical",
    status: "Field Visit Scheduled",
    reportDate: "Sep 8, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.0 acres",
    lat: 10.0792,
    lng: 77.9654,
    symptoms: ["Yellowing of lower leaf margins", "Buckling of petiole base", "Vascular discoloration in pseudostem"],
    remarks: [{ id: "rem-c3", officerName: "ADO Madurai", officerRole: "Agriculture Officer", timestamp: "Sep 8, 2026", text: "Quarantine precautions required. Urgent visit scheduled." }],
    timeline: [{ id: "t-1", title: "Critical Alert", description: "High suspicion of Fusarium wilt.", timestamp: "Sep 8, 2026", status: "Field Visit Scheduled" }],
  },
  {
    id: "DC-1074",
    farmerId: "FARMER-016",
    farmerName: "E. Senthil",
    farmerPhone: "+91 98421 11016",
    crop: "Sugarcane",
    disease: "Early Shoot Borer",
    location: "Alanganallur",
    riskScore: 48,
    riskLevel: "Low",
    status: "Resolved",
    reportDate: "Aug 15, 2026",
    assignedOfficer: "Agriculture Development Officer",
    affectedArea: "2.5 acres",
    lat: 10.0432,
    lng: 78.0821,
    symptoms: ["Dead heart symptom in young shoots (mitigated)"],
    remarks: [],
    timeline: [{ id: "t-1", title: "Resolved", description: "Trichogramma egg parasitoids released.", timestamp: "Aug 26, 2026", status: "Resolved" }],
  },
];

const SEED_HOTSPOTS: Hotspot[] = [
  {
    id: "HOTSPOT-001",
    disease: "Rice Leaf Blast",
    crop: "Paddy (Rice)",
    location: "Melur",
    affectedFarmers: 5,
    radiusKm: 1.8,
    riskScore: 84,
    severity: "HIGH",
    status: "New",
    firstReport: "Sep 4, 2026",
    latestReport: "Sep 8, 2026",
    caseIds: ["DC-1042", "DC-1045", "DC-1048", "DC-1051", "DC-1053"],
    lat: 10.0295,
    lng: 78.3365,
    trend: [
      { day: "Day 1", farmers: 1, date: "Sep 4" },
      { day: "Day 2", farmers: 2, date: "Sep 5" },
      { day: "Day 3", farmers: 4, date: "Sep 7" },
      { day: "Day 4", farmers: 5, date: "Sep 8" },
    ],
    environmental: {
      temperatureC: 27,
      humidityPercent: 86,
      soilMoisturePercent: 78,
      rainfallMm: 32,
      safetyDisclaimer: "Environmental conditions may be favorable. Officer verification recommended. Never claim environment proves disease alone.",
    },
  },
  {
    id: "HOTSPOT-002",
    disease: "Tomato Early Blight",
    crop: "Tomato",
    location: "Usilampatti",
    affectedFarmers: 4,
    radiusKm: 1.5,
    riskScore: 78,
    severity: "HIGH",
    status: "Field Visit Scheduled",
    firstReport: "Sep 5, 2026",
    latestReport: "Sep 8, 2026",
    caseIds: ["DC-1020", "DC-1021", "DC-1022", "DC-1023"],
    lat: 9.9715,
    lng: 77.7960,
    trend: [
      { day: "Day 1", farmers: 1, date: "Sep 5" },
      { day: "Day 2", farmers: 2, date: "Sep 6" },
      { day: "Day 3", farmers: 3, date: "Sep 7" },
      { day: "Day 4", farmers: 4, date: "Sep 8" },
    ],
    environmental: {
      temperatureC: 29,
      humidityPercent: 82,
      soilMoisturePercent: 65,
      rainfallMm: 18,
      safetyDisclaimer: "Environmental conditions may be favorable. Officer verification recommended.",
    },
  },
  {
    id: "HOTSPOT-003",
    disease: "American Bollworm",
    crop: "Cotton",
    location: "Thirumangalam",
    affectedFarmers: 3,
    radiusKm: 2.0,
    riskScore: 62,
    severity: "MEDIUM",
    status: "Under Investigation",
    firstReport: "Sep 5, 2026",
    latestReport: "Sep 7, 2026",
    caseIds: ["DC-1030", "DC-1031", "DC-1032"],
    lat: 9.8235,
    lng: 77.9885,
    trend: [
      { day: "Day 1", farmers: 1, date: "Sep 5" },
      { day: "Day 2", farmers: 2, date: "Sep 6" },
      { day: "Day 3", farmers: 3, date: "Sep 7" },
    ],
    environmental: {
      temperatureC: 32,
      humidityPercent: 68,
      soilMoisturePercent: 52,
      rainfallMm: 8,
      safetyDisclaimer: "Prototype indicator only. On-field scouting required for insect threshold counts.",
    },
  },
  {
    id: "HOTSPOT-004",
    disease: "Sigatoka Leaf Spot",
    crop: "Banana",
    location: "Vadipatti",
    affectedFarmers: 3,
    radiusKm: 1.2,
    riskScore: 71,
    severity: "HIGH",
    status: "Monitoring",
    firstReport: "Sep 3, 2026",
    latestReport: "Sep 5, 2026",
    caseIds: ["DC-1035", "DC-1036", "DC-1037"],
    lat: 10.0760,
    lng: 77.9620,
    trend: [
      { day: "Day 1", farmers: 1, date: "Sep 3" },
      { day: "Day 2", farmers: 2, date: "Sep 4" },
      { day: "Day 3", farmers: 3, date: "Sep 5" },
    ],
    environmental: {
      temperatureC: 28,
      humidityPercent: 88,
      soilMoisturePercent: 74,
      rainfallMm: 24,
      safetyDisclaimer: "High humidity may accelerate foliar fungal spore dispersal. Field verification advised.",
    },
  },
  {
    id: "HOTSPOT-005",
    disease: "Red Rot",
    crop: "Sugarcane",
    location: "Alanganallur",
    affectedFarmers: 3,
    radiusKm: 2.5,
    riskScore: 55,
    severity: "MEDIUM",
    status: "New",
    firstReport: "Sep 7, 2026",
    latestReport: "Sep 8, 2026",
    caseIds: ["DC-1060", "DC-1061", "DC-1062"],
    lat: 10.0430,
    lng: 78.0820,
    trend: [
      { day: "Day 1", farmers: 1, date: "Sep 7" },
      { day: "Day 2", farmers: 3, date: "Sep 8" },
    ],
    environmental: {
      temperatureC: 30,
      humidityPercent: 76,
      soilMoisturePercent: 80,
      rainfallMm: 14,
      safetyDisclaimer: "Prototype cluster assessment. Physical stalk splitting inspection recommended.",
    },
  },
];

const SEED_VISITS: FieldVisit[] = [
  {
    id: "VISIT-001",
    farmerId: "FARMER-001",
    farmerName: "R. Kumar",
    caseId: "DC-1042",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur - Plot 4B",
    dateTime: "Today, 10:30 AM",
    purpose: "Primary spore assessment and cluster boundary mapping",
    status: "In Progress",
    notes: "Farmer available on site. Inspect nursery beds as well.",
  },
  {
    id: "VISIT-002",
    farmerId: "FARMER-003",
    farmerName: "P. Murugan",
    caseId: "DC-1048",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur - East Canal Field",
    dateTime: "Today, 02:00 PM",
    purpose: "Assess neck blast symptoms and advise preventive spray",
    status: "Scheduled",
    notes: "Bring diagnostic leaf sampling kit.",
  },
  {
    id: "VISIT-003",
    farmerId: "FARMER-006",
    farmerName: "T. Balan",
    caseId: "DC-1020",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti - North Block",
    dateTime: "Tomorrow, 09:30 AM",
    purpose: "Verify early blight severity and inspect drip moisture levels",
    status: "Scheduled",
  },
  {
    id: "VISIT-004",
    farmerId: "FARMER-011",
    farmerName: "J. Sundaram",
    caseId: "DC-1068",
    crop: "Maize",
    disease: "Fall Armyworm",
    location: "Thirumangalam - Survey 142",
    dateTime: "Tomorrow, 03:00 PM",
    purpose: "Critical armyworm whorl count and pheromone trap distribution",
    status: "Scheduled",
  },
  {
    id: "VISIT-005",
    farmerId: "FARMER-014",
    farmerName: "L. Ramasamy",
    caseId: "DC-1073",
    crop: "Banana",
    disease: "Panama Wilt (Fusarium)",
    location: "Vadipatti - Riverbank Acreage",
    dateTime: "Sep 11, 2026, 11:00 AM",
    purpose: "Fusarium quarantine check and tissue sample collection",
    status: "Scheduled",
  },
  {
    id: "VISIT-006",
    farmerId: "FARMER-010",
    farmerName: "G. Subramanian",
    caseId: "DC-1030",
    crop: "Cotton",
    disease: "American Bollworm",
    location: "Thirumangalam",
    dateTime: "Sep 5, 2026, 10:00 AM",
    purpose: "Initial boll damage investigation",
    status: "Completed",
    investigation: {
      farmsInspected: 3,
      confirmedCases: 2,
      suspectedCases: 1,
      symptoms: "Boll perforation and larval feeding",
      growthStage: "Flowering & Boll formation",
      affectedArea: "3.5 acres",
      weather: "Warm and dry (32°C)",
      soilCondition: "Dry black soil",
      moisture: "Adequate",
      pestsObserved: "Helicoverpa armigera larvae",
      officerRemarks: "Moderate infestation. Advised neem seed kernel extract followed by bio-agent release.",
      assessment: "Potential Outbreak",
      completedAt: "Sep 5, 2026, 12:15 PM",
    },
  },
  {
    id: "VISIT-007",
    farmerId: "FARMER-019",
    farmerName: "R. Meenakshi",
    caseId: "DC-1065",
    crop: "Paddy (Rice)",
    disease: "Brown Planthopper",
    location: "Sholavandan",
    dateTime: "Aug 26, 2026, 11:30 AM",
    purpose: "Verify pest clearance and drainage management",
    status: "Completed",
    investigation: {
      farmsInspected: 1,
      confirmedCases: 0,
      suspectedCases: 0,
      symptoms: "Residual yellowing only, no active nymphs",
      growthStage: "Milking stage",
      affectedArea: "1.5 acres",
      weather: "Sunny (31°C)",
      soilCondition: "Drained",
      moisture: "Optimum",
      pestsObserved: "Nil",
      officerRemarks: "Case resolved successfully. Water level kept low.",
      assessment: "False Alarm",
      completedAt: "Aug 26, 2026, 01:00 PM",
    },
  },
  {
    id: "VISIT-008",
    farmerId: "FARMER-002",
    farmerName: "M. Selvam",
    caseId: "DC-1045",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    dateTime: "Sep 7, 2026, 04:00 PM",
    purpose: "Perimeter check on blast spread to adjacent holdings",
    status: "Completed",
    investigation: {
      farmsInspected: 4,
      confirmedCases: 3,
      suspectedCases: 1,
      symptoms: "Typical spindle blast lesions",
      growthStage: "Tillering",
      affectedArea: "3.1 acres",
      weather: "Humid overcast",
      soilCondition: "Saturated clay loam",
      moisture: "High",
      pestsObserved: "Nil",
      officerRemarks: "High humidity fostering fungal sporulation. Linked to HOTSPOT-001.",
      assessment: "Confirmed Outbreak",
      completedAt: "Sep 7, 2026, 05:30 PM",
    },
  },
  {
    id: "VISIT-009",
    farmerId: "FARMER-016",
    farmerName: "E. Senthil",
    caseId: "DC-1060",
    crop: "Sugarcane",
    disease: "Red Rot",
    location: "Alanganallur",
    dateTime: "Sep 6, 2026, 10:00 AM",
    purpose: "Investigate reported midrib reddening",
    status: "Overdue" as VisitStatus,
    notes: "Reschedule required due to administrative duty.",
  },
  {
    id: "VISIT-010",
    farmerId: "FARMER-008",
    farmerName: "A. Pandian",
    caseId: "DC-1022",
    crop: "Tomato",
    disease: "Early Blight",
    location: "Usilampatti",
    dateTime: "Sep 7, 2026, 02:00 PM",
    purpose: "Check defoliation rate in tomato field",
    status: "Overdue" as VisitStatus,
  },
  {
    id: "VISIT-011",
    farmerId: "FARMER-013",
    farmerName: "N. Palanivel",
    caseId: "DC-1035",
    crop: "Banana",
    disease: "Sigatoka Leaf Spot",
    location: "Vadipatti",
    dateTime: "Sep 4, 2026, 03:00 PM",
    purpose: "Routine banana health check and phytosanitation advice",
    status: "Completed",
    investigation: {
      farmsInspected: 2,
      confirmedCases: 2,
      suspectedCases: 0,
      symptoms: "Yellow sigatoka streaks",
      growthStage: "Shooting",
      affectedArea: "1.8 acres",
      weather: "Rainy (26°C)",
      soilCondition: "Wet loam",
      moisture: "Very High",
      pestsObserved: "Nil",
      officerRemarks: "Leaf pruning enforced. Foliar mineral oil spray advised.",
      assessment: "Requires Further Monitoring",
      completedAt: "Sep 4, 2026, 04:30 PM",
    },
  },
  {
    id: "VISIT-012",
    farmerId: "FARMER-007",
    farmerName: "V. Karuppan",
    caseId: "DC-1071",
    crop: "Tomato",
    disease: "Late Blight",
    location: "Usilampatti",
    dateTime: "Sep 12, 2026, 10:00 AM",
    purpose: "Emergency late blight inspection",
    status: "Scheduled",
  },
  {
    id: "VISIT-013",
    farmerId: "FARMER-017",
    farmerName: "H. Natarajan",
    caseId: "DC-1061",
    crop: "Sugarcane",
    disease: "Red Rot",
    location: "Alanganallur",
    dateTime: "Sep 13, 2026, 11:30 AM",
    purpose: "Field sample culture collection",
    status: "Scheduled",
  },
  {
    id: "VISIT-014",
    farmerId: "FARMER-005",
    farmerName: "S. Rajendran",
    caseId: "DC-1053",
    crop: "Paddy (Rice)",
    disease: "Rice Leaf Blast",
    location: "Melur",
    dateTime: "Sep 14, 2026, 09:30 AM",
    purpose: "Evaluate recovery post-fungicide spray",
    status: "Scheduled",
  },
  {
    id: "VISIT-015",
    farmerId: "FARMER-020",
    farmerName: "K. Thirupathi",
    caseId: "DC-1066",
    crop: "Groundnut",
    disease: "Tikka Leaf Spot",
    location: "Peraiyur",
    dateTime: "Aug 28, 2026, 02:30 PM",
    purpose: "Post-harvest soil and stubble sanitation check",
    status: "Completed",
    investigation: {
      farmsInspected: 1,
      confirmedCases: 0,
      suspectedCases: 0,
      symptoms: "Nil",
      growthStage: "Pod maturity",
      affectedArea: "2.0 acres",
      weather: "Clear (33°C)",
      soilCondition: "Dry",
      moisture: "Low",
      pestsObserved: "Nil",
      officerRemarks: "Deep summer plowing recommended to bury infested crop debris.",
      assessment: "False Alarm",
      completedAt: "Aug 28, 2026, 03:45 PM",
    },
  },
];

const SEED_NOTIFICATIONS: OfficerNotification[] = [
  { id: "NOTIF-001", category: "Urgent", title: "🚨 HIGH RISK Hotspot in Melur", body: "Rice Leaf Blast detected across 5 farms within 1.8 km radius. Risk Score: 84/100.", timestamp: "10 mins ago", read: false, archived: false, priority: "Critical", hotspotId: "HOTSPOT-001" },
  { id: "NOTIF-002", category: "Cases", title: "New Critical Case DC-1073", body: "L. Ramasamy (Vadipatti) submitted Banana scan with severe Panama Wilt symptoms.", timestamp: "25 mins ago", read: false, archived: false, priority: "Critical", caseId: "DC-1073" },
  { id: "NOTIF-003", category: "Field Visits", title: "Field Visit In Progress", body: "Visit VISIT-001 at R. Kumar field (Melur) is currently ongoing.", timestamp: "45 mins ago", read: false, archived: false, priority: "Normal", visitId: "VISIT-001" },
  { id: "NOTIF-004", category: "Hotspots", title: "Hotspot Growth Alert: HOTSPOT-001", body: "Melur cluster grew from 2 to 5 affected farmers over the past 48 hours.", timestamp: "2 hours ago", read: false, archived: false, priority: "High", hotspotId: "HOTSPOT-001" },
  { id: "NOTIF-005", category: "Urgent", title: "Critical Fall Armyworm Warning", body: "J. Sundaram (Thirumangalam) reported heavy whorl destruction on 3 acres of maize.", timestamp: "3 hours ago", read: false, archived: false, priority: "High", caseId: "DC-1068" },
  { id: "NOTIF-006", category: "Hotspots", title: "High Moisture Trigger", body: "Environmental sensor near Melur recorded 86% humidity and 78% soil moisture.", timestamp: "4 hours ago", read: true, archived: false, priority: "Normal", hotspotId: "HOTSPOT-001" },
  { id: "NOTIF-007", category: "Field Visits", title: "Overdue Visit Reminder", body: "VISIT-009 for E. Senthil (Sugarcane Red Rot, Alanganallur) is past due date.", timestamp: "Yesterday", read: false, archived: false, priority: "High", visitId: "VISIT-009" },
  { id: "NOTIF-008", category: "Cases", title: "Case Status Updated: DC-1048", body: "Status advanced to Field Visit Scheduled by system dispatch.", timestamp: "Yesterday", read: true, archived: false, priority: "Normal", caseId: "DC-1048" },
  { id: "NOTIF-009", category: "Hotspots", title: "New Hotspot Formed: HOTSPOT-002", body: "Tomato Early Blight cluster detected in Usilampatti with 4 affected farmers.", timestamp: "Yesterday", read: true, archived: false, priority: "High", hotspotId: "HOTSPOT-002" },
  { id: "NOTIF-010", category: "System", title: "Weekly Disease Summary Ready", body: "Weekly epidemiological bulletin for Madurai Agricultural Division generated.", timestamp: "2 days ago", read: true, archived: false, priority: "Normal" },
  { id: "NOTIF-011", category: "Field Visits", title: "Field Visit Completed: VISIT-008", body: "Investigation filed for M. Selvam. Confirmed Outbreak recorded.", timestamp: "2 days ago", read: true, archived: false, priority: "Normal", visitId: "VISIT-008" },
  { id: "NOTIF-012", category: "Cases", title: "Farmer Feedback Received", body: "R. Meenakshi rated your expert advice 5 stars for brown planthopper management.", timestamp: "3 days ago", read: true, archived: false, priority: "Normal" },
  { id: "NOTIF-013", category: "Hotspots", title: "Cotton Bollworm Alert: HOTSPOT-003", body: "Thirumangalam cluster monitoring threshold reached 3 affected holdings.", timestamp: "3 days ago", read: true, archived: false, priority: "Normal", hotspotId: "HOTSPOT-003" },
  { id: "NOTIF-014", category: "Urgent", title: "High Risk Scan: DC-1071", body: "Late Blight confirmed in Usilampatti tomato field. Immediate containment advised.", timestamp: "4 days ago", read: true, archived: false, priority: "High", caseId: "DC-1071" },
  { id: "NOTIF-015", category: "System", title: "Rainfall Advisory Issued", body: "Heavy rain forecasted in western taluks over next 48 hours. Fungal risk elevated.", timestamp: "4 days ago", read: true, archived: false, priority: "Normal" },
  { id: "NOTIF-016", category: "Field Visits", title: "Visit Scheduled: VISIT-002", body: "Visit scheduled with P. Murugan for Rice Leaf Blast verification today 2:00 PM.", timestamp: "5 days ago", read: true, archived: false, priority: "Normal", visitId: "VISIT-002" },
  { id: "NOTIF-017", category: "Cases", title: "Dealer Referral Alert", body: "Murugan Agro Centre referred a farmer case for suspected bacterial wilt.", timestamp: "5 days ago", read: true, archived: false, priority: "Normal" },
  { id: "NOTIF-018", category: "Hotspots", title: "Sigatoka Monitoring Active", body: "HOTSPOT-004 in Vadipatti classified under Active Monitoring status.", timestamp: "6 days ago", read: true, archived: false, priority: "Normal", hotspotId: "HOTSPOT-004" },
  { id: "NOTIF-019", category: "Cases", title: "Case Resolved: DC-1066", body: "Groundnut Tikka Leaf Spot case in Peraiyur marked Resolved after treatment.", timestamp: "Aug 29, 2026", read: true, archived: false, priority: "Normal", caseId: "DC-1066" },
  { id: "NOTIF-020", category: "System", title: "System Security & Sync", body: "Offline database synchronized with State Agriculture Directorate repository.", timestamp: "Aug 28, 2026", read: true, archived: false, priority: "Normal" },
];

// ---------------- LOCAL STORAGE READ/WRITE HELPERS ----------------
function load<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Failed to load ${key}:`, e);
    return fallback;
  }
}

function save<T>(key: string, val: T): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.error(`Failed to save ${key}:`, e);
  }
}

// ---------------- AUTHENTICATION ----------------
export interface OfficerAccount {
  officerId: string;
  name: string;
  password: string; // Demo-only frontend credential; backend must hash this in production.
  division: string;
  assignedArea: string;
  district: string;
}

export interface OfficerSession {
  officerId: string;
  name: string;
  division: string;
  assignedArea: string;
  district: string;
  authenticated: boolean;
  loginTime: string;
}

// Demo officer directory. In a backend deployment these records should live in
// MongoDB with password hashes and an admin-managed area assignment.
export const OFFICER_ACCOUNTS: OfficerAccount[] = [
  { officerId: "AO-MDU-1042", name: "Agriculture Development Officer", password: "demo123", division: "Madurai Agricultural Division", assignedArea: "Madurai", district: "Madurai" },
  { officerId: "AO-VNR-2081", name: "Virudhunagar Agriculture Officer", password: "demo123", division: "Virudhunagar Agricultural Division", assignedArea: "Virudhunagar", district: "Virudhunagar" },
  { officerId: "AO-SIV-3017", name: "Sivakasi Agriculture Officer", password: "demo123", division: "Sivakasi Agricultural Block", assignedArea: "Sivakasi", district: "Virudhunagar" },
];

export function isOfficerAuthenticated(): boolean {
  const session = load<OfficerSession | null>(KEYS.SESSION, null);
  return Boolean(session?.authenticated);
}

export function getOfficerSession(): OfficerSession | null {
  return load<OfficerSession | null>(KEYS.SESSION, null);
}

export function getAssignedArea(): string {
  return getOfficerSession()?.assignedArea || "Madurai";
}

export function loginOfficer(officerId: string, password: string): { success: boolean; message: string } {
  const cleanId = officerId.trim().toUpperCase();
  const cleanPass = password.trim();
  const account = OFFICER_ACCOUNTS.find((o) => o.officerId.toUpperCase() === cleanId && o.password === cleanPass);

  if (!account) {
    return { success: false, message: "Invalid Officer ID or Password." };
  }

  const session: OfficerSession = {
    officerId: account.officerId,
    name: account.name,
    division: account.division,
    assignedArea: account.assignedArea,
    district: account.district,
    authenticated: true,
    loginTime: new Date().toISOString(),
  };
  save(KEYS.SESSION, session);
  // Keep the profile aligned with the logged-in officer for all dashboard screens.
  save(KEYS.PROFILE, { ...SEED_PROFILE, id: account.officerId, name: account.name, division: account.division, location: account.assignedArea, email: `${account.officerId.toLowerCase()}@agri.tn.gov.in` });
  return { success: true, message: "Login successful" };
}

export function logoutOfficer(): void {
  if (typeof window !== "undefined") localStorage.removeItem(KEYS.SESSION);
}

// ---------------- LANGUAGE & SETTINGS ----------------
export function getSelectedLanguage(): string {
  if (typeof window === "undefined") return "English";
  return localStorage.getItem(KEYS.SELECTED_LANG) || "English";
}

export function setSelectedLanguage(lang: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEYS.SELECTED_LANG, lang);
  const settings = getSettings();
  settings.language = lang as any;
  updateSettings(settings);
}

export function getOfficerProfile(): OfficerProfile {
  const session = getOfficerSession();
  const stored = load<OfficerProfile>(KEYS.PROFILE, SEED_PROFILE);
  if (!session) return stored;
  return { ...stored, id: session.officerId, name: session.name, division: session.division, location: session.assignedArea };
}

export function updateOfficerProfile(profile: Partial<OfficerProfile>): OfficerProfile {
  const current = getOfficerProfile();
  const updated = { ...current, ...profile };
  save(KEYS.PROFILE, updated);
  return updated;
}

export function getSettings(): OfficerSettings {
  return load<OfficerSettings>(KEYS.SETTINGS, SEED_SETTINGS);
}

export function updateSettings(settings: Partial<OfficerSettings>): OfficerSettings {
  const current = getSettings();
  const updated = { ...current, ...settings };
  save(KEYS.SETTINGS, updated);
  return updated;
}

export function resetSettings(): OfficerSettings {
  save(KEYS.SETTINGS, SEED_SETTINGS);
  return SEED_SETTINGS;
}

// ---------------- CASES ----------------
export function getCases(): OfficerCase[] {
  return load<OfficerCase[]>(KEYS.CASES, SEED_CASES);
}

export function getCaseById(id: string): OfficerCase | undefined {
  const cases = getCases();
  return cases.find((c) => c.id === id);
}

export function updateCaseStatus(id: string, status: CaseStatus, officerNote?: string): OfficerCase | null {
  const cases = getCases();
  const idx = cases.findIndex((c) => c.id === id);
  if (idx === -1) return null;

  const target = cases[idx];
  target.status = status;
  const now = new Date();
  const timeStr = now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) + " " + now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  target.timeline.unshift({
    id: "tl-" + Date.now(),
    title: `Status changed to ${status}`,
    description: officerNote || `Officer updated case status to ${status}.`,
    timestamp: timeStr,
    status,
  });

  if (officerNote) {
    target.remarks.unshift({
      id: "rem-" + Date.now(),
      officerName: "ADO Madurai",
      officerRole: "Agriculture Officer",
      timestamp: timeStr,
      text: officerNote,
    });
  }

  save(KEYS.CASES, cases);

  // Generate automated notification
  addNotification({
    category: "Cases",
    title: `Case ${id} Updated`,
    body: `Status set to ${status}.`,
    priority: status === "Confirmed" ? "High" : "Normal",
    caseId: id,
  });

  return target;
}

export function addCaseRemark(id: string, text: string): OfficerCase | null {
  const cases = getCases();
  const target = cases.find((c) => c.id === id);
  if (!target) return null;

  const now = new Date();
  const timeStr = now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) + " " + now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  target.remarks.unshift({
    id: "rem-" + Date.now(),
    officerName: "ADO Madurai",
    officerRole: "Agriculture Officer",
    timestamp: timeStr,
    text,
  });

  save(KEYS.CASES, cases);
  return target;
}

// ---------------- FARMERS ----------------
export function getFarmers(): Farmer[] {
  return load<Farmer[]>(KEYS.FARMERS, SEED_FARMERS);
}

export function getFarmerById(id: string): Farmer | undefined {
  const farmers = getFarmers();
  return farmers.find((f) => f.id === id);
}

export function addFarmerRemark(id: string, text: string): Farmer | null {
  const farmers = getFarmers();
  const target = farmers.find((f) => f.id === id);
  if (!target) return null;

  target.remarks.unshift(text);
  save(KEYS.FARMERS, farmers);
  return target;
}

// ---------------- HOTSPOTS / GEO-FENCING ----------------
// Geo-fence rule: whenever 2 or more distinct farmers inside the same
// clustering radius report the SAME disease (on the same crop) within the
// configured recency window, that patch of land is flagged as a disease
// cluster and the officer is notified — even before it grows into a full
// "field visit required" hotspot (which needs settings.hotspotConfig
// minimumAffectedFarmers, default 3).
const GEO_FENCE_MIN_FARMERS = 2;

const KEYS_GEO_NOTIFIED = "doccrop_officer_geofence_notified"; // { [hotspotId]: lastNotifiedFarmerCount }

// Fallback / demo environmental readings, keyed by village so newly detected
// clusters in a known village still show sensible conditions. Unknown
// villages get a neutral placeholder instead of fabricated sensor data.
const ENV_BY_LOCATION: Record<string, EnvironmentalData> = {
  Melur: { temperatureC: 27, humidityPercent: 86, soilMoisturePercent: 78, rainfallMm: 32, safetyDisclaimer: "Environmental conditions may be favorable. Officer verification recommended. Never claim environment proves disease alone." },
  Usilampatti: { temperatureC: 29, humidityPercent: 82, soilMoisturePercent: 65, rainfallMm: 18, safetyDisclaimer: "Environmental conditions may be favorable. Officer verification recommended." },
  Thirumangalam: { temperatureC: 32, humidityPercent: 68, soilMoisturePercent: 52, rainfallMm: 8, safetyDisclaimer: "Prototype indicator only. On-field scouting required for insect threshold counts." },
  Vadipatti: { temperatureC: 28, humidityPercent: 88, soilMoisturePercent: 74, rainfallMm: 24, safetyDisclaimer: "High humidity may accelerate foliar fungal spore dispersal. Field verification advised." },
  Alanganallur: { temperatureC: 30, humidityPercent: 76, soilMoisturePercent: 80, rainfallMm: 14, safetyDisclaimer: "Prototype cluster assessment. Physical stalk splitting inspection recommended." },
};

function estimateEnvironmental(location: string): EnvironmentalData {
  return (
    ENV_BY_LOCATION[location] ?? {
      temperatureC: 29,
      humidityPercent: 75,
      soilMoisturePercent: 60,
      rainfallMm: 12,
      safetyDisclaimer: "No live sensor data for this village yet. Prototype estimate only — officer field verification required.",
    }
  );
}

function slugifyHotspotPart(s: string) {
  return s.toUpperCase().replace(/[^A-Z0-9]+/g, "").slice(0, 12);
}

function daysBetween(dateStr: string, now: Date): number {
  const t = new Date(dateStr).getTime();
  if (Number.isNaN(t)) return 0;
  return Math.round((now.getTime() - t) / (24 * 60 * 60 * 1000));
}

function severityForCount(affectedFarmers: number, minimumAffectedFarmers: number): Hotspot["severity"] {
  if (affectedFarmers > 5) return "CRITICAL";
  if (affectedFarmers >= Math.max(4, minimumAffectedFarmers)) return "HIGH";
  if (affectedFarmers >= 3) return "MEDIUM";
  return "MONITORING"; // exactly the 2-farmer geo-fence trigger tier
}

// Haversine distance formula in kilometers
export function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Real geo-fencing / cluster detection.
 *
 * For every disease (per crop), farmers are grouped into geographic clusters
 * using union-find: any two case reports within `config.clusterRadiusKm` of
 * each other are linked into the same cluster. Only reports from the last
 * `config.timeWindowDays` count toward the cluster. Once a cluster reaches
 * GEO_FENCE_MIN_FARMERS (2) distinct farmers it becomes a flagged cluster;
 * once it reaches `config.minimumAffectedFarmers` it is treated as a
 * priority hotspot requiring a field visit.
 *
 * Known demo hotspots (HOTSPOT-001..005) keep their original id/status so
 * existing links from cases and dashboards keep working — but their
 * affected-farmer count, severity and risk score are now computed live from
 * the actual case list instead of being hardcoded.
 */
export function detectDiseaseHotspots(
  cases: OfficerCase[] = getCases(),
  config = getSettings().hotspotConfig
): Hotspot[] {
  const now = new Date();
  const byKey = new Map<string, OfficerCase[]>();
  for (const c of cases) {
    const key = `${c.crop}::${c.disease}`;
    byKey.set(key, [...(byKey.get(key) ?? []), c]);
  }

  const results: Hotspot[] = [];

  for (const [, group] of byKey) {
    const recent = group.filter((c) => daysBetween(c.reportDate, now) <= config.timeWindowDays || Number.isNaN(new Date(c.reportDate).getTime()));

    const parent = recent.map((_, i) => i);
    const find = (i: number): number => {
      const p = parent[i] ?? i;
      if (p === i) return i;
      const root = find(p);
      parent[i] = root;
      return root;
    };
    const union = (a: number, b: number) => {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent[ra] = rb;
    };
    for (let i = 0; i < recent.length; i++) {
      for (let j = i + 1; j < recent.length; j++) {
        const ci = recent[i];
        const cj = recent[j];
        if (ci && cj && haversineDistanceKm(ci.lat, ci.lng, cj.lat, cj.lng) <= config.clusterRadiusKm) {
          union(i, j);
        }
      }
    }

    const clusters = new Map<number, OfficerCase[]>();
    recent.forEach((c, i) => {
      const root = find(i);
      clusters.set(root, [...(clusters.get(root) ?? []), c]);
    });

    for (const [, clusterCases] of clusters) {
      const affectedFarmers = new Set(clusterCases.map((c) => c.farmerId)).size;
      // GEO-FENCE RULE: 2 or more farmers, same disease, same area -> flag it.
      if (affectedFarmers < GEO_FENCE_MIN_FARMERS) continue;

      const lats = clusterCases.map((c) => c.lat);
      const lngs = clusterCases.map((c) => c.lng);
      const lat = lats.reduce((a, b) => a + b, 0) / lats.length;
      const lng = lngs.reduce((a, b) => a + b, 0) / lngs.length;
      const radiusKm = Math.max(0.3, ...clusterCases.map((c) => haversineDistanceKm(lat, lng, c.lat, c.lng)));

      const sorted = [...clusterCases].sort((a, b) => new Date(a.reportDate).getTime() - new Date(b.reportDate).getTime());
      const first = sorted[0];
      const last = sorted[sorted.length - 1];
      if (!first || !last) continue;

      const location = mostCommonLocation(clusterCases);
      const avgRisk = clusterCases.reduce((a, c) => a + c.riskScore, 0) / clusterCases.length;
      const concentration = radiusKm <= config.clusterRadiusKm * 0.6 ? 1 : radiusKm <= config.clusterRadiusKm ? 0.6 : 0.3;
      const riskScore = Math.round(
        Math.min(100, Math.min(1, affectedFarmers / 6) * 40 + (avgRisk / 100) * 35 + concentration * 25)
      );

      // Re-use an existing seeded hotspot's id/status if this cluster is the
      // same one (majority of its cases already carry that hotspotId), so
      // links from case records and other screens keep working.
      const hotspotIdVotes = new Map<string, number>();
      for (const c of clusterCases) {
        if (c.hotspotId) hotspotIdVotes.set(c.hotspotId, (hotspotIdVotes.get(c.hotspotId) ?? 0) + 1);
      }
      const matchedId = [...hotspotIdVotes.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
      const seedMatch = matchedId ? SEED_HOTSPOTS.find((h) => h.id === matchedId) : undefined;

      const id = seedMatch?.id ?? `HOTSPOT-${slugifyHotspotPart(first.disease)}-${slugifyHotspotPart(location)}`;
      const trend: HotspotTrendPoint[] = sorted.map((c, i) => ({
        day: `Day ${i + 1}`,
        farmers: new Set(sorted.slice(0, i + 1).map((s) => s.farmerId)).size,
        date: c.reportDate,
      }));

      results.push({
        id,
        disease: first.disease,
        crop: first.crop,
        location,
        affectedFarmers,
        radiusKm: Math.round(radiusKm * 10) / 10,
        riskScore,
        severity: severityForCount(affectedFarmers, config.minimumAffectedFarmers),
        status: seedMatch?.status ?? "New",
        firstReport: first.reportDate,
        latestReport: last.reportDate,
        caseIds: clusterCases.map((c) => c.id),
        lat,
        lng,
        trend,
        environmental: seedMatch?.environmental ?? estimateEnvironmental(location),
      });
    }
  }

  return results.sort((a, b) => b.riskScore - a.riskScore);
}

function mostCommonLocation(cases: OfficerCase[]): string {
  const counts = new Map<string, number>();
  for (const c of cases) counts.set(c.location, (counts.get(c.location) ?? 0) + 1);
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] ?? cases[0]?.location ?? "Unknown";
}

/**
 * Idempotently notifies the officer whenever a geo-fenced cluster is newly
 * detected, or grows to affect more farmers than it did the last time we
 * checked. This is what actually implements "if 2+ people in one area are
 * affected by the same disease, notify the officer".
 */
function seedGeoFenceNotifications(hotspots: Hotspot[]): void {
  const lastNotified = load<Record<string, number>>(KEYS_GEO_NOTIFIED, {});
  let changed = false;

  for (const h of hotspots) {
    const previous = lastNotified[h.id] ?? 0;
    if (h.affectedFarmers <= previous) continue; // nothing new to say

    const crossedFieldVisitThreshold = previous < getSettings().hotspotConfig.minimumAffectedFarmers && h.affectedFarmers >= getSettings().hotspotConfig.minimumAffectedFarmers;

    addNotification({
      category: "Hotspots",
      title: crossedFieldVisitThreshold
        ? `🚨 Disease Hotspot: ${h.location}`
        : `⚠️ Disease Cluster Alert: ${h.location}`,
      body: crossedFieldVisitThreshold
        ? `${h.affectedFarmers} farmers in ${h.location} now report ${h.disease} within ${h.radiusKm} km of each other. Field visit recommended.`
        : `${h.affectedFarmers} farmers within ${h.radiusKm} km in ${h.location} have reported ${h.disease}. Geo-fence monitoring activated for this area — watch for further reports.`,
      priority: crossedFieldVisitThreshold ? "High" : "Normal",
      hotspotId: h.id,
    });

    lastNotified[h.id] = h.affectedFarmers;
    changed = true;
  }

  if (changed) save(KEYS_GEO_NOTIFIED, lastNotified);
}

export function getHotspots(): Hotspot[] {
  const hotspots = detectDiseaseHotspots(getCases(), getSettings().hotspotConfig);
  seedGeoFenceNotifications(hotspots);
  return hotspots;
}

export function getHotspotById(id: string): Hotspot | undefined {
  const hotspots = getHotspots();
  return hotspots.find((h) => h.id === id);
}

// Moisture risk calculation utility
export function calculateMoistureRisk(cropData: {
  temperatureC: number;
  humidityPercent: number;
  soilMoisturePercent: number;
  rainfallMm: number;
}): {
  moistureCondition: "Optimal" | "Moderate Risk" | "High Fungal Risk" | "Water Stress";
  waterStressRisk: "Low" | "Moderate" | "High";
  excessMoistureRisk: "Low" | "Moderate" | "Critical";
  environmentalRiskScore: number;
  recommendation: string;
  safetyDisclaimer: string;
} {
  const { humidityPercent, soilMoisturePercent, rainfallMm } = cropData;
  let score = 20;

  if (humidityPercent > 80) score += 35;
  else if (humidityPercent > 65) score += 20;

  if (soilMoisturePercent > 75) score += 30;
  else if (soilMoisturePercent > 60) score += 15;

  if (rainfallMm > 25) score += 15;

  let moistureCondition: "Optimal" | "Moderate Risk" | "High Fungal Risk" | "Water Stress" = "Optimal";
  let excessRisk: "Low" | "Moderate" | "Critical" = "Low";
  let stressRisk: "Low" | "Moderate" | "High" = "Low";

  if (score >= 75) {
    moistureCondition = "High Fungal Risk";
    excessRisk = "Critical";
  } else if (score >= 50) {
    moistureCondition = "Moderate Risk";
    excessRisk = "Moderate";
  } else if (soilMoisturePercent < 30) {
    moistureCondition = "Water Stress";
    stressRisk = "High";
  }

  return {
    moistureCondition,
    waterStressRisk: stressRisk,
    excessMoistureRisk: excessRisk,
    environmentalRiskScore: Math.min(100, score),
    recommendation:
      score >= 75
        ? "Environmental conditions may be favorable for fungal sporulation. Inspect lower canopy and ensure drainage."
        : "Moisture levels within acceptable range. Routine scouting recommended.",
    safetyDisclaimer:
      "Prototype assessment only. Environmental factors do not confirm disease without on-site diagnostic verification.",
  };
}

// ---------------- FIELD VISITS & INVESTIGATION ----------------
export function getFieldVisits(): FieldVisit[] {
  return load<FieldVisit[]>(KEYS.VISITS, SEED_VISITS);
}

export function getFieldVisitById(id: string): FieldVisit | undefined {
  const visits = getFieldVisits();
  return visits.find((v) => v.id === id);
}

export function createFieldVisit(data: {
  farmerId: string;
  farmerName: string;
  caseId: string;
  crop: string;
  disease: string;
  location: string;
  dateTime: string;
  purpose: string;
  notes?: string;
}): FieldVisit {
  const visits = getFieldVisits();
  const newVisit: FieldVisit = {
    id: `VISIT-${String(visits.length + 1).padStart(3, "0")}`,
    farmerId: data.farmerId,
    farmerName: data.farmerName,
    caseId: data.caseId,
    crop: data.crop,
    disease: data.disease,
    location: data.location,
    dateTime: data.dateTime,
    purpose: data.purpose,
    status: "Scheduled",
    notes: data.notes,
  };

  visits.unshift(newVisit);
  save(KEYS.VISITS, visits);

  // Update corresponding case status
  if (data.caseId) {
    updateCaseStatus(data.caseId, "Field Visit Scheduled", `Field visit ${newVisit.id} scheduled for ${data.dateTime}.`);
  }

  addNotification({
    category: "Field Visits",
    title: `Field Visit Scheduled (${newVisit.id})`,
    body: `Scheduled for ${data.farmerName} at ${data.location}.`,
    priority: "Normal",
    visitId: newVisit.id,
  });

  return newVisit;
}

export function updateFieldVisitStatus(id: string, status: VisitStatus, notes?: string): FieldVisit | null {
  const visits = getFieldVisits();
  const target = visits.find((v) => v.id === id);
  if (!target) return null;

  target.status = status;
  if (notes) target.notes = (target.notes ? target.notes + " | " : "") + notes;

  save(KEYS.VISITS, visits);

  if (target.caseId && status === "In Progress") {
    updateCaseStatus(target.caseId, "Under Investigation", `Field investigation underway by officer.`);
  }

  return target;
}

export function submitInvestigation(visitId: string, investigation: InvestigationData): FieldVisit | null {
  const visits = getFieldVisits();
  const target = visits.find((v) => v.id === visitId);
  if (!target) return null;

  target.status = "Completed";
  target.investigation = investigation;
  save(KEYS.VISITS, visits);

  // Master Prompt Section 28 Assessment Mapping:
  // Confirmed Outbreak -> Confirmed
  // Potential Outbreak -> Monitoring
  // False Alarm -> Resolved
  // Requires Further Monitoring -> Monitoring
  let mappedCaseStatus: CaseStatus = "Monitoring";
  if (investigation.assessment === "Confirmed Outbreak") {
    mappedCaseStatus = "Confirmed";
  } else if (investigation.assessment === "Potential Outbreak") {
    mappedCaseStatus = "Monitoring";
  } else if (investigation.assessment === "False Alarm") {
    mappedCaseStatus = "Resolved";
  } else if (investigation.assessment === "Requires Further Monitoring") {
    mappedCaseStatus = "Monitoring";
  }

  if (target.caseId) {
    updateCaseStatus(
      target.caseId,
      mappedCaseStatus,
      `Investigation filed (${investigation.assessment}). Farms inspected: ${investigation.farmsInspected}. Officer note: ${investigation.officerRemarks}`
    );
  }

  addNotification({
    category: "Field Visits",
    title: `Investigation Completed: ${visitId}`,
    body: `Outcome: ${investigation.assessment}. Status updated to ${mappedCaseStatus}.`,
    priority: investigation.assessment === "Confirmed Outbreak" ? "High" : "Normal",
    visitId,
    caseId: target.caseId,
  });

  return target;
}

// ---------------- NOTIFICATIONS ----------------
export function getNotifications(): OfficerNotification[] {
  return load<OfficerNotification[]>(KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
}

export function addNotification(n: Omit<OfficerNotification, "id" | "timestamp" | "read" | "archived">): OfficerNotification {
  const notifs = getNotifications();
  const newNotif: OfficerNotification = {
    ...n,
    id: `NOTIF-${String(Date.now()).slice(-4)}`,
    timestamp: "Just now",
    read: false,
    archived: false,
  };
  notifs.unshift(newNotif);
  save(KEYS.NOTIFICATIONS, notifs);
  return newNotif;
}

export function markNotificationRead(id: string): void {
  const notifs = getNotifications();
  const target = notifs.find((n) => n.id === id);
  if (target) {
    target.read = true;
    save(KEYS.NOTIFICATIONS, notifs);
  }
}

export function markAllNotificationsRead(): void {
  const notifs = getNotifications();
  notifs.forEach((n) => (n.read = true));
  save(KEYS.NOTIFICATIONS, notifs);
}

export function archiveNotification(id: string): void {
  const notifs = getNotifications();
  const target = notifs.find((n) => n.id === id);
  if (target) {
    target.archived = true;
    save(KEYS.NOTIFICATIONS, notifs);
  }
}

export function getUnreadNotificationCount(): number {
  return getNotifications().filter((n) => !n.read && !n.archived).length;
}

// ---------------- REPORTS ----------------
export interface ReportSummary {
  period: string;
  totalCases: number;
  confirmedDiseases: number;
  highRiskCases: number;
  hotspotsCount: number;
  fieldVisitsCompleted: number;
  affectedFarmers: number;
  diseaseDistribution: { name: string; count: number }[];
  riskDistribution: { name: string; count: number; color: string }[];
  visitCompletionRate: number; // percentage
}

export function getReports(period: "Today" | "7 Days" | "30 Days" | "90 Days" | "All" = "7 Days"): ReportSummary {
  const cases = getCases();
  const hotspots = getHotspots();
  const visits = getFieldVisits();
  const farmers = getFarmers();

  const confirmedCount = cases.filter((c) => c.status === "Confirmed").length;
  const highRiskCount = cases.filter((c) => c.riskLevel === "High" || c.riskLevel === "Critical").length;
  const completedVisits = visits.filter((v) => v.status === "Completed").length;

  const diseaseCounts: Record<string, number> = {};
  cases.forEach((c) => {
    diseaseCounts[c.disease] = (diseaseCounts[c.disease] || 0) + 1;
  });

  const diseaseDistribution = Object.entries(diseaseCounts).map(([name, count]) => ({ name, count }));

  const riskCounts = {
    Critical: cases.filter((c) => c.riskLevel === "Critical").length,
    High: cases.filter((c) => c.riskLevel === "High").length,
    Medium: cases.filter((c) => c.riskLevel === "Medium").length,
    Low: cases.filter((c) => c.riskLevel === "Low").length,
  };

  const riskDistribution = [
    { name: "Critical", count: riskCounts.Critical, color: "#dc2626" },
    { name: "High", count: riskCounts.High, color: "#ea580c" },
    { name: "Medium", count: riskCounts.Medium, color: "#eab308" },
    { name: "Low", count: riskCounts.Low, color: "#16a34a" },
  ];

  return {
    period,
    totalCases: cases.length,
    confirmedDiseases: confirmedCount,
    highRiskCases: highRiskCount,
    hotspotsCount: hotspots.length,
    fieldVisitsCompleted: completedVisits,
    affectedFarmers: farmers.length,
    diseaseDistribution,
    riskDistribution,
    visitCompletionRate: Math.round((completedVisits / Math.max(1, visits.length)) * 100),
  };
}
