// Mock OTP flow for the Farmer login screen.
// Prototype-only: there's no SMS backend, so DocCrop always issues the same
// demo code and shows it in an on-screen banner (a "message notify at the
// top") instead of actually texting it — this matches how the hackathon
// jury/demo needs to log in without a real phone gateway.

export const DEMO_OTP = "123456";

const KEY = "doccrop.otp";

export type OtpState = { mobile: string; code: string; generatedAt: string; verified: boolean };

export function generateOtp(mobile: string): OtpState {
  const state: OtpState = { mobile, code: DEMO_OTP, generatedAt: new Date().toISOString(), verified: false };
  if (typeof localStorage !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
  return state;
}

export function getOtpState(): OtpState | null {
  if (typeof localStorage === "undefined") return null;
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "null") as OtpState | null;
  } catch {
    return null;
  }
}

export function verifyOtp(entered: string): boolean {
  const state = getOtpState();
  if (!state) return false;
  const ok = entered.trim() === state.code;
  if (ok && typeof localStorage !== "undefined") {
    localStorage.setItem(KEY, JSON.stringify({ ...state, verified: true }));
  }
  return ok;
}
