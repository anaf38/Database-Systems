export type RiskResult = { score: number; level: "Low" | "Medium" | "High"; factors: string[] };
export function predictRisk(input: { severity: number; humidity?: number; rainfallProbability?: number; history?: boolean }): RiskResult {
  let score = input.severity * 0.7 + (input.humidity ?? 60) * 0.15 + (input.rainfallProbability ?? 20) * 0.1 + (input.history ? 5 : 0);
  score = Math.round(Math.min(100, Math.max(0, score)));
  return { score, level: score >= 70 ? "High" : score >= 40 ? "Medium" : "Low", factors: [input.severity >= 60 ? "High current severity" : "Current severity", (input.humidity ?? 60) >= 75 ? "High humidity" : "Moderate humidity", (input.rainfallProbability ?? 20) >= 50 ? "Rain may favor spread" : "Lower rain probability"] };
}
