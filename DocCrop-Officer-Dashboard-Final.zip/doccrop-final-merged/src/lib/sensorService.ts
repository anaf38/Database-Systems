export type SensorSnapshot = { moisture: number; soilTemperature: number; wind: number; updatedAt: string; source: string };
export async function getSensorSnapshot(): Promise<SensorSnapshot> { return { moisture: 18, soilTemperature: 26, wind: 7, updatedAt: new Date().toISOString(), source: "Demo sensor adapter" }; }
