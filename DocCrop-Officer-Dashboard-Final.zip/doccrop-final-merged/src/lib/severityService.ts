import type { FollowUpStatus } from "./cropTypes";

/** Compares two severity readings (0-100) and classifies progress for a follow-up. */
export function compareSeverity(previous: number, current: number): FollowUpStatus {
  const delta = current - previous;
  if (delta <= -5) return "Better";
  if (delta >= 5) return "Worse";
  return "No Change";
}
