// Weather layer for the Farmer home screen.
// Uses Open-Meteo (no API key required) for a real live forecast once we have
// coordinates. Before the farmer shares their precise location we still show
// a "default" approximate snapshot (based on their saved session.location
// text) so the screen is never empty — then swap in the precise reading the
// moment GPS/location is accepted.
// Prototype-only: no server-side caching, just an in-memory + localStorage cache.

export type WeatherSnapshot = {
  temperature: number;
  condition: string;
  humidity: number;
  rainProbability: number;
  wind: number;
  source: "Approximate (before location)" | "Live (OpenWeather-style feed)";
  forecastDate: string;
  precise: boolean;
};

const CACHE_KEY = "doccrop.weatherCache";
const WEATHER_CODE: Record<number, string> = {
  0: "Clear sky",
  1: "Mostly clear",
  2: "Partly cloudy",
  3: "Overcast",
  45: "Fog",
  48: "Fog",
  51: "Light drizzle",
  53: "Drizzle",
  55: "Heavy drizzle",
  61: "Light rain",
  63: "Rain",
  65: "Heavy rain",
  71: "Light snow",
  80: "Rain showers",
  81: "Rain showers",
  82: "Violent showers",
  95: "Thunderstorm",
};

function readCache(): WeatherSnapshot | null {
  if (typeof localStorage === "undefined") return null;
  try {
    return JSON.parse(localStorage.getItem(CACHE_KEY) ?? "null") as WeatherSnapshot | null;
  } catch {
    return null;
  }
}

function writeCache(snapshot: WeatherSnapshot) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(CACHE_KEY, JSON.stringify(snapshot));
}

/** A believable "before you've shared location" placeholder — deterministic, not random, so it doesn't flicker. */
export function approximateWeather(locationLabel?: string | null): WeatherSnapshot {
  const seed = (locationLabel ?? "India").length;
  return {
    temperature: 27 + (seed % 5),
    condition: "Partly cloudy",
    humidity: 60 + (seed % 15),
    rainProbability: 20 + (seed % 20),
    wind: 8 + (seed % 6),
    source: "Approximate (before location)",
    forecastDate: new Date().toISOString(),
    precise: false,
  };
}

/** Live lookup once we have coordinates. Falls back to the cached/approximate snapshot if offline. */
export async function fetchWeather(latitude: number, longitude: number): Promise<WeatherSnapshot> {
  try {
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&hourly=precipitation_probability&timezone=auto`,
    );
    if (!res.ok) throw new Error("weather fetch failed");
    const data = (await res.json()) as {
      current: { temperature_2m: number; relative_humidity_2m: number; wind_speed_10m: number; weather_code: number; time: string };
      hourly?: { precipitation_probability?: number[]; time?: string[] };
    };
    const nowIdx = data.hourly?.time?.findIndex((t) => t === data.current.time) ?? -1;
    const rainProbability = nowIdx >= 0 ? data.hourly?.precipitation_probability?.[nowIdx] ?? 20 : 20;
    const snapshot: WeatherSnapshot = {
      temperature: Math.round(data.current.temperature_2m),
      condition: WEATHER_CODE[data.current.weather_code] ?? "Mixed conditions",
      humidity: Math.round(data.current.relative_humidity_2m),
      rainProbability: Math.round(rainProbability),
      wind: Math.round(data.current.wind_speed_10m),
      source: "Live (OpenWeather-style feed)",
      forecastDate: new Date().toISOString(),
      precise: true,
    };
    writeCache(snapshot);
    return snapshot;
  } catch {
    return readCache() ?? approximateWeather();
  }
}
