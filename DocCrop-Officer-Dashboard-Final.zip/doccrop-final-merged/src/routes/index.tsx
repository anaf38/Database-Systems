import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Sprout } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Splash,
});

function Splash() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = window.setTimeout(() => {
      navigate({ to: "/officer" });
    }, 700);
    return () => window.clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="grid min-h-screen place-items-center field-gradient">
      <div className="flex flex-col items-center gap-3 text-primary-foreground">
        <span className="grid size-20 place-items-center rounded-3xl bg-primary-foreground/15">
          <Sprout className="size-10 animate-pulse" />
        </span>
        <h1 className="text-2xl font-bold">DocCrop</h1>
        <p className="text-sm opacity-90">Smart Care. Healthy Crop. Better Tomorrow.</p>
      </div>
    </div>
  );
}
