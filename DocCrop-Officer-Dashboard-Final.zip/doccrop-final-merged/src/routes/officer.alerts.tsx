import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Radar, Bell, ShieldAlert, ArrowRight, Droplets } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getNotifications, getHotspots, getCases } from "@/lib/officerService";

export const Route = createFileRoute("/officer/alerts")({
  component: OfficerAlertsScreen,
});

function OfficerAlertsScreen() {
  const notifications = getNotifications();
  const hotspots = getHotspots();
  const cases = getCases();

  const urgentAlerts = notifications.filter((n) => n.priority === "Critical" || n.category === "Urgent");

  return (
    <OfficerMobileShell title="Disease Alerts" subtitle="Priority Village Triggers">
      <div className="space-y-4 px-4 pt-4">
        {/* Critical Banner */}
        <div className="rounded-2xl border-2 border-destructive/50 bg-destructive/10 p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="size-5 text-destructive" />
            <h3 className="font-bold text-sm text-destructive">Active Epidemiological Alerts</h3>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            3 High-risk disease clusters require field officer supervision in Madurai Division.
          </p>
        </div>

        {/* Hotspots Section */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1 mb-2">
            Top Hotspots Triggered
          </h3>
          <div className="space-y-2.5">
            {hotspots.slice(0, 3).map((h) => (
              <Link
                key={h.id}
                to="/officer/hotspot/$hotspotId"
                params={{ hotspotId: h.id }}
                className="tap block rounded-2xl border border-border bg-card p-3.5 hover:border-primary shadow-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-destructive uppercase tracking-wider">{h.id}</span>
                    <h4 className="text-sm font-bold">{h.disease}</h4>
                    <p className="text-xs text-muted-foreground">{h.location} · {h.affectedFarmers} Farmers Affected</p>
                  </div>
                  <span className="rounded-md bg-destructive px-2 py-0.5 text-xs font-bold text-destructive-foreground">
                    Score {h.riskScore}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Moisture Risk Trigger Card */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-center gap-2 text-blue-600 mb-1">
            <Droplets className="size-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Moisture Stress Indicator</h4>
          </div>
          <p className="text-xs font-bold">Western Taluks (Melur & Vadipatti)</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Humidity above 85% paired with 32mm rainfall increases blast spore dispersal probability.
          </p>
          <p className="mt-2 text-[10px] text-muted-foreground italic">
            * Prototype evaluation only. Field inspection necessary.
          </p>
        </div>

        {/* Urgent Notification Stream */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1 mb-2">
            Urgent Incident Stream
          </h3>
          <div className="space-y-2">
            {urgentAlerts.map((n) => (
              <div key={n.id} className="rounded-xl border border-border bg-card p-3 text-xs">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-destructive">{n.title}</span>
                  <span className="text-muted-foreground">{n.timestamp}</span>
                </div>
                <p className="mt-1 text-muted-foreground text-[11px]">{n.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
