import { createFileRoute, useParams, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowLeft,
  CalendarCheck2,
  CheckCircle2,
  Clock,
  MapPin,
  MessageSquare,
  Send,
  ShieldAlert,
  User,
  Sprout,
  Activity,
} from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import {
  getCaseById,
  updateCaseStatus,
  addCaseRemark,
  type CaseStatus,
} from "@/lib/officerService";

export const Route = createFileRoute("/officer/case/$caseId")({
  component: OfficerCaseDetail,
});

const ALL_STATUSES: CaseStatus[] = [
  "New",
  "Under Review",
  "Field Visit Scheduled",
  "Under Investigation",
  "Confirmed",
  "Monitoring",
  "Resolved",
];

function OfficerCaseDetail() {
  const { caseId } = useParams({ from: "/officer/case/$caseId" });
  const navigate = useNavigate();
  const [remarkInput, setRemarkInput] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  const c = getCaseById(caseId);

  if (!c) {
    return (
      <OfficerMobileShell title="Case Dossier" showBack backTo="/officer/cases">
        <div className="p-6 text-center text-sm text-muted-foreground">
          Case {caseId} not found.
        </div>
      </OfficerMobileShell>
    );
  }

  const handleStatusChange = (newStatus: CaseStatus) => {
    updateCaseStatus(c.id, newStatus, `Officer moved status to ${newStatus}`);
    setRefreshKey((k) => k + 1);
  };

  const handleAddRemark = (e: React.FormEvent) => {
    e.preventDefault();
    if (!remarkInput.trim()) return;
    addCaseRemark(c.id, remarkInput.trim());
    setRemarkInput("");
    setRefreshKey((k) => k + 1);
  };

  return (
    <OfficerMobileShell
      title={`Case ${c.id}`}
      subtitle={`${c.crop} · ${c.location}`}
      showBack
      backTo="/officer/cases"
    >
      <div className="space-y-4 px-4 pt-4">
        {/* Header Summary */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-primary">{c.id}</span>
              <h2 className="text-lg font-bold">{c.disease}</h2>
              <p className="text-xs text-muted-foreground">{c.crop} · {c.affectedArea}</p>
            </div>
            <div className="text-right">
              <span className="rounded-md bg-destructive px-2 py-0.5 text-xs font-bold text-destructive-foreground">
                Score {c.riskScore}/100
              </span>
              <p className="mt-1 text-[10px] font-semibold text-destructive">{c.riskLevel.toUpperCase()} RISK</p>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-border/60 pt-3 text-xs">
            <div>
              <span className="text-muted-foreground block text-[10px]">Farmer</span>
              <span className="font-bold">{c.farmerName}</span>
              <p className="text-[11px] text-muted-foreground">{c.farmerPhone}</p>
            </div>
            <div>
              <span className="text-muted-foreground block text-[10px]">Location</span>
              <span className="font-bold flex items-center gap-1">
                <MapPin className="size-3 text-primary" />
                {c.location}
              </span>
              <p className="text-[11px] text-muted-foreground">Reported: {c.reportDate}</p>
            </div>
          </div>
        </div>

        {/* Symptoms Observed */}
        {c.symptoms && c.symptoms.length > 0 && (
          <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
              Reported Symptoms
            </h3>
            <ul className="space-y-1.5 text-xs">
              {c.symptoms.map((s, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Status Transition Controls */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
            Update Case Status
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {ALL_STATUSES.map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => handleStatusChange(st)}
                className={`tap rounded-xl px-2.5 py-1.5 text-xs font-bold transition ${
                  c.status === st
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <Link
            to="/officer/visits/schedule"
            className="tap mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-xs font-bold text-primary-foreground shadow-xs"
          >
            <CalendarCheck2 className="size-4" />
            Schedule Field Visit for this Case
          </Link>
        </div>

        {/* Timeline */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
            Case Timeline
          </h3>
          <div className="space-y-3">
            {c.timeline.map((item) => (
              <div key={item.id} className="relative pl-5 border-l-2 border-primary/40 text-xs">
                <span className="absolute -left-[5px] top-0 size-2 rounded-full bg-primary" />
                <p className="font-bold text-foreground">{item.title}</p>
                <p className="text-muted-foreground text-[11px]">{item.description}</p>
                <span className="text-[10px] text-muted-foreground/70">{item.timestamp}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Officer Remarks */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
            <MessageSquare className="size-3.5 text-primary" />
            <span>Official Officer Remarks</span>
          </h3>

          <form onSubmit={handleAddRemark} className="flex gap-2 mb-3">
            <input
              type="text"
              value={remarkInput}
              onChange={(e) => setRemarkInput(e.target.value)}
              placeholder="Add field note / recommendation..."
              className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-xs focus:border-primary focus:outline-none"
            />
            <button
              type="submit"
              className="tap grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground"
            >
              <Send className="size-4" />
            </button>
          </form>

          <div className="space-y-2">
            {c.remarks.length === 0 ? (
              <p className="text-[11px] text-muted-foreground">No officer remarks recorded yet.</p>
            ) : (
              c.remarks.map((r) => (
                <div key={r.id} className="rounded-xl bg-secondary/50 p-2.5 text-xs">
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span className="font-bold text-primary">{r.officerName}</span>
                    <span>{r.timestamp}</span>
                  </div>
                  <p className="mt-1 text-foreground">{r.text}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
