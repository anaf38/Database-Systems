import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { Search, Filter, ArrowRight, AlertCircle, ShieldAlert, ChevronRight } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getCases, type OfficerCase, type RiskLevel, type CaseStatus } from "@/lib/officerService";

export const Route = createFileRoute("/officer/cases")({
  component: OfficerCasesScreen,
});

function OfficerCasesScreen() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [riskFilter, setRiskFilter] = useState<string>("All");
  const cases = getCases();

  const filteredCases = useMemo(() => {
    return cases.filter((c) => {
      const matchSearch =
        c.farmerName.toLowerCase().includes(search.toLowerCase()) ||
        c.crop.toLowerCase().includes(search.toLowerCase()) ||
        c.disease.toLowerCase().includes(search.toLowerCase()) ||
        c.location.toLowerCase().includes(search.toLowerCase()) ||
        c.id.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === "All" || c.status === statusFilter;
      const matchRisk = riskFilter === "All" || c.riskLevel === riskFilter;

      return matchSearch && matchStatus && matchRisk;
    });
  }, [cases, search, statusFilter, riskFilter]);

  const riskBadge = (level: RiskLevel, score: number) => {
    const colors: Record<RiskLevel, string> = {
      Critical: "bg-red-500 text-white",
      High: "bg-orange-500 text-white",
      Medium: "bg-amber-500 text-white",
      Low: "bg-emerald-600 text-white",
    };
    return (
      <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${colors[level] || "bg-secondary"}`}>
        {level.toUpperCase()} {score}/100
      </span>
    );
  };

  return (
    <OfficerMobileShell title="Case Management" subtitle={`${cases.length} Total Field Cases`}>
      <div className="space-y-3 px-4 pt-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search farmer, disease, crop or ID..."
            className="w-full rounded-2xl border border-border bg-card py-2.5 pl-10 pr-4 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {["All", "Under Investigation", "Field Visit Scheduled", "Confirmed", "New", "Monitoring", "Resolved"].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`tap shrink-0 rounded-full px-3 py-1 font-semibold transition ${
                statusFilter === st
                  ? "bg-primary text-primary-foreground"
                  : "border border-border bg-card text-muted-foreground"
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Risk Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {["All", "Critical", "High", "Medium", "Low"].map((rk) => (
            <button
              key={rk}
              onClick={() => setRiskFilter(rk)}
              className={`tap shrink-0 rounded-full px-3 py-0.5 font-medium transition ${
                riskFilter === rk
                  ? "bg-foreground text-background font-bold"
                  : "border border-border bg-card text-muted-foreground"
              }`}
            >
              Risk: {rk}
            </button>
          ))}
        </div>

        {/* List of Mobile Cards */}
        <div className="space-y-2.5 pt-1">
          {filteredCases.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card p-6 text-center text-xs text-muted-foreground">
              No disease cases found matching your filters.
            </div>
          ) : (
            filteredCases.map((item) => (
              <Link
                key={item.id}
                to="/officer/case/$caseId"
                params={{ caseId: item.id }}
                className="tap block rounded-2xl border border-border bg-card p-3.5 shadow-xs transition hover:border-primary"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-primary tracking-wide uppercase">{item.id}</span>
                    <h4 className="text-sm font-bold text-foreground">{item.disease}</h4>
                    <p className="text-xs text-muted-foreground">{item.farmerName} · {item.crop}</p>
                  </div>
                  {riskBadge(item.riskLevel, item.riskScore)}
                </div>

                <div className="mt-2.5 flex items-center justify-between border-t border-border/60 pt-2 text-[11px]">
                  <span className="text-muted-foreground">{item.location} · {item.reportDate}</span>
                  <span className="rounded-full bg-secondary px-2 py-0.5 font-bold text-secondary-foreground text-[10px]">
                    {item.status}
                  </span>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </OfficerMobileShell>
  );
}
