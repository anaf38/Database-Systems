import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ClipboardList,
  AlertTriangle,
  CalendarCheck2,
  Radar,
  Users,
  FileBarChart2,
  Bell,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  TrendingUp,
  MapPin,
} from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import {
  getCases,
  getHotspots,
  getFieldVisits,
  getFarmers,
  getOfficerProfile,
  getNotifications,
} from "@/lib/officerService";

export const Route = createFileRoute("/officer/dashboard")({
  component: OfficerDashboard,
});

function OfficerDashboard() {
  const navigate = useNavigate();
  const profile = getOfficerProfile();
  const cases = getCases();
  const hotspots = getHotspots();
  const visits = getFieldVisits();
  const farmers = getFarmers();
  const notifications = getNotifications();

  // Summary counts as per Master Prompt:
  // Total Farmers: 1,248 (demo figure + active records), Active Cases: 86, High Risk: 18, Field Visits: 12, Potential Hotspots: 3
  const activeCasesCount = cases.filter((c) => c.status !== "Resolved").length;
  const highRiskCount = cases.filter((c) => c.riskLevel === "High" || c.riskLevel === "Critical").length;
  const pendingVisitsCount = visits.filter((v) => v.status === "Scheduled" || v.status === "In Progress").length;
  const activeHotspotsCount = hotspots.filter((h) => h.status !== "Resolved").length;

  const urgentHotspot = hotspots.find((h) => h.id === "HOTSPOT-001") || hotspots[0];

  const quickActions = [
    { label: "Cases", path: "/officer/cases", count: activeCasesCount, icon: ClipboardList, color: "text-blue-500 bg-blue-500/10" },
    { label: "Hotspots", path: "/officer/hotspots", count: activeHotspotsCount, icon: Radar, color: "text-rose-500 bg-rose-500/10" },
    { label: "Farmers", path: "/officer/farmers", count: farmers.length, icon: Users, color: "text-emerald-500 bg-emerald-500/10" },
    { label: "Field Visits", path: "/officer/visits", count: pendingVisitsCount, icon: CalendarCheck2, color: "text-amber-500 bg-amber-500/10" },
    { label: "Reports", path: "/officer/reports", count: "PDF", icon: FileBarChart2, color: "text-purple-500 bg-purple-500/10" },
    { label: "Alerts", path: "/officer/alerts", count: highRiskCount, icon: Bell, color: "text-indigo-500 bg-indigo-500/10" },
  ];

  return (
    <OfficerMobileShell
      title="Agriculture Officer"
      subtitle="Madurai Agricultural Division"
    >
      <div className="space-y-4 px-4 pt-4">
        {/* Officer Welcome Header */}
        <div className="rounded-2xl border border-border/80 bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-primary">Good morning, Officer 👋</p>
              <h2 className="text-lg font-bold leading-snug">{profile.division}</h2>
              <p className="text-xs text-muted-foreground">{profile.location} District · Field Operations</p>
            </div>
            <div className="grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary font-bold text-sm">
              AO
            </div>
          </div>
        </div>

        {/* Master Prompt Section 9: Summary Cards (Horizontally Scrollable) */}
        <div>
          <div className="flex items-center justify-between px-1 mb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Division Overview</h3>
            <span className="text-[11px] font-semibold text-primary">Live Sync</span>
          </div>
          <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-none">
            <div className="flex min-w-[120px] flex-col rounded-2xl border border-border bg-card p-3 shadow-xs">
              <span className="text-[11px] font-medium text-muted-foreground">Total Farmers</span>
              <span className="text-xl font-extrabold text-foreground mt-0.5">1,248</span>
              <span className="text-[10px] text-emerald-600 font-semibold mt-1">20 surveyed</span>
            </div>

            <div className="flex min-w-[120px] flex-col rounded-2xl border border-border bg-card p-3 shadow-xs">
              <span className="text-[11px] font-medium text-muted-foreground">Active Cases</span>
              <span className="text-xl font-extrabold text-foreground mt-0.5">86</span>
              <span className="text-[10px] text-blue-600 font-semibold mt-1">30 detailed</span>
            </div>

            <div className="flex min-w-[120px] flex-col rounded-2xl border border-rose-500/30 bg-rose-500/5 p-3 shadow-xs">
              <span className="text-[11px] font-medium text-rose-700">High Risk</span>
              <span className="text-xl font-extrabold text-rose-700 mt-0.5">18</span>
              <span className="text-[10px] text-rose-600 font-semibold mt-1">Priority review</span>
            </div>

            <div className="flex min-w-[120px] flex-col rounded-2xl border border-border bg-card p-3 shadow-xs">
              <span className="text-[11px] font-medium text-muted-foreground">Field Visits</span>
              <span className="text-xl font-extrabold text-foreground mt-0.5">12</span>
              <span className="text-[10px] text-amber-600 font-semibold mt-1">3 today</span>
            </div>

            <div className="flex min-w-[120px] flex-col rounded-2xl border border-border bg-card p-3 shadow-xs">
              <span className="text-[11px] font-medium text-muted-foreground">Hotspots</span>
              <span className="text-xl font-extrabold text-foreground mt-0.5">3</span>
              <span className="text-[10px] text-primary font-semibold mt-1">5 detected</span>
            </div>
          </div>
        </div>

        {/* Master Prompt Section 10: Prominent Urgent Alert */}
        {urgentHotspot && (
          <div className="relative overflow-hidden rounded-2xl border-2 border-destructive/40 bg-destructive/10 p-4 shadow-sm">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="flex size-2 rounded-full bg-destructive animate-ping" />
                <span className="rounded-full bg-destructive px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-destructive-foreground">
                  🚨 HIGH RISK HOTSPOT
                </span>
              </div>
              <span className="rounded-lg bg-card px-2 py-0.5 text-[11px] font-bold text-destructive">
                Score {urgentHotspot.riskScore}/100
              </span>
            </div>

            <div className="mt-2.5">
              <h4 className="text-base font-bold text-foreground">
                {urgentHotspot.disease} ({urgentHotspot.crop})
              </h4>
              <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="size-3.5 text-destructive" />
                <span>{urgentHotspot.location} · {urgentHotspot.affectedFarmers} Affected Farmers · {urgentHotspot.radiusKm} km radius</span>
              </p>
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-destructive/20 pt-2.5 text-[11px] text-muted-foreground">
              <span>First: {urgentHotspot.firstReport}</span>
              <span>Latest: {urgentHotspot.latestReport}</span>
            </div>

            <Link
              to="/officer/hotspot/$hotspotId"
              params={{ hotspotId: urgentHotspot.id }}
              className="tap mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl bg-destructive py-2.5 text-xs font-bold text-destructive-foreground shadow-sm transition hover:bg-destructive/90"
            >
              <span>View Hotspot Details</span>
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
        )}

        {/* Quick Actions (Master Prompt Section 11) */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1 mb-2">
            Field Officer Operations
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {quickActions.map(({ label, path, count, icon: Icon, color }) => (
              <Link
                key={label}
                to={path as any}
                className="tap flex flex-col items-center justify-center rounded-2xl border border-border bg-card p-3 text-center transition hover:border-primary shadow-xs"
              >
                <div className={`grid size-10 place-items-center rounded-xl ${color}`}>
                  <Icon className="size-5" />
                </div>
                <span className="mt-2 text-xs font-bold leading-tight">{label}</span>
                <span className="text-[10px] text-muted-foreground font-medium">{count}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Priority Action: Today Field Visits */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <CalendarCheck2 className="size-4 text-primary" />
              <span>Today Field Visits</span>
            </h3>
            <Link to="/officer/visits" className="text-xs font-bold text-primary hover:underline">
              View All →
            </Link>
          </div>

          <div className="mt-3 space-y-2">
            {visits.slice(0, 2).map((visit) => (
              <Link
                key={visit.id}
                to="/officer/visit/$visitId"
                params={{ visitId: visit.id }}
                className="tap flex items-center justify-between rounded-xl bg-secondary/50 p-3 hover:bg-secondary"
              >
                <div>
                  <p className="text-xs font-bold text-foreground">{visit.farmerName} · {visit.crop}</p>
                  <p className="text-[11px] text-muted-foreground">{visit.dateTime} · {visit.location}</p>
                </div>
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                  visit.status === "In Progress"
                    ? "bg-amber-500/20 text-amber-700"
                    : "bg-blue-500/20 text-blue-700"
                }`}>
                  {visit.status}
                </span>
              </Link>
            ))}
          </div>

          <button
            type="button"
            onClick={() => navigate({ to: "/officer/visits/schedule" })}
            className="tap mt-3 flex w-full items-center justify-center rounded-xl border border-primary/30 bg-primary/5 py-2 text-xs font-bold text-primary hover:bg-primary/10"
          >
            + Schedule New Field Visit
          </button>
        </div>

        {/* Prototype Safety Notice */}
        <div className="rounded-2xl border border-border bg-secondary/30 p-3 text-center">
          <p className="text-[11px] text-muted-foreground">
            ⚠️ <strong>AI-Assisted Field Tool:</strong> Prototype Risk Scores & Hotspots require on-field diagnostic verification by the authorized Agriculture Officer.
          </p>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
