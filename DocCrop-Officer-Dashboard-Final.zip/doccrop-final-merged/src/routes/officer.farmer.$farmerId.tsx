import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Phone, MapPin, CalendarCheck2, MessageSquare, Send, ArrowLeft, Sprout, ShieldAlert } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getFarmerById, getCases, getFieldVisits, addFarmerRemark } from "@/lib/officerService";

export const Route = createFileRoute("/officer/farmer/$farmerId")({
  component: OfficerFarmerProfile,
});

function OfficerFarmerProfile() {
  const { farmerId } = useParams({ from: "/officer/farmer/$farmerId" });
  const [remarkInput, setRemarkInput] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  const farmer = getFarmerById(farmerId);
  const allCases = getCases().filter((c) => c.farmerId === farmerId);
  const allVisits = getFieldVisits().filter((v) => v.farmerId === farmerId);

  if (!farmer) {
    return (
      <OfficerMobileShell title="Farmer Profile" showBack backTo="/officer/farmers">
        <div className="p-6 text-center text-sm text-muted-foreground">Farmer {farmerId} not found.</div>
      </OfficerMobileShell>
    );
  }

  const handleAddRemark = (e: React.FormEvent) => {
    e.preventDefault();
    if (!remarkInput.trim()) return;
    addFarmerRemark(farmer.id, remarkInput.trim());
    setRemarkInput("");
    setRefreshKey((k) => k + 1);
  };

  return (
    <OfficerMobileShell title={farmer.name} subtitle="Farmer Profile & Holdings" showBack backTo="/officer/farmers">
      <div className="space-y-4 px-4 pt-4">
        {/* Info Card */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold text-primary uppercase tracking-wider">{farmer.id}</span>
              <h2 className="text-lg font-bold">{farmer.name}</h2>
              <p className="text-xs text-muted-foreground">{farmer.village}, {farmer.taluk} Taluk</p>
            </div>
            <a
              href={`tel:${farmer.phone}`}
              className="tap flex items-center gap-1 rounded-xl bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground shadow-xs"
            >
              <Phone className="size-3.5" />
              <span>Call</span>
            </a>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-border/60 pt-3 text-xs">
            <div>
              <span className="text-muted-foreground text-[10px] block">Primary Crop</span>
              <span className="font-bold">{farmer.primaryCrop}</span>
            </div>
            <div>
              <span className="text-muted-foreground text-[10px] block">Land Size</span>
              <span className="font-bold">{farmer.landSizeAcres} Acres</span>
            </div>
            <div>
              <span className="text-muted-foreground text-[10px] block">Soil Type</span>
              <span className="font-bold">{farmer.soilType}</span>
            </div>
            <div>
              <span className="text-muted-foreground text-[10px] block">Irrigation</span>
              <span className="font-bold">{farmer.irrigationSource}</span>
            </div>
          </div>
        </div>

        {/* Farmer Disease Cases */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
            Disease Cases ({allCases.length})
          </h3>
          <div className="space-y-2">
            {allCases.length === 0 ? (
              <p className="text-xs text-muted-foreground">No disease cases filed yet.</p>
            ) : (
              allCases.map((c) => (
                <Link
                  key={c.id}
                  to="/officer/case/$caseId"
                  params={{ caseId: c.id }}
                  className="tap flex items-center justify-between rounded-xl bg-secondary/50 p-2.5 text-xs hover:bg-secondary"
                >
                  <div>
                    <span className="font-bold text-primary">{c.id}</span> · {c.disease}
                    <p className="text-[10px] text-muted-foreground">{c.status} · {c.reportDate}</p>
                  </div>
                  <span className="rounded bg-destructive/10 px-1.5 py-0.5 text-[10px] font-bold text-destructive">
                    {c.riskScore}
                  </span>
                </Link>
              ))
            )}
          </div>
        </div>

        {/* Farmer Remarks */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
            <MessageSquare className="size-3.5 text-primary" />
            <span>Officer Advisory & Remarks</span>
          </h3>

          <form onSubmit={handleAddRemark} className="flex gap-2 mb-3">
            <input
              type="text"
              value={remarkInput}
              onChange={(e) => setRemarkInput(e.target.value)}
              placeholder="Add observation or recommendation..."
              className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-xs focus:border-primary focus:outline-none"
            />
            <button type="submit" className="tap grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
              <Send className="size-4" />
            </button>
          </form>

          <div className="space-y-2">
            {farmer.remarks.map((r, i) => (
              <div key={i} className="rounded-xl bg-secondary/40 p-2.5 text-xs text-foreground">
                {r}
              </div>
            ))}
          </div>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
