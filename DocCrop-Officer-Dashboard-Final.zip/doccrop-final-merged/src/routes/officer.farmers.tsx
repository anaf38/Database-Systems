import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { Search, Users, Phone, MapPin, ArrowRight } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getFarmers, type Farmer } from "@/lib/officerService";

export const Route = createFileRoute("/officer/farmers")({
  component: OfficerFarmersList,
});

function OfficerFarmersList() {
  const [search, setSearch] = useState("");
  const [cropFilter, setCropFilter] = useState("All");
  const farmers = getFarmers();

  const filtered = useMemo(() => {
    return farmers.filter((f) => {
      const matchSearch =
        f.name.toLowerCase().includes(search.toLowerCase()) ||
        f.village.toLowerCase().includes(search.toLowerCase()) ||
        f.phone.includes(search) ||
        f.primaryCrop.toLowerCase().includes(search.toLowerCase());
      const matchCrop = cropFilter === "All" || f.primaryCrop.toLowerCase().includes(cropFilter.toLowerCase());
      return matchSearch && matchCrop;
    });
  }, [farmers, search, cropFilter]);

  return (
    <OfficerMobileShell title="Farmer Directory" subtitle={`${farmers.length} Registered Farmers`}>
      <div className="space-y-3 px-4 pt-4">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search farmer name, village, or phone..."
            className="w-full rounded-2xl border border-border bg-card py-2.5 pl-10 pr-4 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {["All", "Paddy", "Tomato", "Cotton", "Banana", "Sugarcane", "Groundnut"].map((cr) => (
            <button
              key={cr}
              onClick={() => setCropFilter(cr)}
              className={`tap shrink-0 rounded-full px-3 py-1 font-semibold transition ${
                cropFilter === cr
                  ? "bg-primary text-primary-foreground"
                  : "border border-border bg-card text-muted-foreground"
              }`}
            >
              {cr}
            </button>
          ))}
        </div>

        <div className="space-y-2.5">
          {filtered.map((farmer) => (
            <Link
              key={farmer.id}
              to="/officer/farmer/$farmerId"
              params={{ farmerId: farmer.id }}
              className="tap block rounded-2xl border border-border bg-card p-3.5 shadow-xs hover:border-primary"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold text-foreground">{farmer.name}</h4>
                  <p className="text-xs text-muted-foreground">{farmer.primaryCrop} · {farmer.landSizeAcres} Acres</p>
                  <p className="mt-1 flex items-center gap-1 text-[11px] text-muted-foreground">
                    <MapPin className="size-3 text-primary" />
                    <span>{farmer.village}, {farmer.taluk}</span>
                  </p>
                </div>
                <div className="text-right">
                  <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                    farmer.overallRisk === "Critical" || farmer.overallRisk === "High"
                      ? "bg-destructive text-destructive-foreground"
                      : "bg-secondary text-secondary-foreground"
                  }`}>
                    Risk: {farmer.overallRisk}
                  </span>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    Active Cases: <strong>{farmer.activeCasesCount}</strong>
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </OfficerMobileShell>
  );
}
