import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import {
  ArrowLeft,
  CalendarCheck2,
  Droplets,
  MapPin,
  Radar,
  ShieldAlert,
  Thermometer,
  Wind,
  TrendingUp,
  Users,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getHotspotById, getCases } from "@/lib/officerService";
import { createGeoFenceForHotspot, getGeoFenceForHotspot, reviewGeoFence, getFarmersInsideGeoFence, sendGeoFenceAlert } from "@/lib/geofenceService";

export const Route = createFileRoute("/officer/hotspot/$hotspotId")({
  component: OfficerHotspotDetail,
});

function OfficerHotspotDetail() {
  const { hotspotId } = useParams({ from: "/officer/hotspot/$hotspotId" });
  const h = getHotspotById(hotspotId);
  const allCases = getCases();

  if (!h) {
    return (
      <OfficerMobileShell title="Hotspot Details" showBack backTo="/officer/hotspots">
        <div className="p-6 text-center text-sm text-muted-foreground">
          Hotspot {hotspotId} not found.
        </div>
      </OfficerMobileShell>
    );
  }

  const linkedCases = allCases.filter((c) => h.caseIds.includes(c.id));
  const fence = getGeoFenceForHotspot(h.id) || createGeoFenceForHotspot(h);
  const insideCount = getFarmersInsideGeoFence(fence).length;

  return (
    <OfficerMobileShell
      title={h.id}
      subtitle={`${h.disease} (${h.location})`}
      showBack
      backTo="/officer/hotspots"
    >
      <div className="space-y-4 px-4 pt-4">
        {/* Hotspot Header */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold text-destructive uppercase tracking-wider">{h.id}</span>
              <h2 className="text-lg font-bold">{h.disease}</h2>
              <p className="text-xs text-muted-foreground">{h.crop} · {h.location}</p>
            </div>
            <div className="text-right">
              <span className="rounded-md bg-destructive px-2 py-0.5 text-xs font-bold text-destructive-foreground">
                Score {h.riskScore}/100
              </span>
              <p className="mt-1 text-[10px] font-bold text-destructive">{h.severity}</p>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between border-t border-border/60 pt-2.5 text-xs">
            <span>Affected: <strong>{h.affectedFarmers} Farmers</strong></span>
            <span>Radius: <strong>{h.radiusKm} km</strong></span>
            <span>Status: <strong>{h.status}</strong></span>
          </div>
        </div>

        {/* Master Prompt Section 18: Interactive CSS/SVG Map (Runs Offline) */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
              <Radar className="size-3.5 text-primary" />
              <span>Offline Vector Map · Cluster Radius</span>
            </h3>
            <span className="text-[10px] font-bold text-destructive">{h.radiusKm} km Zone</span>
          </div>

          <div className="relative h-56 w-full overflow-hidden rounded-xl bg-slate-950 border border-slate-800">
            {/* SVG Vector Map Rendering */}
            <svg className="size-full" viewBox="0 0 300 220">
              <defs>
                <radialGradient id="hotspotGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
                  <stop offset="70%" stopColor="#ef4444" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0.0" />
                </radialGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="0" y1="55" x2="300" y2="55" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="110" x2="300" y2="110" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="0" y1="165" x2="300" y2="165" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="75" y1="0" x2="75" y2="220" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="150" y1="0" x2="150" y2="220" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="225" y1="0" x2="225" y2="220" stroke="#1e293b" strokeDasharray="3 3" />

              {/* Hotspot Cluster Ring */}
              <circle cx="150" cy="110" r="75" fill="url(#hotspotGrad)" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4 2" />
              <circle cx="150" cy="110" r="45" fill="#ef4444" fillOpacity="0.1" stroke="#f87171" strokeWidth="1" />

              {/* Epicenter Pin */}
              <circle cx="150" cy="110" r="6" fill="#ef4444" stroke="#ffffff" strokeWidth="2" />
              <text x="150" y="132" fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle">
                {h.location} Center
              </text>

              {/* Individual Farms */}
              <circle cx="120" cy="85" r="4" fill="#38bdf8" />
              <text x="120" y="77" fill="#94a3b8" fontSize="8" textAnchor="middle">Farm 1</text>

              <circle cx="175" cy="95" r="4" fill="#38bdf8" />
              <text x="175" y="87" fill="#94a3b8" fontSize="8" textAnchor="middle">Farm 2</text>

              <circle cx="135" cy="145" r="4" fill="#38bdf8" />
              <text x="135" y="157" fill="#94a3b8" fontSize="8" textAnchor="middle">Farm 3</text>

              <circle cx="180" cy="135" r="4" fill="#38bdf8" />
              <text x="180" y="147" fill="#94a3b8" fontSize="8" textAnchor="middle">Farm 4</text>

              <circle cx="160" cy="70" r="4" fill="#38bdf8" />
              <text x="160" y="62" fill="#94a3b8" fontSize="8" textAnchor="middle">Farm 5</text>
            </svg>

            <div className="absolute bottom-2 left-2 flex items-center gap-2 rounded bg-black/70 px-2 py-1 text-[10px] text-white">
              <span className="size-2 rounded-full bg-red-500" /> Epicenter
              <span className="size-2 rounded-full bg-sky-400 ml-1" /> Affected Farm
            </div>
          </div>
        </div>

        {/* Master Prompt Section 19: Hotspot Trend Chart */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
              <TrendingUp className="size-3.5 text-primary" />
              <span>Outbreak Trend Progression</span>
            </h3>
            <span className="text-[10px] font-bold text-amber-500">Increasing ⚠️</span>
          </div>

          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={h.trend} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                <Line
                  type="monotone"
                  dataKey="farmers"
                  stroke="#ef4444"
                  strokeWidth={3}
                  dot={{ r: 4, fill: "#ef4444" }}
                  name="Affected Farms"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Master Prompt Section 20: Environmental Data */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
            <Droplets className="size-3.5 text-blue-500" />
            <span>Environmental Micro-Climate Data</span>
          </h3>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-xl bg-secondary/50 p-2.5">
              <span className="text-muted-foreground text-[10px] block">Temperature</span>
              <span className="font-bold text-sm">{h.environmental.temperatureC}°C</span>
            </div>
            <div className="rounded-xl bg-secondary/50 p-2.5">
              <span className="text-muted-foreground text-[10px] block">Air Humidity</span>
              <span className="font-bold text-sm text-blue-600">{h.environmental.humidityPercent}%</span>
            </div>
            <div className="rounded-xl bg-secondary/50 p-2.5">
              <span className="text-muted-foreground text-[10px] block">Soil Moisture</span>
              <span className="font-bold text-sm text-emerald-600">{h.environmental.soilMoisturePercent}%</span>
            </div>
            <div className="rounded-xl bg-secondary/50 p-2.5">
              <span className="text-muted-foreground text-[10px] block">Rainfall</span>
              <span className="font-bold text-sm">{h.environmental.rainfallMm} mm</span>
            </div>
          </div>

          <div className="mt-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-2.5 text-[11px] text-amber-800">
            ⚠️ <strong>Safety Language:</strong> {h.environmental.safetyDisclaimer}
          </div>
        </div>

        {/* Geo-fence review and targeted alert */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Geo-fence Control</h3>
            <span className="rounded-full bg-secondary px-2 py-1 text-[10px] font-bold">{fence.status}</span>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">{fence.radiusKm} km radius · {insideCount} farmer(s) currently inside the boundary.</p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {fence.status === "Pending Review" && <button type="button" onClick={() => { reviewGeoFence(fence.id, "Active"); window.location.reload(); }} className="rounded-xl bg-primary px-3 py-2.5 text-xs font-bold text-primary-foreground">Approve & Activate</button>}
            {fence.status === "Pending Review" && <button type="button" onClick={() => { reviewGeoFence(fence.id, "Rejected"); window.location.reload(); }} className="rounded-xl border border-border px-3 py-2.5 text-xs font-bold">Reject</button>}
            {fence.status === "Active" && <button type="button" onClick={() => { const r=sendGeoFenceAlert(fence.id, `Please inspect crops for ${fence.disease} in the ${fence.location} geo-fenced area.`); alert(`Alert sent to ${r.sent} farmer(s) inside the geo-fence.`); window.location.reload(); }} className="col-span-2 rounded-xl bg-destructive px-3 py-2.5 text-xs font-bold text-destructive-foreground">Send Alert to Farmers Inside Geo-fence</button>}
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground">Alerts are targeted by GPS distance using the Haversine formula; farmers outside the boundary are excluded.</p>
        </div>

        {/* Linked Cases List */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
            Cases Linked to this Hotspot ({linkedCases.length})
          </h3>
          <div className="space-y-2">
            {linkedCases.map((c) => (
              <Link
                key={c.id}
                to="/officer/case/$caseId"
                params={{ caseId: c.id }}
                className="tap flex items-center justify-between rounded-xl bg-secondary/40 p-2.5 hover:bg-secondary text-xs"
              >
                <div>
                  <span className="font-bold text-primary">{c.id}</span> · {c.farmerName}
                  <p className="text-[10px] text-muted-foreground">{c.status} · {c.affectedArea}</p>
                </div>
                <span className="rounded bg-destructive/10 px-1.5 py-0.5 text-[10px] font-bold text-destructive">
                  {c.riskScore}
                </span>
              </Link>
            ))}
          </div>

          <Link
            to="/officer/visits/schedule"
            className="tap mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl bg-primary py-2.5 text-xs font-bold text-primary-foreground shadow-xs"
          >
            <CalendarCheck2 className="size-4" />
            Schedule Cluster Field Investigation
          </Link>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
