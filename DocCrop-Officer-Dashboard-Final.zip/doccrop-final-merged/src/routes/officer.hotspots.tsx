import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Radar, MapPin, Users, ArrowRight, ShieldAlert } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getHotspots, type Hotspot } from "@/lib/officerService";

export const Route = createFileRoute("/officer/hotspots")({
  component: OfficerHotspotsList,
});

function OfficerHotspotsList() {
  const [filter, setFilter] = useState<string>("All");
  const hotspots = getHotspots();

  const filtered = hotspots.filter((h) => {
    if (filter === "Critical") return h.severity === "CRITICAL";
    if (filter === "High") return h.severity === "HIGH";
    if (filter === "Monitoring") return h.severity === "MONITORING" || h.severity === "MEDIUM";
    return true;
  });

  return (
    <OfficerMobileShell title="Disease Hotspots" subtitle="Clustered Outbreak Detection">
      <div className="space-y-3 px-4 pt-4">
        {/* Filter Tabs */}
        <div className="flex gap-2 border-b border-border/60 pb-2 text-xs">
          {["All", "High", "Monitoring"].map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`tap rounded-full px-3 py-1 font-semibold transition ${
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground"
              }`}
            >
              {f === "High" ? "High Priority" : f}
            </button>
          ))}
        </div>

        {/* Hotspot Cards */}
        <div className="space-y-3">
          {filtered.map((h) => (
            <div
              key={h.id}
              className="rounded-2xl border border-border bg-card p-4 shadow-xs transition hover:border-primary"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold text-destructive uppercase tracking-wider">{h.id}</span>
                  <h3 className="text-base font-bold text-foreground">{h.disease}</h3>
                  <p className="text-xs text-muted-foreground">{h.crop} · {h.location}</p>
                </div>
                <div className="text-right">
                  <span className="rounded-md bg-destructive px-2 py-0.5 text-xs font-bold text-destructive-foreground">
                    Score {h.riskScore}/100
                  </span>
                  <p className="mt-1 text-[10px] font-bold text-destructive">{h.severity}</p>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 border-t border-border/60 pt-2.5 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Users className="size-3.5 text-primary" />
                  <span>{h.affectedFarmers} Affected Farmers</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="size-3.5 text-primary" />
                  <span>{h.radiusKm} km Cluster Radius</span>
                </div>
              </div>

              <div className="mt-2 text-[11px] text-muted-foreground">
                Status: <strong className="text-foreground">{h.status}</strong> · Updated: {h.latestReport}
              </div>

              <Link
                to="/officer/hotspot/$hotspotId"
                params={{ hotspotId: h.id }}
                className="tap mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl bg-primary py-2.5 text-xs font-bold text-primary-foreground shadow-xs"
              >
                <span>View Hotspot Details & Map</span>
                <ArrowRight className="size-3.5" />
              </Link>
            </div>
          ))}
        </div>
      </div>
    </OfficerMobileShell>
  );
}
