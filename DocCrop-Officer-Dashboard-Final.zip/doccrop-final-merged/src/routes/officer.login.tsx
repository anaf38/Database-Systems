import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Eye, EyeOff, Lock, User, AlertCircle, Globe, Check } from "lucide-react";
import { loginOfficer, getSelectedLanguage, setSelectedLanguage } from "@/lib/officerService";

export const Route = createFileRoute("/officer/login")({
  component: OfficerLogin,
});

// Language selector shown on the login screen. "native" is shown on the
// chip so an officer can find their language even before the UI itself is
// translated. Add more entries here to support additional languages.
const LOGIN_LANGUAGES: { code: string; label: string; native: string }[] = [
  { code: "English", label: "English", native: "English" },
  { code: "Hindi", label: "Hindi", native: "हिन्दी" },
  { code: "Tamil", label: "Tamil", native: "தமிழ்" },
  { code: "Telugu", label: "Telugu", native: "తెలుగు" },
  { code: "Kannada", label: "Kannada", native: "ಕನ್ನಡ" },
  { code: "Malayalam", label: "Malayalam", native: "മലയാളം" },
  { code: "Marathi", label: "Marathi", native: "मराठी" },
  { code: "Gujarati", label: "Gujarati", native: "ગુજરાતી" },
  { code: "Bengali", label: "Bengali", native: "বাংলা" },
  { code: "Punjabi", label: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "Odia", label: "Odia", native: "ଓଡ଼ିଆ" },
  { code: "Urdu", label: "Urdu", native: "اردو" },
  { code: "Assamese", label: "Assamese", native: "অসমীয়া" },
];

function OfficerLogin() {
  const navigate = useNavigate();
  const [officerId, setOfficerId] = useState("AO-MDU-1042");
  const [password, setPassword] = useState("demo123");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState<string>(() => getSelectedLanguage());

  const handleSelectLanguage = (code: string) => {
    setLanguage(code);
    setSelectedLanguage(code);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    setTimeout(() => {
      const res = loginOfficer(officerId, password);
      setLoading(false);
      if (res.success) {
        navigate({ to: "/officer/dashboard" });
      } else {
        setError(res.message);
      }
    }, 400);
  };

  const handleFillDemo = () => {
    setOfficerId("AO-MDU-1042");
    setPassword("demo123");
    setError(null);
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-background px-6 py-8">
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
          <ShieldCheck className="size-3.5" />
          <span>Official Portal</span>
        </div>
      </div>

      <div className="mt-8">
        <div className="grid size-12 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-sm">
          <Lock className="size-6" />
        </div>
        <h1 className="mt-4 font-display text-2xl font-bold tracking-tight">Officer Sign In</h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Department of Agriculture & Farmer Welfare. Enter your official officer ID to access the field dashboard.
        </p>
      </div>

      {error && (
        <div className="mt-4 flex items-center gap-2.5 rounded-2xl border border-destructive/20 bg-destructive/10 p-3.5 text-xs text-destructive">
          <AlertCircle className="size-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Language Selection — horizontal scroll chips, right above ID/Password */}
      <div className="mt-5">
        <label className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground">
          <Globe className="size-3.5 text-primary" />
          <span>Select Your Language</span>
        </label>
        <div className="mt-2 flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {LOGIN_LANGUAGES.map((l) => {
            const active = language === l.code;
            return (
              <button
                key={l.code}
                type="button"
                onClick={() => handleSelectLanguage(l.code)}
                aria-pressed={active}
                className={`tap flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-semibold transition ${
                  active
                    ? "border-primary bg-primary text-primary-foreground shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground"
                }`}
              >
                {active && <Check className="size-3.5" />}
                <span>{l.native}</span>
                {l.native !== l.label && <span className="opacity-70">({l.label})</span>}
              </button>
            );
          })}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Officer ID / Designation
          </label>
          <div className="relative mt-1.5">
            <User className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              required
              value={officerId}
              onChange={(e) => setOfficerId(e.target.value)}
              placeholder="e.g. AO-MDU-1042"
              className="w-full rounded-2xl border border-border bg-card py-3.5 pl-10 pr-4 text-sm font-medium focus:border-primary focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Password
          </label>
          <div className="relative mt-1.5">
            <Lock className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type={showPassword ? "text" : "password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full rounded-2xl border border-border bg-card py-3.5 pl-10 pr-10 text-sm font-medium focus:border-primary focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="rounded border-border text-primary focus:ring-primary"
            />
            <span className="text-muted-foreground">Remember session</span>
          </label>
          <button
            type="button"
            onClick={handleFillDemo}
            className="font-semibold text-primary hover:underline"
          >
            Fill Demo Credentials
          </button>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="tap mt-2 flex w-full items-center justify-center rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground shadow-md transition hover:bg-primary/90 disabled:opacity-50"
        >
          {loading ? "Verifying..." : "Sign In to Officer Portal"}
        </button>
      </form>

      <div className="mt-auto space-y-2 pt-6 text-center">
        <p className="text-[11px] text-muted-foreground">Demo accounts (each officer is assigned to one area):</p>
        <div className="rounded-2xl border border-border bg-card p-3 text-left text-[11px]">
          <p><strong>AO-MDU-1042</strong> · Madurai · password <strong>demo123</strong></p>
          <p><strong>AO-VNR-2081</strong> · Virudhunagar · password <strong>demo123</strong></p>
          <p><strong>AO-SIV-3017</strong> · Sivakasi · password <strong>demo123</strong></p>
        </div>
      </div>
    </div>
  );
}
