import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Bell, CheckCheck, Archive, ShieldAlert } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import {
  getNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  archiveNotification,
} from "@/lib/officerService";

export const Route = createFileRoute("/officer/notifications")({
  component: OfficerNotificationsScreen,
});

function OfficerNotificationsScreen() {
  const [filter, setFilter] = useState("All");
  const [refresh, setRefresh] = useState(0);

  const notifications = getNotifications();

  const filtered = notifications.filter((n) => {
    if (n.archived) return false;
    if (filter === "All") return true;
    return n.category === filter;
  });

  const handleMarkAll = () => {
    markAllNotificationsRead();
    setRefresh((r) => r + 1);
  };

  const handleMarkOne = (id: string) => {
    markNotificationRead(id);
    setRefresh((r) => r + 1);
  };

  const handleArchive = (id: string) => {
    archiveNotification(id);
    setRefresh((r) => r + 1);
  };

  return (
    <OfficerMobileShell title="Notifications" subtitle="Official Alerts & Updates">
      <div className="space-y-3 px-4 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            {["All", "Urgent", "Hotspots", "Cases", "Field Visits", "System"].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`tap shrink-0 rounded-full px-3 py-1 font-semibold transition ${
                  filter === cat
                    ? "bg-primary text-primary-foreground"
                    : "border border-border bg-card text-muted-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleMarkAll}
            className="tap shrink-0 text-xs font-semibold text-primary hover:underline ml-2"
          >
            Mark all read
          </button>
        </div>

        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card p-6 text-center text-xs text-muted-foreground">
              No notifications found in {filter}.
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className={`rounded-2xl border p-3.5 transition ${
                  item.read ? "border-border bg-card/60 opacity-80" : "border-primary/40 bg-card shadow-xs"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 text-[10px]">
                      <span className={`font-bold uppercase ${
                        item.priority === "Critical" ? "text-destructive" : "text-primary"
                      }`}>
                        {item.category}
                      </span>
                      <span className="text-muted-foreground">· {item.timestamp}</span>
                    </div>
                    <h4 className="text-xs font-bold text-foreground mt-0.5">{item.title}</h4>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{item.body}</p>
                  </div>

                  <div className="flex flex-col gap-1 shrink-0">
                    {!item.read && (
                      <button
                        type="button"
                        onClick={() => handleMarkOne(item.id)}
                        className="tap text-[10px] font-bold text-primary hover:underline"
                      >
                        Read
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleArchive(item.id)}
                      className="tap text-[10px] text-muted-foreground hover:text-foreground"
                    >
                      Archive
                    </button>
                  </div>
                </div>

                {item.hotspotId && (
                  <Link
                    to="/officer/hotspot/$hotspotId"
                    params={{ hotspotId: item.hotspotId }}
                    className="tap mt-2 inline-block text-[11px] font-bold text-destructive hover:underline"
                  >
                    View Hotspot →
                  </Link>
                )}
                {item.caseId && (
                  <Link
                    to="/officer/case/$caseId"
                    params={{ caseId: item.caseId }}
                    className="tap mt-2 inline-block text-[11px] font-bold text-primary hover:underline"
                  >
                    Open Case File →
                  </Link>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </OfficerMobileShell>
  );
}
