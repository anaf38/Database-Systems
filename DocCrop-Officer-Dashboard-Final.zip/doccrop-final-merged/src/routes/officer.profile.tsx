import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { User, ShieldCheck, Mail, Phone, MapPin, Save, LogOut } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getOfficerProfile, updateOfficerProfile, logoutOfficer } from "@/lib/officerService";

export const Route = createFileRoute("/officer/profile")({
  component: OfficerProfileScreen,
});

function OfficerProfileScreen() {
  const navigate = useNavigate();
  const profile = getOfficerProfile();

  const [name, setName] = useState(profile.name);
  const [department, setDepartment] = useState(profile.department);
  const [division, setDivision] = useState(profile.division);
  const [phone, setPhone] = useState(profile.phone);
  const [email, setEmail] = useState(profile.email);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateOfficerProfile({ name, department, division, phone, email });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleLogout = () => {
    logoutOfficer();
    navigate({ to: "/role", replace: true });
  };

  return (
    <OfficerMobileShell title="Officer Profile" subtitle="Official Department Credentials">
      <form onSubmit={handleSave} className="space-y-4 px-4 pt-4">
        <div className="rounded-2xl border border-border bg-card p-4 text-center shadow-xs">
          <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-primary text-primary-foreground text-xl font-bold shadow-sm">
            AO
          </div>
          <h2 className="mt-2 text-base font-bold">{profile.name}</h2>
          <p className="text-xs text-muted-foreground">{profile.role} · {profile.badgeNumber}</p>
        </div>

        {saved && (
          <div className="rounded-xl bg-emerald-500/10 p-2.5 text-center text-xs font-bold text-emerald-600">
            Profile saved to localStorage!
          </div>
        )}

        <div className="space-y-3">
          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Designation / Title</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 w-full rounded-xl border border-border bg-card p-2.5 text-xs font-medium focus:border-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Department</label>
            <input
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="mt-1 w-full rounded-xl border border-border bg-card p-2.5 text-xs font-medium focus:border-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Division / District</label>
            <input
              type="text"
              value={division}
              onChange={(e) => setDivision(e.target.value)}
              className="mt-1 w-full rounded-xl border border-border bg-card p-2.5 text-xs font-medium focus:border-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Phone</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="mt-1 w-full rounded-xl border border-border bg-card p-2.5 text-xs font-medium focus:border-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Official Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-xl border border-border bg-card p-2.5 text-xs font-medium focus:border-primary focus:outline-none"
            />
          </div>
        </div>

        <button
          type="submit"
          className="tap flex w-full items-center justify-center gap-1.5 rounded-xl bg-primary py-3 text-xs font-bold text-primary-foreground shadow-xs hover:bg-primary/90"
        >
          <Save className="size-3.5" />
          Save Changes
        </button>

        <button
          type="button"
          onClick={handleLogout}
          className="tap flex w-full items-center justify-center gap-1.5 rounded-xl bg-destructive/10 py-3 text-xs font-bold text-destructive hover:bg-destructive/20"
        >
          <LogOut className="size-3.5" />
          Log Out
        </button>
      </form>
    </OfficerMobileShell>
  );
}
