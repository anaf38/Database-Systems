import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Store, MapPin, CheckCircle2, CalendarClock, XCircle } from "lucide-react";
import { toast } from "sonner";
import { AppShell, ScreenHeader } from "@/components/AppShell";
import { getFarmerReferrals, updateReferralStatus } from "@/lib/dealerService";
import type { ReferralStatus } from "@/lib/dealerTypes";

export const Route = createFileRoute("/officer/referrals")({ component: OfficerReferrals });

const STATUS_TONE: Record<ReferralStatus, string> = {
  "Pending Officer Review": "bg-moderate text-moderate-foreground",
  "Reviewed": "bg-sky text-sky-foreground",
  "Field Visit Scheduled": "bg-primary-soft text-primary",
  "Dismissed": "bg-secondary text-secondary-foreground",
};

function OfficerReferrals() {
  const [, refresh] = useState(0);
  const referrals = getFarmerReferrals();
  const pending = referrals.filter((r) => r.status === "Pending Officer Review");
  const handled = referrals.filter((r) => r.status !== "Pending Officer Review");

  const act = (id: string, status: ReferralStatus) => {
    updateReferralStatus(id, status);
    refresh((n) => n + 1);
    toast.success(`Referral marked "${status}" — dealer has been notified.`);
  };

  return (
    <AppShell>
      <div className="px-5 pb-2 pt-7">
        <Link to="/officer" className="tap flex items-center gap-2 text-sm font-semibold text-primary">
          <ArrowLeft className="size-4" />
          Officer dashboard
        </Link>
      </div>
      <ScreenHeader
        title="Dealer referrals"
        subtitle={`${pending.length} pending review`}
        action={
          <span className="grid size-10 place-items-center rounded-full bg-primary-soft">
            <Store className="size-5 text-primary" />
          </span>
        }
      />

      <div className="space-y-2.5 px-5 pb-2">
        {referrals.length === 0 && <p className="card-surface p-4 text-sm text-muted-foreground">No farmer referrals from dealers yet.</p>}
        {pending.map((r) => (
          <div key={r.id} className="card-surface p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-bold leading-snug">{r.farmerName} · {r.crop}</p>
                <p className="text-xs text-muted-foreground">Referred by {r.dealerShopName}</p>
              </div>
              <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${STATUS_TONE[r.status]}`}>{r.status}</span>
            </div>
            <p className="mt-2 text-sm">{r.issue}</p>
            <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="size-3.5" />{r.location}</p>
            {r.notes && <p className="mt-2 rounded-xl bg-secondary p-2.5 text-xs text-secondary-foreground">{r.notes}</p>}
            <p className="mt-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{new Date(r.createdAt).toLocaleString("en-IN")}</p>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <button onClick={() => act(r.id, "Reviewed")} className="tap flex items-center justify-center gap-1 rounded-lg bg-secondary py-2 text-xs font-bold"><CheckCircle2 className="size-3.5" />Reviewed</button>
              <button onClick={() => act(r.id, "Field Visit Scheduled")} className="tap flex items-center justify-center gap-1 rounded-lg bg-primary py-2 text-xs font-bold text-primary-foreground"><CalendarClock className="size-3.5" />Schedule visit</button>
              <button onClick={() => act(r.id, "Dismissed")} className="tap flex items-center justify-center gap-1 rounded-lg border border-destructive/40 py-2 text-xs font-bold text-destructive"><XCircle className="size-3.5" />Dismiss</button>
            </div>
          </div>
        ))}
      </div>

      {handled.length > 0 && (
        <div className="px-5 pb-6">
          <h2 className="mb-2 text-sm font-bold text-muted-foreground">Handled</h2>
          <div className="space-y-2">
            {handled.map((r) => (
              <div key={r.id} className="card-surface p-3.5 opacity-75">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-bold">{r.farmerName} · {r.crop}</p>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${STATUS_TONE[r.status]}`}>{r.status}</span>
                </div>
                <p className="text-xs text-muted-foreground">Referred by {r.dealerShopName} · {r.location}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </AppShell>
  );
}
