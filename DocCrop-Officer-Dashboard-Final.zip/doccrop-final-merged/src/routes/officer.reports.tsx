import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileBarChart2, Download, Printer, RefreshCw } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getReports, type ReportSummary } from "@/lib/officerService";

export const Route = createFileRoute("/officer/reports")({
  component: OfficerReportsScreen,
});

function OfficerReportsScreen() {
  const [period, setPeriod] = useState<"Today" | "7 Days" | "30 Days" | "90 Days" | "All">("7 Days");
  const summary = getReports(period);

  const handleDownload = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(summary, null, 2));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `doccrop-report-${period.toLowerCase().replace(" ", "-")}.json`);
    dlAnchor.click();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <OfficerMobileShell title="Epidemiological Reports" subtitle="Madurai Division Analytics">
      <div className="space-y-4 px-4 pt-4">
        {/* Period Filter */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {(["Today", "7 Days", "30 Days", "90 Days", "All"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`tap shrink-0 rounded-full px-3 py-1 font-semibold transition ${
                period === p
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "border border-border bg-card text-muted-foreground"
              }`}
            >
              {p}
            </button>
          ))}
        </div>

        {/* Summary Stat Grid */}
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-xl border border-border bg-card p-3 text-center">
            <span className="text-[10px] text-muted-foreground block">Total Cases</span>
            <span className="text-lg font-bold">{summary.totalCases}</span>
          </div>
          <div className="rounded-xl border border-border bg-card p-3 text-center">
            <span className="text-[10px] text-rose-600 block">High Risk</span>
            <span className="text-lg font-bold text-rose-600">{summary.highRiskCases}</span>
          </div>
          <div className="rounded-xl border border-border bg-card p-3 text-center">
            <span className="text-[10px] text-muted-foreground block">Hotspots</span>
            <span className="text-lg font-bold">{summary.hotspotsCount}</span>
          </div>
        </div>

        {/* Chart 1: Disease Distribution */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
            Disease Distribution ({period})
          </h3>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={summary.diseaseDistribution} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} />
                <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                <Bar dataKey="count" fill="#16a34a" radius={[4, 4, 0, 0]} name="Cases" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Risk Breakdown */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
            Risk Breakdown ({period})
          </h3>
          <div className="space-y-2 text-xs">
            {summary.riskDistribution.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <span className="font-semibold">{item.name}</span>
                <span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ backgroundColor: item.color + "25", color: item.color }}>
                  {item.count} cases
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Actions (Master Prompt Section 32) */}
        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={handleDownload}
            className="tap flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-primary py-3 text-xs font-bold text-primary-foreground shadow-xs"
          >
            <Download className="size-3.5" />
            Download
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="tap flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-border bg-card py-3 text-xs font-bold text-foreground hover:bg-secondary"
          >
            <Printer className="size-3.5" />
            Print Report
          </button>
        </div>
      </div>
    </OfficerMobileShell>
  );
}
