import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Settings, Globe, Moon, Bell, Radar, RotateCcw, Save } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getSettings, updateSettings, resetSettings } from "@/lib/officerService";

export const Route = createFileRoute("/officer/settings")({
  component: OfficerSettingsScreen,
});

function OfficerSettingsScreen() {
  const settings = getSettings();
  const [lang, setLang] = useState(settings.language);
  const [minFarmers, setMinFarmers] = useState(settings.hotspotConfig.minimumAffectedFarmers);
  const [clusterKm, setClusterKm] = useState(settings.hotspotConfig.clusterRadiusKm);
  const [windowDays, setWindowDays] = useState(settings.hotspotConfig.timeWindowDays);
  const [notifEnabled, setNotifEnabled] = useState(settings.notificationsEnabled);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      language: lang,
      notificationsEnabled: notifEnabled,
      hotspotConfig: {
        minimumAffectedFarmers: Number(minFarmers),
        clusterRadiusKm: Number(clusterKm),
        timeWindowDays: Number(windowDays),
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => {
    if (confirm("Reset all settings to default values?")) {
      const reset = resetSettings();
      setLang(reset.language);
      setMinFarmers(reset.hotspotConfig.minimumAffectedFarmers);
      setClusterKm(reset.hotspotConfig.clusterRadiusKm);
      setWindowDays(reset.hotspotConfig.timeWindowDays);
      setNotifEnabled(reset.notificationsEnabled);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  return (
    <OfficerMobileShell title="System Settings" subtitle="Preferences & Hotspot Thresholds">
      <form onSubmit={handleSave} className="space-y-4 px-4 pt-4">
        {saved && (
          <div className="rounded-xl bg-emerald-500/10 p-2.5 text-center text-xs font-bold text-emerald-600">
            Settings updated successfully!
          </div>
        )}

        {/* Language Selection */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5 mb-2">
            <Globe className="size-3.5 text-primary" />
            <span>Application Language</span>
          </label>
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value as any)}
            className="w-full rounded-xl border border-border bg-background p-2.5 text-xs font-medium"
          >
            <option value="English">English</option>
            <option value="Tamil">Tamil (தமிழ்)</option>
            <option value="Hindi">Hindi (हिन्दी)</option>
            <option value="Telugu">Telugu (తెలుగు)</option>
            <option value="Kannada">Kannada (ಕನ್ನಡ)</option>
            <option value="Malayalam">Malayalam (മലയാളം)</option>
          </select>
        </div>

        {/* Hotspot Clustering Thresholds */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Radar className="size-3.5 text-rose-500" />
            <span>Hotspot Detection Settings</span>
          </h3>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Min Affected Farmers</label>
            <input
              type="number"
              value={minFarmers}
              onChange={(e) => setMinFarmers(Number(e.target.value))}
              className="mt-1 w-full rounded-xl border border-border bg-background p-2 text-xs"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Cluster Radius (km)</label>
            <input
              type="number"
              step="0.1"
              value={clusterKm}
              onChange={(e) => setClusterKm(Number(e.target.value))}
              className="mt-1 w-full rounded-xl border border-border bg-background p-2 text-xs"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-muted-foreground uppercase">Time Window (Days)</label>
            <input
              type="number"
              value={windowDays}
              onChange={(e) => setWindowDays(Number(e.target.value))}
              className="mt-1 w-full rounded-xl border border-border bg-background p-2 text-xs"
            />
          </div>
        </div>

        {/* Notifications Toggle */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="size-4 text-amber-500" />
            <span className="text-xs font-bold">Push Alerts & Notifications</span>
          </div>
          <input
            type="checkbox"
            checked={notifEnabled}
            onChange={(e) => setNotifEnabled(e.target.checked)}
            className="size-4 rounded text-primary"
          />
        </div>

        <div className="flex gap-2 pt-1">
          <button
            type="submit"
            className="tap flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-primary py-3 text-xs font-bold text-primary-foreground shadow-xs"
          >
            <Save className="size-3.5" />
            Save Settings
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="tap flex items-center justify-center gap-1 rounded-xl border border-border bg-card px-4 py-3 text-xs font-bold text-muted-foreground hover:text-foreground"
          >
            <RotateCcw className="size-3.5" />
            Reset
          </button>
        </div>
      </form>
    </OfficerMobileShell>
  );
}
