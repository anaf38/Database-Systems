import { createFileRoute, Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { isOfficerAuthenticated } from "@/lib/officerService";

export const Route = createFileRoute("/officer")({ component: OfficerLayout });

function OfficerLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const isExactOfficer = location.pathname === "/officer" || location.pathname === "/officer/";

  useEffect(() => {
    if (isExactOfficer) {
      navigate({
        to: isOfficerAuthenticated() ? "/officer/dashboard" : "/officer/login",
        replace: true,
      });
    }
  }, [navigate, isExactOfficer]);

  if (isExactOfficer) return null;
  return <Outlet />;
}
