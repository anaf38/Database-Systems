import { createFileRoute, useParams, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  CalendarCheck2,
  CheckCircle2,
  Clock,
  MapPin,
  Play,
  XCircle,
  FileText,
  User,
  ShieldCheck,
} from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import {
  getFieldVisitById,
  updateFieldVisitStatus,
  submitInvestigation,
  type InvestigationData,
} from "@/lib/officerService";

export const Route = createFileRoute("/officer/visit/$visitId")({
  component: OfficerVisitDetail,
});

function OfficerVisitDetail() {
  const { visitId } = useParams({ from: "/officer/visit/$visitId" });
  const navigate = useNavigate();
  const [refresh, setRefresh] = useState(0);

  const visit = getFieldVisitById(visitId);

  // Investigation form fields (Master Prompt Section 27)
  const [farmsInspected, setFarmsInspected] = useState(3);
  const [confirmedCases, setConfirmedCases] = useState(2);
  const [suspectedCases, setSuspectedCases] = useState(1);
  const [symptoms, setSymptoms] = useState("Spindle lesions with chlorotic halos");
  const [growthStage, setGrowthStage] = useState("Tillering / Early Panicle");
  const [affectedArea, setAffectedArea] = useState("2.5 acres");
  const [weather, setWeather] = useState("Overcast, 28°C");
  const [soilCondition, setSoilCondition] = useState("Clay loam, high moisture");
  const [moisture, setMoisture] = useState("Adequate to saturated");
  const [pestsObserved, setPestsObserved] = useState("Fungal blast mycelium");
  const [officerRemarks, setOfficerRemarks] = useState("Immediate fungicide rotation advised to contain spread.");
  const [assessment, setAssessment] = useState<InvestigationData["assessment"]>("Confirmed Outbreak");

  if (!visit) {
    return (
      <OfficerMobileShell title="Visit Details" showBack backTo="/officer/visits">
        <div className="p-6 text-center text-sm text-muted-foreground">Visit {visitId} not found.</div>
      </OfficerMobileShell>
    );
  }

  const handleStart = () => {
    updateFieldVisitStatus(visit.id, "In Progress");
    setRefresh((r) => r + 1);
  };

  const handleCancel = () => {
    updateFieldVisitStatus(visit.id, "Cancelled", "Cancelled by officer");
    setRefresh((r) => r + 1);
  };

  const handleCompleteInvestigation = (e: React.FormEvent) => {
    e.preventDefault();
    submitInvestigation(visit.id, {
      farmsInspected,
      confirmedCases,
      suspectedCases,
      symptoms,
      growthStage,
      affectedArea,
      weather,
      soilCondition,
      moisture,
      pestsObserved,
      officerRemarks,
      assessment,
      completedAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    });
    setRefresh((r) => r + 1);
  };

  return (
    <OfficerMobileShell title={visit.id} subtitle={visit.farmerName} showBack backTo="/officer/visits">
      <div className="space-y-4 px-4 pt-4">
        {/* Visit Card */}
        <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold text-primary uppercase">{visit.id}</span>
              <h2 className="text-base font-bold">{visit.farmerName}</h2>
              <p className="text-xs text-muted-foreground">{visit.crop} · {visit.disease}</p>
            </div>
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${
              visit.status === "Completed"
                ? "bg-emerald-500/20 text-emerald-700"
                : visit.status === "In Progress"
                ? "bg-amber-500/20 text-amber-700"
                : "bg-blue-500/20 text-blue-700"
            }`}>
              {visit.status}
            </span>
          </div>

          <div className="mt-3 space-y-1.5 border-t border-border/60 pt-2.5 text-xs text-muted-foreground">
            <p className="flex items-center gap-1.5">
              <Clock className="size-3.5 text-primary" />
              <span>{visit.dateTime}</span>
            </p>
            <p className="flex items-center gap-1.5">
              <MapPin className="size-3.5 text-primary" />
              <span>{visit.location}</span>
            </p>
            <p className="mt-1 text-foreground font-medium">Purpose: {visit.purpose}</p>
          </div>

          {/* Quick Action Buttons */}
          {visit.status !== "Completed" && visit.status !== "Cancelled" && (
            <div className="mt-3 flex gap-2 border-t border-border/60 pt-3">
              {visit.status === "Scheduled" && (
                <button
                  type="button"
                  onClick={handleStart}
                  className="tap flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-amber-600 py-2 text-xs font-bold text-white shadow-xs"
                >
                  <Play className="size-3.5" />
                  Start Visit
                </button>
              )}
              <button
                type="button"
                onClick={handleCancel}
                className="tap flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-destructive/10 py-2 text-xs font-bold text-destructive hover:bg-destructive/20"
              >
                <XCircle className="size-3.5" />
                Cancel Visit
              </button>
            </div>
          )}
        </div>

        {/* Master Prompt Section 27: Investigation Form */}
        {visit.status !== "Completed" ? (
          <form onSubmit={handleCompleteInvestigation} className="rounded-2xl border border-border bg-card p-4 shadow-xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
              <FileText className="size-3.5 text-primary" />
              <span>Field Investigation Form</span>
            </h3>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] font-bold text-muted-foreground uppercase">Inspected</label>
                <input
                  type="number"
                  value={farmsInspected}
                  onChange={(e) => setFarmsInspected(Number(e.target.value))}
                  className="w-full rounded-xl border border-border bg-background p-2 text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-muted-foreground uppercase">Confirmed</label>
                <input
                  type="number"
                  value={confirmedCases}
                  onChange={(e) => setConfirmedCases(Number(e.target.value))}
                  className="w-full rounded-xl border border-border bg-background p-2 text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-muted-foreground uppercase">Suspected</label>
                <input
                  type="number"
                  value={suspectedCases}
                  onChange={(e) => setSuspectedCases(Number(e.target.value))}
                  className="w-full rounded-xl border border-border bg-background p-2 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-muted-foreground uppercase">Symptoms</label>
              <input
                type="text"
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                className="w-full rounded-xl border border-border bg-background p-2 text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-bold text-muted-foreground uppercase">Growth Stage</label>
                <input
                  type="text"
                  value={growthStage}
                  onChange={(e) => setGrowthStage(e.target.value)}
                  className="w-full rounded-xl border border-border bg-background p-2 text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-muted-foreground uppercase">Affected Area</label>
                <input
                  type="text"
                  value={affectedArea}
                  onChange={(e) => setAffectedArea(e.target.value)}
                  className="w-full rounded-xl border border-border bg-background p-2 text-xs"
                />
              </div>
            </div>

            {/* Assessment (Master Prompt Section 28 Mapping) */}
            <div>
              <label className="text-[10px] font-bold text-muted-foreground uppercase">Assessment Outcome</label>
              <select
                value={assessment}
                onChange={(e) => setAssessment(e.target.value as any)}
                className="w-full rounded-xl border border-border bg-background p-2 text-xs font-bold"
              >
                <option value="Confirmed Outbreak">Confirmed Outbreak → Confirmed Case</option>
                <option value="Potential Outbreak">Potential Outbreak → Monitoring</option>
                <option value="False Alarm">False Alarm → Resolved</option>
                <option value="Requires Further Monitoring">Requires Further Monitoring → Monitoring</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-muted-foreground uppercase">Officer Remarks</label>
              <textarea
                rows={2}
                value={officerRemarks}
                onChange={(e) => setOfficerRemarks(e.target.value)}
                className="w-full rounded-xl border border-border bg-background p-2 text-xs"
              />
            </div>

            <button
              type="submit"
              className="tap flex w-full items-center justify-center gap-1.5 rounded-xl bg-primary py-3 text-xs font-bold text-primary-foreground shadow-sm hover:bg-primary/90"
            >
              <CheckCircle2 className="size-4" />
              <span>Complete Investigation & Update Case</span>
            </button>
          </form>
        ) : (
          <div className="rounded-2xl border border-border bg-card p-4 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-emerald-600" />
              <span>Completed Investigation Dossier</span>
            </h3>
            {visit.investigation && (
              <div className="space-y-2 text-xs">
                <p>Outcome: <strong>{visit.investigation.assessment}</strong></p>
                <p>Farms Inspected: {visit.investigation.farmsInspected} · Confirmed: {visit.investigation.confirmedCases}</p>
                <p>Symptoms: {visit.investigation.symptoms}</p>
                <p className="rounded-xl bg-secondary p-2.5 text-muted-foreground">
                  Officer Note: {visit.investigation.officerRemarks}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </OfficerMobileShell>
  );
}
