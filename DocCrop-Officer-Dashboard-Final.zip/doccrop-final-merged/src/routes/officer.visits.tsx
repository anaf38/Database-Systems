import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CalendarCheck2, Plus, Clock, MapPin, ArrowRight } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getFieldVisits, type FieldVisit } from "@/lib/officerService";

export const Route = createFileRoute("/officer/visits")({
  component: OfficerVisitsList,
});

function OfficerVisitsList() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<string>("Today");
  const visits = getFieldVisits();

  const getVisitDate = (dateTime: string) => {
    const parsed = new Date(dateTime);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  };

  const filtered = useMemo(() => visits.filter((v) => {
    const date = getVisitDate(v.dateTime);
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrowStart = new Date(todayStart);
    tomorrowStart.setDate(tomorrowStart.getDate() + 1);
    const dayAfterTomorrow = new Date(tomorrowStart);
    dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 1);

    if (tab === "Today") return date ? date >= todayStart && date < tomorrowStart && v.status !== "Cancelled" : v.dateTime.toLowerCase().includes("today");
    if (tab === "Upcoming") return v.status === "Scheduled" && (!date || date >= now);
    if (tab === "Completed") return v.status === "Completed";
    if (tab === "Overdue") return v.status === "Scheduled" && !!date && date < now;
    return true;
  }), [visits, tab]);

  return (
    <OfficerMobileShell title="Field Visits" subtitle="Inspections & Investigations">
      <div className="space-y-3 px-4 pt-4">
        {/* Schedule Button */}
        <button
          type="button"
          onClick={() => navigate({ to: "/officer/visits/schedule" })}
          className="tap flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-xs font-bold text-primary-foreground shadow-sm hover:bg-primary/90"
        >
          <Plus className="size-4" />
          <span>Schedule New Field Visit</span>
        </button>

        {/* Tabs: Today, Upcoming, Completed, Overdue, All */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          {["Today", "Upcoming", "Completed", "Overdue", "All"].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`tap shrink-0 rounded-full px-3.5 py-1 font-semibold transition ${
                tab === t
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "border border-border bg-card text-muted-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Visits List */}
        <div className="space-y-2.5">
          {filtered.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card p-6 text-center text-xs text-muted-foreground">
              No field visits found under {tab}.
            </div>
          ) : (
            filtered.map((visit) => (
              <Link
                key={visit.id}
                to="/officer/visit/$visitId"
                params={{ visitId: visit.id }}
                className="tap block rounded-2xl border border-border bg-card p-3.5 shadow-xs hover:border-primary"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-primary uppercase">{visit.id}</span>
                    <h4 className="text-sm font-bold">{visit.farmerName}</h4>
                    <p className="text-xs text-muted-foreground">{visit.crop} · {visit.disease}</p>
                  </div>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                    visit.status === "Completed"
                      ? "bg-emerald-500/20 text-emerald-700"
                      : visit.status === "In Progress"
                      ? "bg-amber-500/20 text-amber-700"
                      : "bg-blue-500/20 text-blue-700"
                  }`}>
                    {visit.status}
                  </span>
                </div>

                <div className="mt-2 text-xs text-muted-foreground">
                  <p className="flex items-center gap-1">
                    <Clock className="size-3 text-primary" />
                    <span>{(() => { const d = getVisitDate(visit.dateTime); return d ? d.toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : visit.dateTime; })()}</span>
                  </p>
                  <p className="flex items-center gap-1 mt-0.5">
                    <MapPin className="size-3 text-primary" />
                    <span>{visit.location}</span>
                  </p>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </OfficerMobileShell>
  );
}
