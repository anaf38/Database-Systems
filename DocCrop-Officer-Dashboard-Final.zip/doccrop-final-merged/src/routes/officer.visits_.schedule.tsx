import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, CalendarCheck2, User, Sprout, MapPin, FileText } from "lucide-react";
import { OfficerMobileShell } from "@/components/OfficerMobileShell";
import { getFarmers, getCases, createFieldVisit } from "@/lib/officerService";

export const Route = createFileRoute("/officer/visits/schedule")({
  component: ScheduleFieldVisitScreen,
});

function ScheduleFieldVisitScreen() {
  const navigate = useNavigate();
  const farmers = getFarmers();
  const cases = getCases();

  const [farmerId, setFarmerId] = useState(farmers[0]?.id || "");
  const [caseId, setCaseId] = useState(cases.find((c) => c.farmerId === farmers[0]?.id)?.id || cases[0]?.id || "");
  const [dateTime, setDateTime] = useState(() => {
    const d = new Date(Date.now() + 24 * 60 * 60 * 1000);
    d.setMinutes(0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [location, setLocation] = useState("Melur - Main Road Block");
  const [purpose, setPurpose] = useState("On-site spore validation & cluster verification");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");

  const farmerCases = useMemo(() => cases.filter((c) => c.farmerId === farmerId), [cases, farmerId]);

  const handleFarmerChange = (nextFarmerId: string) => {
    setFarmerId(nextFarmerId);
    const firstCase = cases.find((c) => c.farmerId === nextFarmerId);
    setCaseId(firstCase?.id || "");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const selectedDate = new Date(dateTime);
    if (Number.isNaN(selectedDate.getTime()) || selectedDate.getTime() <= Date.now()) {
      setError("Please choose a future date and time for the field visit.");
      return;
    }
    if (!farmerId || !caseId) {
      setError("Please select both a farmer and a case.");
      return;
    }

    const pickedFarmer = farmers.find((f) => f.id === farmerId) || farmers[0];
    const pickedCase = cases.find((c) => c.id === caseId) || cases[0];

    createFieldVisit({
      farmerId: pickedFarmer.id,
      farmerName: pickedFarmer.name,
      caseId: pickedCase.id,
      crop: pickedCase.crop,
      disease: pickedCase.disease,
      location: location || pickedFarmer.village,
      dateTime: selectedDate.toISOString(),
      purpose,
      notes,
    });

    navigate({ to: "/officer/visits" });
  };

  return (
    <OfficerMobileShell title="Schedule Visit" subtitle="Assign Field Inspection" showBack backTo="/officer/visits">
      <form onSubmit={handleSubmit} className="space-y-4 px-4 pt-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Select Farmer</label>
          <select
            value={farmerId}
            onChange={(e) => handleFarmerChange(e.target.value)}
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          >
            {farmers.map((f) => (
              <option key={f.id} value={f.id}>{f.name} ({f.village} · {f.primaryCrop})</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Select Case</label>
          <select
            value={caseId}
            onChange={(e) => setCaseId(e.target.value)}
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          >
            {farmerCases.map((c) => (
              <option key={c.id} value={c.id}>{c.id} - {c.disease} ({c.farmerName})</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Date & Time</label>
          <input
            type="datetime-local"
            required
            min={new Date(Date.now() + 60 * 1000).toISOString().slice(0, 16)}
            value={dateTime}
            onChange={(e) => setDateTime(e.target.value)}
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Location</label>
          <input
            type="text"
            required
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Field landmark or village"
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Purpose</label>
          <input
            type="text"
            required
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            placeholder="Visit objective"
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Officer Notes (Optional)</label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Preliminary equipment or instructions..."
            className="mt-1.5 w-full rounded-2xl border border-border bg-card p-3 text-xs font-medium focus:border-primary focus:outline-none"
          />
        </div>

        {error && (
          <div role="alert" className="rounded-2xl border border-destructive/30 bg-destructive/10 p-3 text-xs font-semibold text-destructive">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="tap w-full rounded-2xl bg-primary py-3.5 text-xs font-bold text-primary-foreground shadow-md hover:bg-primary/90"
        >
          Confirm & Schedule Visit
        </button>
      </form>
    </OfficerMobileShell>
  );
}
